# Status da implementação — personalização por executivo (Supabase)

**Atualizado em:** 2026-10-10 (fim do dia)
**Estado:** implementado e testado localmente com Supabase **simulado**. Nenhum projeto Supabase real foi criado ou conectado. Nada foi publicado. Este documento não contém credenciais.

Para retomar: ler este arquivo, depois `docs/CONFIGURACAO-SUPABASE.md` (passo a passo) e, se precisar de detalhe, `qa/RELATORIO.md` (seção 2026-10-10) e `docs/07-fontes-e-pendencias.md` (P25–P32).

---

## 1. O que foi concluído

### Banco e Storage (`supabase/`)
- `migrations/20261010120000_executives.sql`
  - Tabela `public.executives` com RLS ligada.
  - Escrita (`GRANT UPDATE`) só nas colunas editáveis: nome, nome de apresentação, cargo, e-mail de contato, telefones e foto.
  - CHECKs de formato e tamanho.
  - Slug único e imutável (trigger) e no máximo um perfil padrão.
  - `photo_path` restrito à pasta do próprio usuário.
  - RPC pública `get_public_executive(p_slug)`. Devolve só os campos da apresentação: sem `id`, `user_id`, e-mail de login ou `created_at`.
- `migrations/20261010120100_executive_photos_storage.sql`
  - Bucket público `executive-photos`, até 2 MB, só `image/webp` e `image/jpeg`.
  - Escrita, troca e exclusão só em `<auth.uid()>/`.
  - Sem policy para anon, então não há listagem.
- `migrations/20261010120200_seed_sabrina.sql`: Sabrina como perfil padrão. A inserção é idempotente.
- `snippets/`: vincular executivo a uma conta, criar executivo (com placeholders), desativar ou reativar, trocar o perfil padrão.
- `tests/rls.test.mjs`: testes em PGlite, Postgres em WASM, com stub de `auth` e `storage`. Rodam com `npm run test:rls`.

### Painel `/painel/` (`src/painel/`, `src/lib/supabase/panel.ts`, `photo.ts`)
- Login por e-mail e senha, sem cadastro público.
- Convite e definição de senha. Aceita os formatos `token_hash`, `#access_token` e `?code=`.
- "Esqueci minha senha" responde com mensagem neutra.
- Conta sem perfil vinculado mostra um aviso.
- Edição dos campos:
  - nome, nome de apresentação, cargo e e-mail de contato;
  - telefone em campo único, que gera o número exibido e o E.164.
- Validação inline.
- Foto:
  - otimizada no navegador: orientação corrigida, metadados removidos, ≤ 1400 px, WebP/JPEG ≤ 2 MB;
  - prévia e "Desfazer troca" antes de salvar;
  - envio só ao clicar em Salvar, com limpeza de arquivos órfãos.
- Botões: Salvar, Sair, Copiar meu link de apresentação, Abrir minha apresentação.
- Prévia da abertura e do contato. Aviso de alterações não salvas.
- Sem variáveis configuradas, mostra "Painel ainda não configurado".

### Apresentação pública (`src/app/`, `src/lib/executive.ts`, `src/lib/supabase/publicProfile.ts`, `mapping.ts`, `src/state/`)
- **Endereço:** `/?executivo=<slug>`, sem login. Lê a RPC com `fetch`, sem supabase-js no bundle público.
- **Onde o perfil aparece:** M01, M02, M05, M09, M10, na mensagem e na pauta.
- **Estados:**

  | Situação | O que aparece |
  |---|---|
  | Carregando | Tela de carregamento |
  | Slug inexistente ou inválido | "Não encontramos esta apresentação" (nunca outro executivo) |
  | Perfil desativado | "Indisponível" |
  | Falha de conexão com slug | Erro com "Tentar novamente" |
  | Sem identificador e Supabase sem responder | Perfil local de Sabrina |
  | Sem variáveis configuradas | Funciona como antes, só com Sabrina |

- **Sessão do cliente:**
  - Empresa, prioridades, assuntos e pauta ficam só no `sessionStorage`, nunca no Supabase nem na URL.
  - "Nova apresentação" (antigo "Reiniciar apresentação") limpa esses dados e mantém o executivo.
  - Outro slug na mesma aba começa uma sessão limpa.

### Infraestrutura e documentação
- **Build multipágina:** `index.html` e `painel/index.html` (`vite.config.ts`).
- **`/painel` aberto direto:** `vercel.json` e `public/_redirects` fazem a reescrita. Há também um redirecionamento de segurança em `src/main.tsx`.
- **Variáveis:** `.env.example` sem valores. `.env*` fica ignorado pelo Git, exceto `.env.example`.
- **Documentos criados ou atualizados:**
  - `docs/CONFIGURACAO-SUPABASE.md` (passo a passo completo);
  - `docs/STACK.md`, `docs/03-personalizacao.md`, `docs/02-copy.md`, `docs/07-fontes-e-pendencias.md`;
  - guia da apresentação e `qa/RELATORIO.md`.

## 2. Testes realizados

Todos rodaram em Windows 11 com Chromium headless (Playwright). Os testes de navegador usaram o build de produção servido por `vite preview`.

| Teste | Resultado |
|---|---|
| `npm run build` (typecheck + build) | OK |
| `node --import ./src/lib/checks-resolve.mjs src/lib/__checks__.ts` | 31/31 |
| `npm run test:rls`: permissões, isolamento entre usuários, Storage, RPC, seed | 64/64 |
| Painel com Supabase simulado (`page.route`) | 63/63 |
| Apresentação, sem variáveis e com RPC simulada | 95/95 |
| `/painel`, `/painel/`, `/painel?x=1` e `/painel/qualquer`, inclusive após recarregar | abrem o painel |
| Bundle público sem supabase-js/Auth; nenhuma chave no código | conferido |
| Revisão visual em 1440, 390 e 320 px (capturas em `qa/capturas/personalizacao-supabase/`) | feita; disco do login corrigido |

Os scripts de navegador ficaram na pasta temporária da sessão, fora do repositório. Para repetir com Supabase real, siga o checklist da seção 8 de `docs/CONFIGURACAO-SUPABASE.md`.

**Não testado:**
- Supabase real: Auth, PostgREST com JWT assinado, CORS, limites de MIME e tamanho no serviço Storage, envio de e-mail.
- Fluxo `?code=` PKCE de ponta a ponta.
- Safari real (caminho WebP → JPEG).
- Leitor de tela real.
- Hospedagem real.

## 3. Pendências

| Item | Responsável |
|---|---|
| Criar o projeto Supabase da CRED e informar quem administra a conta | Nil/CRED |
| Domínio público da apresentação (Site URL, Redirect URLs, `VITE_PUBLIC_SITE_URL`) | Nil |
| Provedor SMTP para os convites (o SMTP embutido só entrega para a equipe do projeto) | Nil/CRED |
| E-mail de login de Sabrina e dos demais executivos, com dados confirmados de cada um | Nil/CRED |
| Perfil padrão desativado: hoje mostra "indisponível". Alternativa: cair em Sabrina (P29) | decisão de Nil |
| Microcopy nova das telas de estado (`src/app/status/statusCopy.ts`) e do painel (P27/P28) | validar com Nil |
| Captura `docs/guia/img/08-desktop-reiniciar.png` com rótulo antigo | refazer depois |
| Hospedagem (Vercel ou Netlify) e publicação | só com autorização de Nil |

## 4. Próximo passo: conectar ao Supabase real

Seguir `docs/CONFIGURACAO-SUPABASE.md`, nesta ordem:

1. **Criar o projeto:** New project, região `sa-east-1` (São Paulo).
2. **Authentication → Sign In / Providers:**
   - "Allow new users to sign up" **desligado**;
   - Email ligado;
   - Confirm email ligado.
3. **Authentication → URL Configuration:**
   - Site URL = `https://<domínio>`, sem `/painel/`;
   - Redirect URLs = `http://localhost:5173/painel/`, `http://localhost:4173/painel/` e `https://<domínio>/painel/`.
4. **Authentication → Emails → Templates:** links `token_hash` de convite e de recuperação (seção 2.4 do guia). Configurar o SMTP próprio.
5. **SQL Editor:** rodar as 3 migrations na ordem. Conferir com `select * from public.get_public_executive();`, que deve devolver Sabrina.
6. **Storage → executive-photos:** conferir bucket público, 2 MB, WebP/JPEG e 4 policies.
7. **Authentication → Users → Invite user:** convidar Sabrina. Depois, rodar `supabase/snippets/vincular-executivo.sql`.
8. **`.env.local`:** copiar de `.env.example` e preencher `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY` (chave **anon/publishable**, nunca `service_role`/`sb_secret_`). Não versionar.
9. **Testar localmente** com `npm run dev`, percorrendo o checklist da seção 8 do guia: login, edição, foto, link, isolamento com um segundo executivo de teste, slug inexistente e perfil desativado.
10. **Hospedagem:** só depois da validação e com autorização. Configurar as variáveis e refazer o build.
