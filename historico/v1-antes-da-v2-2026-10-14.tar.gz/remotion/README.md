# Remotion — M06 "Gestão em movimento"

Projeto isolado da app (package.json próprio). Gera o recurso animado complementar de M06 conforme `docs/04-direcao-visual-e-motion.md` (seção Remotion). O texto de M06 continua em HTML na página; o vídeo não carrega informação exclusiva.

## O que a composição mostra (ciclo de 20 s em loop, 30 fps, 1080×1080, sem áudio)

Um esquema conceitual, sem telas de software, números, clientes ou resultados:

1. Um centro discreto (a gestão) aparece sobre o fundo preto da marca.
2. **Acompanhamento**, **Integração** e **Informação gerencial** entram juntos (defasagem de 0,3 s, só para a entrada não ser mecânica), com o mesmo tratamento branco.
3. As três ligações do triângulo se desenham ao mesmo tempo.
4. Linhas dos três aspectos convergem ao centro; um anel amarelo marca a convergência e o logotipo oficial (versão negativa) aparece. A formação é lenta (≈ 8,5 s).
5. Conjunto formado, em movimento sutil (≈ 8 s): nós e rótulos flutuam juntos, o anel amarelo respira, o anel pontilhado gira devagar e pulsos brancos discretos correm dos três aspectos ao centro.
6. Dissolução suave (16,5–19,4 s) de volta ao fundo; o último quadro emenda no primeiro.

**Loop (2026-10-12, pedido de Nil).** Antes eram 7 s tocados uma vez, com botão "Rever". Agora é um ciclo contínuo e mais lento. Todo movimento ambiente usa períodos que dividem os 600 quadros (ondas com número inteiro de ciclos, uma volta do anel por ciclo), então não há salto na emenda.

**Versão neutra (2026-10-08).** A primeira versão acendia um aspecto por vez (Acompanhamento → Integração → Informação gerencial) no tempo do vídeo. Como na página o scroll define a etapa ativa no texto, os dois podiam se contradizer (ex.: vídeo destacando "Informação gerencial" com o texto em "Acompanhamento"). Agora nenhum aspecto é destacado isoladamente: o amarelo aparece só no centro (convergência) e no logotipo. O destaque de etapa fica exclusivamente no HTML controlado pelo scroll. Não sincronizar o vídeo ao scroll (docs/04).

Textos: somente os três rótulos de M06 e os complementos listados em `docs/04` ("Portal, atendimento e SLA", "Sistemas e dados", "Indicadores e Power BI").

## Proporção: 1:1

Em desktop, M06 usa palco sticky com texto de um lado e visual do outro; uma coluna de ~45–50% com altura limitada (≥700 px) comporta um quadrado sem cortar rótulos. No celular, o mesmo quadrado entra na largura total entre os blocos de texto sem ocupar a tela inteira. 16:9 ficaria pequeno na coluna; 9:16 ultrapassaria a altura do sticky.

## Identidade

- Cores: Brandbook Grupo CRED MHS 2021, p. 28 — amarelo `#FFCA00` (Pantone 116 C) e preto 100%. Amarelo só no centro (anel de convergência) e no logotipo; nenhum nó de aspecto fica amarelo.
- Logo: `assets/brand/logo_nova.svg` sem alterações de forma; `public/logo-negativo.svg` só troca o preto `#1E1D1D` por branco, como a "marca em negativo sobre fundos escuros" do brandbook (p. 39).
- Fonte: Sommet Rounded (brandbook p. 35), arquivos .otf copiados para `public/fonts/` e carregados por `FontFace` + `staticFile` (`src/fonts.ts`).

## Comandos (rodar dentro de `remotion/`)

```bash
npm install
npm run studio        # preview no Remotion Studio
npm run render:mp4    # ../public/media/m06/m06-gestao.mp4  (H.264 High, CRF 21, yuv420p BT.709 faixa limitada, sem áudio)
npm run render:webm   # ../public/media/m06/m06-gestao.webm (VP9 perfil 0, CRF 32, yuv420p BT.709 faixa limitada, sem áudio)
npm run render:poster # ../public/media/m06/m06-gestao-poster.png (quadro 360, conjunto formado)
npm run render        # os três acima
# poster WebP (usa ffmpeg do sistema):
ffmpeg -y -i ../public/media/m06/m06-gestao-poster.png -c:v libwebp -quality 86 ../public/media/m06/m06-gestao-poster.webp
```

Os dois renders **precisam** de `--pixel-format yuv420p --color-space bt709` (já nos scripts). Sem isso o Remotion grava faixa de cor "full" (yuvj420p / `color_range=pc`), e o WebM VP9 resultante falha no decodificador de hardware do Chrome/Edge no Windows (`PIPELINE_ERROR_DECODE`, erro 3). Conferir após render:

```bash
ffprobe -v error -show_entries stream=codec_name,profile,pix_fmt,color_range,color_space -of compact ../public/media/m06/m06-gestao.mp4 ../public/media/m06/m06-gestao.webm
# esperado: pix_fmt=yuv420p, color_range=tv, color_space=bt709
```

Verificação: `npx remotion still src/index.ts M06Gestao out/check.png --frame <n> --overwrite`.

## Uso na página (orientação)

- `<video muted playsinline preload="none" poster="/media/m06/m06-gestao-poster.webp">` com `<source>` MP4 (primeiro) e WebM, `type` com `codecs`, fallback manual para a outra fonte e, se ambas falharem, poster estático sem botão, dimensões reservadas (aspect-ratio 1/1).
- `loop`: toca enquanto está em vista e pausa fora dela; botão pausar/reproduzir (movimento contínuo exige pausa, WCAG 2.2.2); sem autoplay em `prefers-reduced-motion` — mostrar só o poster.
- Legenda HTML: "Visão conceitual das capacidades de gestão" (docs/02).
- O poster é o quadro do conjunto formado; o vídeo não carrega informação exclusiva.
