import React from "react";
import { Composition } from "remotion";
import { M06Gestao } from "./M06Gestao";
import { video } from "./theme";

export const RemotionRoot: React.FC = () => (
  <Composition
    id="M06Gestao"
    component={M06Gestao}
    durationInFrames={Math.round(video.seconds * video.fps)}
    fps={video.fps}
    width={video.size}
    height={video.size}
  />
);
