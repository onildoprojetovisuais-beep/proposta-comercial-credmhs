import { useEffect, useRef, useState } from 'react';
import { Button, ChapterNavigation, Dialog, scrollToChapter } from '../components/ui';
import M01Encontro from '../components/sections/M01Encontro';
import M02Prioridades from '../components/sections/M02Prioridades';
import M03Capacidade from '../components/sections/M03Capacidade';
import M04ProvaSocial from '../components/sections/M04ProvaSocial';
import M05Ecossistema from '../components/sections/M05Ecossistema';
import M06GestaoEmMovimento from '../components/sections/M06GestaoEmMovimento';
import M07Aplicacoes from '../components/sections/M07Aplicacoes';
import M08Referencias from '../components/sections/M08Referencias';
import M09Pauta from '../components/sections/M09Pauta';
import M10Continuidade from '../components/sections/M10Continuidade';
import { copy } from '../content';
import { formatTemplate } from '../lib';
import { usePresentationState } from '../state';
import { CHAPTER_IDS, CHAPTER_INDEX } from './chapterIndex';
import { useCurrentChapter } from './useCurrentChapter';
import styles from './App.module.css';

const g = copy.global;

/**
 * Composição da página: skip link, header (logo + índice + "Sua pauta (n)" + "Nova apresentação"),
 * M01–M10, footer. Montada por PresentationRoot depois que o executivo foi resolvido.
 * "Nova apresentação" (reset, docs/03): confirmação → limpa a sessão (store.reset) →
 * `key={resetCount}` remonta as seções (estados locais voltam ao início) → rola até M01 e move
 * o foco para o início. O executivo da URL continua o mesmo.
 */
export default function App() {
  const current = useCurrentChapter(CHAPTER_IDS);
  const { state, topicCount, actions } = usePresentationState();
  const [confirmOpen, setConfirmOpen] = useState(false);
  const lastReset = useRef(state.resetCount);
  // Destino do foco quando o diálogo fecha após um reset (o acionador no índice foi remontado).
  const resetFocusRef = useRef<HTMLElement | null>(null);

  // Depois do reset: as seções já foram remontadas; volta à M01 e foca o início.
  useEffect(() => {
    if (state.resetCount === lastReset.current) return;
    lastReset.current = state.resetCount;
    resetFocusRef.current = document.getElementById('m01');
    scrollToChapter('m01', { instant: true });
  }, [state.resetCount]);

  const openConfirm = () => {
    resetFocusRef.current = null; // cancelar devolve o foco ao botão "Nova apresentação"
    setConfirmOpen(true);
  };

  const confirmReset = () => {
    actions.reset();
    setConfirmOpen(false);
  };

  const counterLabel = formatTemplate(g.agendaCounterTemplate, { count: topicCount });
  const counterShort = formatTemplate(g.agendaCounterShortTemplate, { count: topicCount });

  return (
    <>
      <a className="skip-link" href="#conteudo">
        {g.skipLink}
      </a>

      <header className={styles.header}>
        <div className={`container ${styles.headerInner}`}>
          <a
            className={styles.brand}
            href="#m01"
            aria-label="CRED MHS — início da apresentação"
            onClick={(e) => {
              e.preventDefault();
              scrollToChapter('m01');
            }}
          >
            <img
              src="/brand/cred-mhs-logo.svg"
              alt="CRED MHS — Saúde e Segurança do Trabalho"
              width={1600}
              height={481}
              className={styles.logo}
            />
          </a>
          <ChapterNavigation
            key={state.resetCount}
            chapters={CHAPTER_INDEX}
            currentId={current}
            menuLabel={g.menu}
            status={
              <a
                href="#m09"
                className={styles.agendaLink}
                data-count={topicCount}
                onClick={(e) => {
                  e.preventDefault();
                  scrollToChapter('m09');
                }}
              >
                <span className={styles.agendaDot} aria-hidden="true" />
                <span className={styles.agendaFull}>{counterLabel}</span>
                <span className={styles.agendaShort} aria-hidden="true">
                  {counterShort}
                </span>
              </a>
            }
            actions={
              <button type="button" className={styles.resetButton} onClick={openConfirm}>
                <span aria-hidden="true" className={styles.resetIcon}>
                  ↺
                </span>
                {g.reset.label}
              </button>
            }
          />
        </div>
      </header>

      <main id="conteudo" tabIndex={-1} className={styles.main} key={state.resetCount}>
        <M01Encontro />
        <M02Prioridades />
        <M03Capacidade />
        <M04ProvaSocial />
        <M05Ecossistema />
        <M06GestaoEmMovimento />
        <M07Aplicacoes />
        <M08Referencias />
        <M09Pauta />
        <M10Continuidade />
      </main>

      <Dialog
        open={confirmOpen}
        onClose={() => setConfirmOpen(false)}
        title={g.reset.label}
        description={g.reset.confirm}
        size="sm"
        closeLabel={g.close}
        returnFocusRef={resetFocusRef}
        footer={
          <>
            <Button variant="secondary" onClick={() => setConfirmOpen(false)}>
              {g.reset.cancelAction}
            </Button>
            <Button variant="danger" onClick={confirmReset}>
              {g.reset.confirmAction}
            </Button>
          </>
        }
      />

      <footer className={styles.footer} data-surface="dark">
        <div className={`container ${styles.footerInner}`}>
          <img
            src="/brand/cred-mhs-logo-negativo.svg"
            alt="CRED MHS — Saúde e Segurança do Trabalho"
            width={1600}
            height={481}
            loading="lazy"
            className={styles.footerLogo}
          />
          <p className={styles.footerText}>{copy.m01.brandDescriptor}</p>
        </div>
      </footer>
    </>
  );
}
