import type { ChapterNavItem, SectionId } from '../components/ui';
import { chapterFromHash, chapters } from '../content';

/**
 * Índice derivado de src/content/chapters.ts (fonte única dos rótulos de docs/02,
 * "Navegação e estados globais"). Ordem = ordem da página.
 */
export const CHAPTER_INDEX: ChapterNavItem[] = chapters.map((c) => ({ id: c.id, label: c.navLabel }));

export const CHAPTER_IDS: SectionId[] = CHAPTER_INDEX.map((c) => c.id);

/**
 * Resolve o hash da URL para o ID da seção. Aceita o ID do capítulo (#m03, usado pelo índice)
 * e o slug editorial de src/content (#estrutura). Desconhecido → null.
 */
export function sectionIdFromHash(hash: string): SectionId | null {
  const raw = hash.replace(/^#/, '').trim().toLowerCase();
  if ((CHAPTER_IDS as string[]).includes(raw)) return raw as SectionId;
  return chapterFromHash(hash)?.id ?? null;
}
