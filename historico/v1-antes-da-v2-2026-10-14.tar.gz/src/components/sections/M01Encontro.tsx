import { useState } from 'react';
import { Button, IconArrow, SectionShell, scrollToChapter, sectionTitleId } from '../ui';
import { copy } from '../../content';
import { formatTemplate } from '../../lib';
import { usePresentationState } from '../../state';
import styles from './m01/M01Encontro.module.css';

const c = copy.m01;

/**
 * Fontes otimizadas do retrato do projeto (`photoSource: 'bundled'`), derivadas do caminho do
 * perfil. Foto do Supabase (`remote`) já chega otimizada pelo painel: um único arquivo.
 */
function portraitSources(photo: string) {
  const base = photo.replace(/\.(png|jpe?g|webp|avif)$/i, '');
  // Só o perfil documentado tem derivados gerados (public/media/executives/*-640/-1098).
  const known = base.endsWith('/sabrina-ferreira');
  if (!known) return null;
  return {
    avif: `${base}-640.avif 640w, ${base}-1098.avif 1098w`,
    webp: `${base}-640.webp 640w, ${base}-1098.webp 1098w`,
    fallback: `${base}-1098.jpg`,
  };
}

/**
 * M01 — Encontro com o executivo. Título, nome, cargo e retrato vêm do perfil resolvido
 * por `?executivo=` (local ou Supabase). Sem captura de dados.
 * Se o retrato remoto falhar ao carregar, a seção cai no layout tipográfico (sem foto).
 */
export default function M01Encontro() {
  const { executive } = usePresentationState();
  const [failedPhoto, setFailedPhoto] = useState<string | null>(null);
  const title = formatTemplate(c.titleTemplate, { firstName: executive.firstName });
  const photo = executive.photo && executive.photo !== failedPhoto ? executive.photo : null;
  const sources = photo && executive.photoSource === 'bundled' ? portraitSources(photo) : null;
  const sizes = '(min-width: 1024px) 40vw, 100vw';

  return (
    <SectionShell id="m01" title={title} header={false} width="full" spacing="none" className={styles.section}>
      <div className={`container ${styles.grid}`} data-has-photo={!!photo}>
        {photo ? (
          <figure className={styles.portrait}>
            <span className={styles.sun} aria-hidden="true" />
            <picture>
              {sources ? <source type="image/avif" srcSet={sources.avif} sizes={sizes} /> : null}
              {sources ? <source type="image/webp" srcSet={sources.webp} sizes={sizes} /> : null}
              <img
                src={sources?.fallback ?? photo}
                alt={executive.photoAlt}
                width={executive.photoWidth ?? 1098}
                height={executive.photoHeight ?? 1433}
                {...{ fetchpriority: 'high' }}
                decoding="async"
                className={styles.photo}
                onError={() => setFailedPhoto(photo)}
              />
            </picture>
          </figure>
        ) : null}

        <div className={styles.text}>
          <p className={styles.identity}>
            <span className={styles.name}>{formatTemplate(c.eyebrowTemplate, { fullName: executive.fullName })}</span>
            <span className={styles.role}>{formatTemplate(c.roleTemplate, { role: executive.role })}</span>
          </p>
          <h1 id={sectionTitleId('m01')} className={`t-display ${styles.title}`}>
            {title}
          </h1>
          <p className={`t-lead ${styles.lead}`}>{c.body}</p>
          <div className={styles.actions}>
            <Button
              href="#m02"
              size="lg"
              iconAfter={<IconArrow />}
              onClick={(e) => {
                e.preventDefault();
                scrollToChapter('m02');
              }}
            >
              {c.cta}
            </Button>
          </div>
          <p className={styles.brandLine}>
            <strong>{c.brand}</strong> — {c.brandDescriptor}
          </p>
        </div>
      </div>
    </SectionShell>
  );
}
