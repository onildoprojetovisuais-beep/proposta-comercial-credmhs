import { useId, useRef, useState } from 'react';
import { Button, IconArrow, IconCheck, IconChevron, IconPlus, SectionShell, scrollToChapter } from '../ui';
import { chapterById, copy, MAX_PRIORITIES, priorities } from '../../content';
import { COMPANY_NAME_MAX, formatTemplate } from '../../lib';
import type { PriorityId } from '../../types';
import { usePresentationState } from '../../state';
import styles from './m02/M02Prioridades.module.css';

const c = copy.m02;

/**
 * M02 — Prioridades do visitante. Até duas escolhas (ordem preservada), limite com microcopy,
 * nome opcional da empresa, "Continuar" (com ou sem escolhas) e "Conhecer a atuação completa".
 * Nada avança automaticamente ao selecionar.
 */
export default function M02Prioridades() {
  const { state, actions, executive } = usePresentationState();
  const [companyOpen, setCompanyOpen] = useState(() => state.companyName.trim().length > 0);
  const companyPanelId = useId();
  const inputId = useId();
  const helpId = useId();
  const feedbackRef = useRef<HTMLDivElement>(null);
  const selected = state.priorities;
  const count = selected.length;

  // 3ª escolha recusada: o aviso fica logo abaixo da lista e é trazido à vista (consequência
  // direta do toque — sem salto de página em outros casos).
  const onPick = (id: PriorityId) => {
    const r = actions.togglePriority(id);
    if (r === 'limit') {
      requestAnimationFrame(() => feedbackRef.current?.scrollIntoView({ block: 'nearest', behavior: 'smooth' }));
    }
  };

  return (
    <SectionShell
      id="m02"
      eyebrow={chapterById.m02.navLabel}
      title={c.title}
      intro={<p>{c.body}</p>}
      surface="white"
      className={styles.section}
    >
      <div className={styles.layout}>
        <fieldset className={styles.choice}>
          <legend className={styles.legend}>
            <span className={`t-h3 ${styles.question}`}>{c.question}</span>
            <span className={styles.instruction}>{c.instruction}</span>
          </legend>
          <p className={styles.agendaHint}>{formatTemplate(c.agendaHintTemplate, { firstName: executive.firstName })}</p>

          <ul className={styles.options} role="list">
            {priorities.map((p, i) => {
              const order = selected.indexOf(p.id);
              const isOn = order >= 0;
              return (
                <li key={p.id}>
                  <button
                    type="button"
                    className={`row-selectable ${styles.option}`}
                    aria-pressed={isOn}
                    onClick={() => onPick(p.id)}
                  >
                    <span className={styles.optionNum} aria-hidden="true">
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    <span className={styles.optionLabel}>{p.label}</span>
                    <span className={styles.optionState} aria-hidden="true">
                      {isOn ? (
                        <>
                          <IconCheck />
                          <span>{order + 1}ª</span>
                        </>
                      ) : (
                        <IconPlus />
                      )}
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>

          {/* Região de anúncio: limite e confirmação (docs/02). */}
          <div ref={feedbackRef} className={styles.feedback} aria-live="polite" role="status">
            {state.priorityLimitReached && count >= MAX_PRIORITIES ? (
              <p className={styles.limit}>
                <span className={styles.limitMark} aria-hidden="true">!</span>
                {c.limitMessage}
              </p>
            ) : count > 0 ? (
              <p className={styles.confirm}>
                <span className={styles.confirmMark} aria-hidden="true">
                  <IconCheck />
                </span>
                {c.confirmation}
              </p>
            ) : null}
          </div>
        </fieldset>

        <div className={`panel-read ${styles.side}`}>
          <div className={styles.company}>
            <button
              type="button"
              className={styles.companyToggle}
              aria-expanded={companyOpen}
              aria-controls={companyPanelId}
              onClick={() => setCompanyOpen((v) => !v)}
            >
              {c.company.toggleLabel}
              <span className={styles.companyMarker} aria-hidden="true">
                <IconChevron open={companyOpen} />
              </span>
            </button>
            <div id={companyPanelId} hidden={!companyOpen} className={`field-group ${styles.companyPanel}`}>
              <label htmlFor={inputId} className="field-label">
                {c.company.fieldLabel}
              </label>
              <input
                id={inputId}
                type="text"
                className="field"
                value={state.companyName}
                maxLength={COMPANY_NAME_MAX}
                placeholder={c.company.placeholder}
                autoComplete="organization"
                spellCheck={false}
                aria-describedby={helpId}
                onChange={(e) => actions.setCompanyName(e.target.value)}
              />
              <p id={helpId} className="field-hint">
                {c.company.help}
              </p>
            </div>
          </div>

          <div className={styles.next}>
            <p className={`t-h3 ${styles.transition}`}>{c.transition}</p>
            <div className={styles.nextActions}>
              <Button
                href="#m03"
                iconAfter={<IconArrow />}
                onClick={(e) => {
                  e.preventDefault();
                  scrollToChapter('m03');
                }}
              >
                {c.cta}
              </Button>
              <Button
                variant="link"
                onClick={() => {
                  actions.clearPriorities();
                  scrollToChapter('m03');
                }}
              >
                {c.alternative}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </SectionShell>
  );
}
