import { useEffect, useId, useState } from 'react';
import { Button, IconChevron, SectionShell } from '../ui';
import { capacityFacts, chapterById, copy, reachText } from '../../content';
import { usePresentationState } from '../../state';
import styles from './m03/M03Capacidade.module.css';

const c = copy.m03;

/**
 * M03 — Capacidade. Indicadores do slide 17 com qualificadores literais (só `displayPolicy: 'show'`,
 * já filtrado em `capacityFacts`), alcance textual (fallback do dado territorial) e
 * "Conhecer a estrutura" (equipe, recursos próprios, atendimento na empresa).
 * Detalhes ligados às prioridades recebem marcação editorial; nenhum fica oculto.
 */
export default function M03Capacidade() {
  const { highlights } = usePresentationState();
  const [open, setOpen] = useState(false);
  const panelId = useId();
  const highlighted = new Set<string>(highlights.capacityDetails);
  const highlightKey = highlights.capacityDetails.join('|');

  // Prioridade ligada a um detalhe de estrutura → o detalhe fica visível, marcado (sem ocultar os demais).
  useEffect(() => {
    if (highlightKey) setOpen(true);
  }, [highlightKey]);

  return (
    <SectionShell
      id="m03"
      eyebrow={chapterById.m03.navLabel}
      title={c.title}
      intro={<p>{c.body}</p>}
      surface="dark"
      className={styles.section}
      headerAside={
        <p className={`t-h3 ${styles.reach}`}>
          <span className={styles.reachLine} aria-hidden="true" />
          <span className={styles.reachText}>{reachText}</span>
        </p>
      }
    >
      <div className={styles.evidence}>
        <dl className={styles.facts}>
          {capacityFacts.map((f) => (
            <div key={f.id} className={styles.fact}>
              <dt className={styles.qualifier}>{f.qualifier}</dt>
              <dd className={`t-number ${styles.value}`}>{f.value}</dd>
            </div>
          ))}
        </dl>
      </div>

      <div className={styles.structure}>
        <Button
          variant="link"
          aria-expanded={open}
          aria-controls={panelId}
          onClick={() => setOpen((v) => !v)}
          iconAfter={<IconChevron open={open} />}
          className={styles.structureToggle}
        >
          {c.cta}
        </Button>

        <div id={panelId} hidden={!open} className={styles.details}>
          <ul role="list" className={styles.detailList}>
            {c.details.map((d, i) => {
              const isHighlighted = highlighted.has(d.id);
              return (
                <li key={d.id} className={styles.detail} data-highlight={isHighlighted}>
                  <span className={styles.detailNum} aria-hidden="true">
                    {String(i + 1).padStart(2, '0')}
                  </span>
                  <h3 className={`t-h4 ${styles.detailTitle}`}>{d.label}</h3>
                  {isHighlighted ? (
                    <p className={styles.badgeRow}>
                      <span className="badge badge--priority">{copy.m05.priorityBadge}</span>
                    </p>
                  ) : null}
                  <p className={`t-body ${styles.detailText}`}>{d.text}</p>
                </li>
              );
            })}
          </ul>
        </div>
      </div>

      <p className={styles.transition}>{c.transition}</p>
    </SectionShell>
  );
}
