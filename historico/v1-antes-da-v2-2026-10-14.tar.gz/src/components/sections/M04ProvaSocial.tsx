import { useId, useState } from 'react';
import type { CSSProperties } from 'react';
import { Button, IconChevron, SectionShell } from '../ui';
import { chapterById, copy, featuredClients, otherClients } from '../../content';
import type { Client } from '../../types';
import { CLIENT_LOGO_BY_ID, clientLogoSrc } from './m04/clientLogos';
import styles from './m04/M04ProvaSocial.module.css';

const c = copy.m04;

/** Marca com proporção preservada e área visual equilibrada; sem arquivo conciliado → nome em texto. */
function ClientMark({ client }: { client: Client }) {
  const logo = CLIENT_LOGO_BY_ID[client.id];
  if (!logo) {
    return <span className={styles.nameFallback}>{client.name}</span>;
  }
  const [x, y, cw, ch] = logo.crop;
  const ratio = cw / ch;
  const cropStyle = { '--r': ratio, '--s': 1 / Math.sqrt(ratio) } as CSSProperties;
  const imgStyle: CSSProperties = {
    width: `${(logo.w / cw) * 100}%`,
    height: `${(logo.h / ch) * 100}%`,
    left: `${(-x / cw) * 100}%`,
    top: `${(-y / ch) * 100}%`,
  };
  return (
    <span className={styles.crop} style={cropStyle}>
      <img
        src={clientLogoSrc(logo)}
        alt={client.name}
        width={logo.w}
        height={logo.h}
        loading="lazy"
        decoding="async"
        className={styles.logo}
        style={imgStyle}
      />
    </span>
  );
}

/**
 * M04 — Prova social. Seleção inicial (src/content) + relação completa sob demanda.
 * Linguagem de percurso: sem cases, resultados ou depoimentos a partir de logotipos.
 */
export default function M04ProvaSocial() {
  const [expanded, setExpanded] = useState(false);
  const listId = useId();

  return (
    <SectionShell
      id="m04"
      eyebrow={chapterById.m04.navLabel}
      title={c.title}
      intro={<p>{c.body}</p>}
      surface="paper"
    >
      <ul role="list" className={`panel-read ${styles.featured}`}>
        {featuredClients.map((client) => (
          <li key={client.id} className={styles.plate}>
            <ClientMark client={client} />
          </li>
        ))}
      </ul>

      <div className={styles.more}>
        <Button
          variant="link"
          aria-expanded={expanded}
          aria-controls={listId}
          onClick={() => setExpanded((v) => !v)}
          iconAfter={<IconChevron open={expanded} />}
        >
          {expanded ? c.collapse : c.cta}
        </Button>
      </div>

      <ul id={listId} role="list" hidden={!expanded} className={`panel-read ${styles.featured} ${styles.others}`}>
        {otherClients.map((client) => (
          <li key={client.id} className={`${styles.plate} ${styles.plateSmall}`}>
            <ClientMark client={client} />
          </li>
        ))}
      </ul>
    </SectionShell>
  );
}
