import { useCallback, useId, useRef, useState } from 'react';
import { Button, IconCheck, IconChevron, IconPlus, SectionShell, TopicToggle } from '../ui';
import { additionalServices, additionalServicesCopy, chapterById, copy, serviceAreas } from '../../content';
import { formatTemplate } from '../../lib';
import type { ServiceArea, ServiceAreaId, TopicId } from '../../types';
import { usePresentationState } from '../../state';
import { useMediaQuery } from './m05/useMediaQuery';
import { M05_ADDITIONAL_ID } from './m05/ids';
import styles from './m05/M05Ecossistema.module.css';

const c = copy.m05;
const DESKTOP = '(min-width: 1024px)';


/** Microcopy nova (P21): anúncio discreto da pauta — mesmo vocabulário em M05, M06, M07 e M09. */
const announceText = (label: string, added: boolean) =>
  `${label} ${added ? 'adicionado à pauta' : 'removido da pauta'}.`;

interface RowProps {
  topicId: TopicId;
  label: string;
  selected: boolean;
  onToggle: (id: TopicId, label: string) => void;
}

/**
 * Linha do catálogo adicional (layout v2): .row-selectable + data-selected na linha, ação explícita
 * no TopicToggle (aria-pressed, nome acessível com o assunto). Clique na linha = atalho de ponteiro
 * para o mesmo toggle; teclado usa o botão.
 */
function AdditionalRow({ topicId, label, selected, onToggle }: RowProps) {
  return (
    <div
      className={`row-selectable ${styles.additionalRow}`}
      data-selected={selected}
      onClick={(e) => {
        if ((e.target as HTMLElement).closest('button')) return;
        onToggle(topicId, label);
      }}
    >
      <span className={`t-body ${styles.additionalLabel}`}>{label}</span>
      <TopicToggle
        selected={selected}
        onToggle={() => onToggle(topicId, label)}
        subject={label}
        addLabel={c.controls.add}
        removeLabel={c.controls.remove}
        compact
      />
    </div>
  );
}

interface AreaDetailProps {
  area: ServiceArea;
  servicesOpen: boolean;
  onToggleServices: () => void;
  selected: boolean;
  isPriority: boolean;
  onToggleTopic: (id: TopicId, label: string) => void;
  /** No desktop o título da frente fica no painel; no mobile ele já está no botão do acordeão. */
  showHeading: boolean;
  headingId: string;
}

function AreaDetail({
  area,
  servicesOpen,
  onToggleServices,
  selected,
  isPriority,
  onToggleTopic,
  showHeading,
  headingId,
}: AreaDetailProps) {
  const servicesId = useId();
  const textExtras = (area.extras ?? []).filter((e) => e.text || e.items?.length);
  const ctaLabel = area.extras?.find((e) => e.ctaLabel)?.ctaLabel ?? c.controls.showServices;
  // Mobile: a frente é o botão do acordeão (sem h3); os subtítulos sobem um nível para manter a ordem.
  const Sub = showHeading ? 'h4' : 'h3';

  return (
    <div className={styles.detail}>
      {showHeading ? (
        <div className={styles.detailHead}>
          {isPriority ? (
            <p className={styles.badgeRow}>
              <span className="badge badge--priority">{c.priorityBadge}</span>
            </p>
          ) : null}
          <h3 id={headingId} className={`t-h2 ${styles.detailTitle}`}>
            {area.label}
          </h3>
        </div>
      ) : null}
      <p className={`t-body ${styles.summary}`}>{area.summary}</p>
      <p className={`t-body ${styles.detailBody}`}>{area.detail}</p>

      {textExtras.map((e, i) => (
        <div key={i} className={styles.extra}>
          {e.label ? <Sub className={styles.extraLabel}>{e.label}</Sub> : null}
          {e.text ? <p>{e.text}</p> : null}
          {e.items?.length ? (
            <ul className={styles.extraItems}>
              {e.items.map((it) => (
                <li key={it}>{it}</li>
              ))}
            </ul>
          ) : null}
        </div>
      ))}

      <div className={styles.detailActions}>
        <TopicToggle
          selected={selected}
          onToggle={() => onToggleTopic(area.topicId, area.label)}
          subject={area.label}
          addLabel={c.controls.add}
          removeLabel={c.controls.remove}
        />
        <Button
          variant="link"
          aria-expanded={servicesOpen}
          aria-controls={servicesId}
          onClick={onToggleServices}
          iconAfter={<IconChevron open={servicesOpen} />}
        >
          {servicesOpen ? c.controls.hideServices : ctaLabel}{' '}
          <span className={styles.servicesCount}>({area.services.length})</span>
        </Button>
      </div>

      <div id={servicesId} hidden={!servicesOpen} className={styles.services}>
        <Sub className={styles.servicesLabel}>{area.servicesLabel}</Sub>
        <ul className={styles.serviceList}>
          {area.services.map((s) => (
            <li key={s}>{s}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}

/**
 * M05 — Exploração do ecossistema. Frente inicial = 1ª prioridade (ou Saúde Ocupacional);
 * troca manual prevalece (store). Conhecer uma frente não a adiciona à pauta.
 * Desktop: seletor sticky + painel editorial. Mobile: acordeões no fluxo.
 */
export default function M05Ecossistema() {
  const { activeArea, highlights, isTopicSelected, actions, executive } = usePresentationState();
  const isDesktop = useMediaQuery(DESKTOP);
  const [mobileOpen, setMobileOpen] = useState(true);
  const [servicesOpen, setServicesOpen] = useState<Partial<Record<ServiceAreaId, boolean>>>({});
  const [announcement, setAnnouncement] = useState('');
  const itemRefs = useRef<Partial<Record<ServiceAreaId, HTMLButtonElement | null>>>({});
  const baseId = useId();
  const priorityAreas = new Set<string>(highlights.areas);

  const onToggleTopic = useCallback(
    (id: TopicId, label: string) => {
      const r = actions.toggleTopic(id);
      if (r === 'added' || r === 'removed') setAnnouncement(announceText(label, r === 'added'));
    },
    [actions],
  );

  const selectArea = (id: ServiceAreaId) => {
    if (isDesktop) {
      actions.setActiveArea(id);
      return;
    }
    if (id === activeArea) {
      setMobileOpen((v) => !v);
      return;
    }
    actions.setActiveArea(id);
    setMobileOpen(true);
    // A frente anterior recolhe; mantém o botão escolhido visível.
    requestAnimationFrame(() => {
      const el = itemRefs.current[id];
      if (!el) return;
      const top = el.getBoundingClientRect().top;
      const header = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--header-h')) || 64;
      if (top < header + 8) el.scrollIntoView({ block: 'start' });
    });
  };

  const toggleServices = (id: ServiceAreaId) => setServicesOpen((s) => ({ ...s, [id]: !s[id] }));
  const active = serviceAreas.find((a) => a.id === activeArea) ?? serviceAreas[0];
  const panelId = `${baseId}-painel`;
  const panelHeadingId = `${baseId}-titulo-frente`;

  return (
    <SectionShell
      id="m05"
      eyebrow={chapterById.m05.navLabel}
      title={c.title}
      intro={<p>{c.body}</p>}
      surface="white"
    >
      <p className="visually-hidden" aria-live="polite" role="status">
        {announcement}
      </p>

      {/* Explicada uma única vez (P21); os itens repetem só o rótulo do botão. */}
      <p className={styles.addHint}>
        <span className={styles.addHintMark} aria-hidden="true">
          <IconPlus />
        </span>
        <span>{formatTemplate(c.addHintTemplate, { firstName: executive.firstName })}</span>
      </p>

      <div className={styles.explorer} data-mode={isDesktop ? 'desktop' : 'mobile'}>
        <ol className={styles.areas} role="list">
          {serviceAreas.map((area, i) => {
            const isActive = area.id === active.id;
            const isOpen = isActive && (isDesktop || mobileOpen);
            const itemPanelId = isDesktop ? panelId : `${baseId}-${area.id}`;
            return (
              <li key={area.id} className={styles.area} data-active={isActive}>
                <button
                  ref={(el) => {
                    itemRefs.current[area.id] = el;
                  }}
                  type="button"
                  className={`row-expandable ${styles.areaButton}`}
                  aria-expanded={isOpen}
                  aria-controls={itemPanelId}
                  onClick={() => selectArea(area.id)}
                >
                  <span className={styles.areaNum} aria-hidden="true">
                    {String(i + 1).padStart(2, '0')}
                  </span>
                  <span className={styles.areaText}>
                    <span className={styles.areaLabel}>{area.label}</span>
                    {priorityAreas.has(area.id) || isTopicSelected(area.topicId) ? (
                      <span className={styles.areaBadges}>
                        {priorityAreas.has(area.id) ? (
                          <span className="badge badge--priority">
                            <span className="visually-hidden">, </span>
                            {c.priorityBadge}
                          </span>
                        ) : null}
                        {isTopicSelected(area.topicId) ? (
                          <span className="badge badge--agenda">
                            <IconCheck />
                            <span className="visually-hidden">, </span>
                            Na pauta
                          </span>
                        ) : null}
                      </span>
                    ) : null}
                  </span>
                  <span className={styles.areaMarker} aria-hidden="true">
                    <IconChevron open={isDesktop ? undefined : isOpen} direction={isDesktop ? 'right' : 'down'} />
                  </span>
                </button>
                {!isDesktop ? (
                  <div id={itemPanelId} hidden={!isOpen} className={styles.mobilePanel}>
                    <AreaDetail
                      area={area}
                      servicesOpen={!!servicesOpen[area.id]}
                      onToggleServices={() => toggleServices(area.id)}
                      selected={isTopicSelected(area.topicId)}
                      isPriority={priorityAreas.has(area.id)}
                      onToggleTopic={onToggleTopic}
                      showHeading={false}
                      headingId={`${itemPanelId}-h`}
                    />
                  </div>
                ) : null}
              </li>
            );
          })}
        </ol>

        {isDesktop ? (
          <div id={panelId} className={`panel-read ${styles.panel}`} role="region" aria-labelledby={panelHeadingId} key={active.id}>
            <AreaDetail
              area={active}
              servicesOpen={!!servicesOpen[active.id]}
              onToggleServices={() => toggleServices(active.id)}
              selected={isTopicSelected(active.topicId)}
              isPriority={priorityAreas.has(active.id)}
              onToggleTopic={onToggleTopic}
              showHeading
              headingId={panelHeadingId}
            />
          </div>
        ) : null}
      </div>

      <section id={M05_ADDITIONAL_ID} className={styles.additional} aria-labelledby={`${M05_ADDITIONAL_ID}-titulo`} tabIndex={-1}>
        <div className={styles.additionalHead}>
          <h3 id={`${M05_ADDITIONAL_ID}-titulo`} className="t-h3">
            {additionalServicesCopy.title}
          </h3>
          <p className={`t-body ${styles.additionalBody}`}>{additionalServicesCopy.body}</p>
        </div>
        <ul className={styles.additionalList} role="list">
          {additionalServices.map((s) => {
            const sel = isTopicSelected(s.topicId);
            return (
              <li key={s.id} className={styles.additionalItem}>
                <AdditionalRow topicId={s.topicId} label={s.label} selected={sel} onToggle={onToggleTopic} />
              </li>
            );
          })}
        </ul>
      </section>
    </SectionShell>
  );
}
