import { useRef, useState } from 'react';
import type { CSSProperties, MouseEvent } from 'react';
import { Accordion, Button, IconArrow, SectionShell, TopicToggle, scrollToChapter } from '../ui';
import { copy, priorityById, serviceAreas } from '../../content';
import { usePresentationState } from '../../state';
import { M06Media } from './m06/M06Media';
import { useM06Scroll } from './m06/useM06Scroll';
import { useReducedMotion } from './m06/useReducedMotion';
import styles from './m06/M06.module.css';

const m06 = copy.m06;
const gestaoArea = serviceAreas.find((a) => a.id === 'gestao');

/**
 * M06 — Gestão em movimento.
 * Desktop (≥1024×700, sem reduced motion): palco sticky com a mídia 1:1 e os três aspectos, que
 * avançam pelo scroll nativo (ScrollTrigger lê o progresso; não há pin nem interceptação de rolagem).
 * Mobile/zoom alto/reduced motion: sequência no fluxo, mídia em largura total, poster estático em
 * reduced motion. Todo o texto fica sempre no HTML e legível — a fase ativa só muda a ênfase.
 */
export default function M06GestaoEmMovimento() {
  const { highlights, isTopicSelected, actions } = usePresentationState();
  const reducedMotion = useReducedMotion();
  const trackRef = useRef<HTMLDivElement>(null);
  const aspects = m06.aspects;
  const { enhanced, phase, goToPhase } = useM06Scroll(trackRef, aspects.length);
  const [announce, setAnnounce] = useState('');

  const isPriority = highlights.chapters.includes('m06');
  const topicId = gestaoArea?.topicId;
  const selected = topicId ? isTopicSelected(topicId) : false;

  const goToApplications = (e: MouseEvent<HTMLAnchorElement | HTMLButtonElement>) => {
    e.preventDefault();
    scrollToChapter('m07');
  };

  const toggleTopic = () => {
    if (!topicId || !gestaoArea) return;
    actions.toggleTopic(topicId);
    setAnnounce(
      selected
        ? `${gestaoArea.label} removido da pauta.`
        : `${gestaoArea.label} adicionado à pauta.`,
    );
  };

  // Saída única do trecho sticky (docs/04): fica no cabeçalho, antes da animação.
  const shortcut = (
    <Button href="#m07" variant="link" onClick={goToApplications} iconAfter={<IconArrow />}>
      {m06.shortcut}
    </Button>
  );

  return (
    <SectionShell
      id="m06"
      eyebrow="Gestão e tecnologia"
      title={m06.title}
      intro={m06.body}
      surface="dark"
      width="wide"
      className={styles.section}
      headerAside={shortcut}
    >
      {isPriority ? (
        <p className={styles.priorityRow}>
          <span className="badge badge--priority">
            {copy.m05.priorityBadge}: {priorityById.gestao.label}
          </span>
        </p>
      ) : null}

      <div ref={trackRef} className={styles.track} data-enhanced={enhanced ? 'true' : undefined}>
        <div className={styles.stage}>
          <div className={styles.mediaCol}>
            <M06Media caption={m06.mediaCaption} reducedMotion={reducedMotion} />
          </div>

          <div className={styles.textCol}>
            {enhanced ? (
              <nav className={styles.controls} aria-label="Aspectos de gestão e tecnologia">
                <ol className={styles.controlList}>
                  {aspects.map((a, i) => (
                    <li key={a.id}>
                      <button
                        type="button"
                        className={styles.control}
                        aria-current={phase === i ? 'step' : undefined}
                        aria-controls={`m06-aspecto-${a.id}`}
                        onClick={() => goToPhase(i)}
                      >
                        <span className={styles.controlBar} aria-hidden="true">
                          <span
                            className={styles.controlFill}
                            style={{ ['--i' as string]: i } as CSSProperties}
                          />
                        </span>
                        <span className={styles.controlLabel}>{a.label}</span>
                      </button>
                    </li>
                  ))}
                </ol>
              </nav>
            ) : null}

            <ol className={styles.aspects}>
              {aspects.map((a, i) => (
                <li
                  key={a.id}
                  id={`m06-aspecto-${a.id}`}
                  className={styles.aspect}
                  data-active={!enhanced || phase === i ? 'true' : 'false'}
                >
                  <span className={styles.aspectNum} aria-hidden="true">
                    {String(i + 1).padStart(2, '0')}
                  </span>
                  <div className={styles.aspectBody}>
                    <h3 className={`t-h3 ${styles.aspectTitle}`}>{a.label}</h3>
                    <p className={`t-body ${styles.aspectText}`}>{a.text}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </div>

      <div className={styles.more}>
        <Accordion
          variant="dark"
          summary={m06.cta}
          meta={`${m06.complementary.length} recursos`}
          className={styles.moreAccordion}
        >
          <ul className={styles.resourceList}>
            {m06.complementary.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </Accordion>

        {gestaoArea && topicId ? (
          <div className={styles.topicRow}>
            <p className={styles.topicText}>
              <span className={styles.topicKicker}>Pauta</span>
              {gestaoArea.label}
            </p>
            <TopicToggle
              tone="dark"
              selected={selected}
              onToggle={toggleTopic}
              subject={gestaoArea.label}
              addLabel={copy.m05.controls.add}
              removeLabel={copy.m05.controls.remove}
            />
          </div>
        ) : null}
        <p className="visually-hidden" role="status" aria-live="polite">
          {announce}
        </p>
      </div>
    </SectionShell>
  );
}
