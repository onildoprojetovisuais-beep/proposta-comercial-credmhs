import { useState } from 'react';
import { Button, IconCheck, IconChevron, SectionShell, TopicToggle, scrollToChapter } from '../ui';
import { applications, copy } from '../../content';
import { usePresentationState } from '../../state';
import { M05_ADDITIONAL_ID } from './m05/ids';
import { m07Microcopy } from './m07/microcopy';
import styles from './m07/M07Aplicacoes.module.css';

/**
 * M07 — Aplicações específicas (eSocial, Gestão de FAP/NTEP, Riscos Psicossociais).
 * - Copy: copy.m07 + `applications` (docs/02, slides 11–14).
 * - Destaque editorial quando a aplicação está em highlights.applications (prioridade
 *   Gestão e Tecnologia). Riscos Psicossociais nunca é destacado por prioridade (docs/03).
 * - "Conhecer a solução" só abre o detalhe; selecionar exige "Adicionar à conversa".
 */
export default function M07Aplicacoes() {
  const { state, highlights, isTopicSelected, actions } = usePresentationState();
  const [announcement, setAnnouncement] = useState('');
  const c = copy.m07;

  const highlighted = new Set(highlights.applications);
  // Rótulo da prioridade que originou o destaque (ex.: Gestão e Tecnologia).
  const priorityFor = (appId: string) =>
    highlights.priorities.find((p) => p.highlights.applications.some((a) => a === appId))?.label;

  // "Ver outras soluções" leva ao catálogo adicional de M05 (não ao topo do capítulo).
  const goToAdditional = () => {
    const target = document.getElementById(M05_ADDITIONAL_ID);
    if (!target) {
      scrollToChapter('m05');
      return;
    }
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    target.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
    window.history.replaceState(window.history.state, '', `${window.location.pathname}${window.location.search}#m05`);
    target.focus({ preventScroll: true });
  };

  return (
    <SectionShell id="m07" eyebrow="Aplicações" title={c.title} intro={c.body} surface="paper" width="wide">
      <ol className={styles.list} role="list">
        {applications.map((app, index) => {
          const detailKey = `m07:${app.id}`;
          const open = state.expandedDetail === detailKey;
          const selected = isTopicSelected(app.topicId);
          const isHighlighted = highlighted.has(app.id);
          const priorityLabel = isHighlighted ? priorityFor(app.id) : undefined;
          const detailId = `m07-detalhe-${app.id}`;
          const titleId = `m07-tema-${app.id}`;

          return (
            <li
              key={app.id}
              className={`row-expandable ${styles.item}`}
              data-open={open || undefined}
              data-selected={selected || undefined}
              aria-labelledby={titleId}
            >
              <span className={styles.index} aria-hidden="true">
                {String(index + 1).padStart(2, '0')}
              </span>

              <div className={styles.body}>
                {(isHighlighted || selected) && (
                  <p className={styles.tags}>
                    {isHighlighted && (
                      <span className="badge badge--priority">
                        <span>
                          {copy.m05.priorityBadge}
                          {priorityLabel ? <span className={styles.badgeDetail}>: {priorityLabel}</span> : null}
                        </span>
                      </span>
                    )}
                    {selected && (
                      <span className="badge badge--agenda">
                        <IconCheck />
                        {m07Microcopy.inAgenda}
                      </span>
                    )}
                  </p>
                )}
                <h3 id={titleId} className={`t-h2 ${styles.title}`}>
                  {app.label}
                </h3>
                <div className={styles.content}>
                  <p className={`t-body ${styles.summary}`}>{app.summary}</p>

                  <div id={detailId} className={styles.detail} hidden={!open}>
                    <p className="t-body">{app.detail}</p>
                  </div>

                  <div className={styles.actions}>
                    <Button
                      variant="link"
                      aria-label={`${open ? copy.global.close : c.controls.open}: ${app.label}`}
                      aria-expanded={open}
                      aria-controls={detailId}
                      onClick={() => actions.setExpandedDetail(open ? null : detailKey)}
                      iconAfter={<IconChevron open={open} />}
                    >
                      {open ? copy.global.close : c.controls.open}
                    </Button>
                    <TopicToggle
                      selected={selected}
                      subject={app.label}
                      addLabel={c.controls.add}
                      removeLabel={c.controls.remove}
                      onToggle={() => {
                        const result = actions.toggleTopic(app.topicId);
                        if (result === 'added') setAnnouncement(`${app.label} ${m07Microcopy.added}`);
                        else if (result === 'removed') setAnnouncement(`${app.label} ${m07Microcopy.removed}`);
                      }}
                    />
                  </div>
                </div>
              </div>
            </li>
          );
        })}
      </ol>

      <div className={styles.footer}>
        <p className={styles.footerText}>{m07Microcopy.alternativeLead}</p>
        <Button variant="secondary" onClick={goToAdditional} iconAfter={<ArrowUp />}>
          {c.alternative}
        </Button>
      </div>

      <p className="visually-hidden" role="status" aria-live="polite">
        {announcement}
      </p>
    </SectionShell>
  );
}

function ArrowUp() {
  return (
    <svg
      viewBox="0 0 20 20"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.4"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M10 16V4M5 9l5-5 5 5" />
    </svg>
  );
}
