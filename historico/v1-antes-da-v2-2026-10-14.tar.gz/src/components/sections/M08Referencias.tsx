import { SectionShell } from '../ui';
import { copy, displayableCredentials, trustMode } from '../../content';
import { trustFallbackPoints } from './m08/content';
import styles from './m08/M08Referencias.module.css';

/**
 * M08 — Referências de confiança.
 * Decisão (docs/02 M08, docs/07 P05/P06): `trustMode` é 'fallback' enquanto nenhuma ISO tiver
 * titular, escopo e validade confirmados. Nesse estado a seção mostra pessoas e estrutura,
 * SEM selos ISO/LGPD, sem "Ver certificado" e sem aviso de pendência ao prospect.
 * O ramo 'credentials' só lista credenciais completas (isCredentialDisplayable); LGPD nunca vira selo.
 */
export default function M08Referencias() {
  if (trustMode === 'credentials') {
    return (
      <SectionShell id="m08" eyebrow="Confiança" title={copy.m08.credentials.title} surface="white">
        <dl className={styles.credentials}>
          {displayableCredentials.map((cred) => (
            <div key={cred.id} className={styles.credential}>
              <dt className="t-h3">{cred.label}</dt>
              {cred.holder ? <dd>Titular: {cred.holder}</dd> : null}
              {cred.scope ? <dd>Escopo: {cred.scope}</dd> : null}
              {cred.validity ? <dd>Validade: {cred.validity}</dd> : null}
            </div>
          ))}
        </dl>
      </SectionShell>
    );
  }

  const c = copy.m08.fallback;
  return (
    <SectionShell id="m08" eyebrow="Confiança" title={c.title} intro={c.body} surface="white">
      {/* Layout v2: cabeçalho padrão (SectionHeader) na largura do container — título em 2 linhas no
          desktop; os três pontos formam uma régua em três colunas (≥1024), empilhados no mobile. */}
      <div className={styles.layout}>
        <ul className={styles.points} role="list">
          {trustFallbackPoints.map((point) => (
            <li key={point.id} className={styles.point}>
              <span className={styles.mark} aria-hidden="true" />
              <h3 className="t-h3">{point.label}</h3>
              <p className={`t-body ${styles.pointText}`}>{point.text}</p>
            </li>
          ))}
        </ul>
      </div>
    </SectionShell>
  );
}
