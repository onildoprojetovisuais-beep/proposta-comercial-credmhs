import { useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Button, Dialog, IconArrow, SectionShell, scrollToChapter, sectionTitleId } from '../ui';
import { copy } from '../../content';
import { formatTemplate } from '../../lib';
import { usePresentationState } from '../../state';
import { AgendaList } from './m09/AgendaList';
import { AgendaTextFallback } from './m10/AgendaTextFallback';
import { useAgendaCopy } from './m10/useAgendaCopy';
import { m10Microcopy } from './m10/microcopy';
import { m09Microcopy as mc } from './m09/microcopy';
import styles from './m09/M09Pauta.module.css';

/**
 * M09 — Pauta para a sua empresa (ConversationSummary).
 * - Título com/sem empresa (nome renderizado como texto, nunca HTML).
 * - Prioridades e assuntos em grupos distintos; lista editável (remover, reordenar, item livre).
 * - Estado vazio é válido e não bloqueia o contato.
 * - É uma pauta de conversa: sem score, preço, diagnóstico ou "contratar" (docs/01 M09).
 */
export default function M09Pauta() {
  const { executive, agenda, state, actions } = usePresentationState();
  const [announcement, setAnnouncement] = useState('');
  const [confirmClear, setConfirmClear] = useState(false);
  const clearButtonRef = useRef<HTMLButtonElement>(null);
  const agendaCopy = useAgendaCopy();
  const c = copy.m09;
  const c10 = copy.m10;

  const title = agenda.companyName
    ? formatTemplate(c.titleWithCompanyTemplate, { empresa: agenda.companyName })
    : c.titleWithoutCompany;

  const announce = (text: string) => {
    // Reinicia o texto para que anúncios repetidos sejam lidos de novo.
    setAnnouncement('');
    window.setTimeout(() => setAnnouncement(text), 30);
  };

  return (
    <SectionShell
      id="m09"
      eyebrow="Sua pauta"
      title={title}
      intro={agenda.isEmpty ? c.empty : formatTemplate(c.bodyTemplate, { firstName: executive.firstName })}
      surface="yellow"
    >
      {/* Layout v2: cabeçalho padrão (SectionHeader) na largura do container; abaixo, a folha da pauta
          (.panel-action) e, ao lado (≥1024) ou depois dela (mobile), a ação de seguir. */}
      <div className={styles.layout}>
        <div className={`panel-action ${styles.sheet}`} data-surface="light" key={state.resetCount}>
          <div className={styles.sheetHead}>
            <p className={`t-h3 ${styles.sheetTitle}`}>{mc.sheetTitle}</p>
            <p className={styles.sheetWith}>
              {formatTemplate(mc.sheetWithTemplate, { fullName: executive.fullName, role: executive.role })}
            </p>
          </div>

          <section className={styles.group} aria-labelledby="m09-grupo-prioridades">
            <div className={styles.groupHead}>
              <h3 id="m09-grupo-prioridades" className={styles.groupTitle}>
                {c.groupPriorities}
              </h3>
              <Button variant="link" size="sm" onClick={() => scrollToChapter('m02')}>
                {c.actions.editPriorities}
              </Button>
            </div>
            {agenda.priorities.length > 0 ? (
              <ul className={styles.priorities} role="list">
                {agenda.priorities.map((p) => (
                  <li key={p.id} className={styles.priority}>
                    {p.label}
                  </li>
                ))}
              </ul>
            ) : (
              <p className={styles.groupEmpty}>{mc.noPriorities}</p>
            )}
          </section>

          <section className={styles.group} aria-labelledby="m09-grupo-assuntos">
            <div className={styles.groupHead}>
              <h3 id="m09-grupo-assuntos" className={styles.groupTitle}>
                {c.groupTopics}
                {agenda.entries.length > 0 ? <span className={styles.count}> ({agenda.entries.length})</span> : null}
              </h3>
            </div>
            <AgendaList entries={agenda.entries} actions={actions} announce={announce} />
          </section>

          {!agenda.isEmpty && (
            <div className={styles.sheetFoot}>
              <Button ref={clearButtonRef} variant="link" size="sm" onClick={() => setConfirmClear(true)}>
                {c.actions.clear}
              </Button>
            </div>
          )}
        </div>

        <div className={styles.aside}>
          <div className={styles.ctaRow}>
            <Button onClick={() => scrollToChapter('m10')} iconAfter={<IconArrow />}>
              {c.cta}
            </Button>
            {/* Mesma ação (texto e cadeia de cópia) do M10: guardar a pauta sem depender de e-mail. */}
            <Button
              variant="secondary"
              onClick={() => void agendaCopy.copyAgenda()}
              disabled={agenda.isEmpty}
              aria-describedby={agenda.isEmpty ? 'm09-copiar-dica' : undefined}
            >
              {c10.alternatives.copyAgenda}
            </Button>
            <Button variant="link" onClick={() => scrollToChapter('m05')}>
              {c.actions.exploreMore}
            </Button>
          </div>

          {agenda.isEmpty ? (
            <p id="m09-copiar-dica" className={styles.copyHint}>
              {mc.copyEmptyHint}
            </p>
          ) : null}

          <p className={styles.copyStatus} role="status" aria-live="polite">
            {agendaCopy.status === 'copied'
              ? c10.feedback.agendaCopied
              : agendaCopy.status === 'failed'
                ? c10.feedback.copyFailed
                : ''}
          </p>

          {agendaCopy.status === 'failed' ? (
            <AgendaTextFallback
              id="m09-pauta-texto"
              label={m10Microcopy.agendaFallbackLabel}
              text={agendaCopy.agendaText}
            />
          ) : null}

          <p className={styles.note}>{c.commercialNote}</p>
        </div>
      </div>

      <p className="visually-hidden" role="status" aria-live="polite">
        {announcement}
      </p>

      {createPortal(
        <Dialog
          open={confirmClear}
          onClose={() => setConfirmClear(false)}
          title={mc.clearConfirmTitle}
          description={mc.clearConfirmBody}
          size="sm"
          returnFocusRef={clearButtonRef}
          footer={
            <>
              <Button variant="secondary" onClick={() => setConfirmClear(false)}>
                {mc.clearKeep}
              </Button>
              <Button
                variant="danger"
                onClick={() => {
                  actions.clearChoices();
                  setConfirmClear(false);
                  announce(mc.cleared);
                  // O botão "Limpar" deixa de existir; o foco vai para o título da pauta.
                  window.setTimeout(() => {
                    const t = document.getElementById(sectionTitleId('m09'));
                    if (!t) return;
                    t.setAttribute('tabindex', '-1');
                    t.focus();
                  }, 60);
                }}
              >
                {c.actions.clear}
              </Button>
            </>
          }
        />,
        document.body,
      )}
    </SectionShell>
  );
}
