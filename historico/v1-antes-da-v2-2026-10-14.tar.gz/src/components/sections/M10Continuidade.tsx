import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { Button, SectionHeader, SectionShell, scrollToChapter, sectionTitleId } from '../ui';
import { copy } from '../../content';
import { formatTemplate } from '../../lib';
import { usePresentationState } from '../../state';
import type { Executive } from '../../types';
import { copyText } from './m10/clipboard';
import { AgendaTextFallback } from './m10/AgendaTextFallback';
import { useAgendaCopy } from './m10/useAgendaCopy';
import { m10Microcopy as mc } from './m10/microcopy';
import styles from './m10/M10Continuidade.module.css';

type Feedback =
  { kind: 'none' } | { kind: 'ok'; text: string } | { kind: 'message-failed' } | { kind: 'agenda-failed' };

/**
 * M10 — Continuidade com o executivo.
 * - Prévia editável da mensagem (rascunho em memória, nunca persistido nem enviado).
 * - Se as escolhas mudarem depois da edição: aviso + "Atualizar mensagem com minhas escolhas".
 * - E-mail via mailto; se o corpo não couber na URL, abre só destinatário/assunto e orienta a cópia.
 * - Telefone, LinkedIn e site como alternativas. WhatsApp só aparece com canal confirmado (hoje null).
 * - Feedback nunca diz "enviado": o visitante inicia e conclui o contato no próprio aplicativo.
 */
export default function M10Continuidade() {
  const { executive, message, isMessageOutdated, contacts, state, actions } = usePresentationState();
  const agendaCopy = useAgendaCopy();
  const [feedback, setFeedback] = useState<Feedback>({ kind: 'none' });
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const c = copy.m10;
  const first = executive.firstName;

  // Reset/limpeza: some o feedback antigo.
  useEffect(() => setFeedback({ kind: 'none' }), [state.resetCount]);

  // Crescimento automático do campo onde `field-sizing: content` não existe (Safari/Firefox):
  // a mensagem inteira fica visível no fluxo da página, sem rolagem interna no celular.
  useLayoutEffect(() => {
    const ta = textareaRef.current;
    if (!ta || (typeof CSS !== 'undefined' && CSS.supports?.('field-sizing', 'content'))) return;
    ta.style.height = 'auto';
    ta.style.height = `${ta.scrollHeight + 4}px`;
  }, [message]);

  // Mensagem longa: o e-mail abre sem corpo, então copiar vira o passo principal.
  // Sem e-mail válido no perfil: "Copiar mensagem" é a ação principal.
  const email = contacts.email;
  const longMessage = !!email && !email.bodyIncluded && message.trim().length > 0;
  const copyIsPrimary = longMessage || !email;

  async function copyMessage() {
    const ok = await copyText(message);
    if (ok) setFeedback({ kind: 'ok', text: c.feedback.messageCopied });
    else {
      setFeedback({ kind: 'message-failed' });
      textareaRef.current?.focus();
      textareaRef.current?.select();
    }
  }

  async function copyAgenda() {
    const ok = await agendaCopy.copyAgenda();
    setFeedback(ok ? { kind: 'ok', text: c.feedback.agendaCopied } : { kind: 'agenda-failed' });
  }

  function focusEditor() {
    const ta = textareaRef.current;
    if (!ta) return;
    ta.focus();
    const end = ta.value.length;
    ta.setSelectionRange(end, end);
  }

  const emailAction = email ? (
    <Button
      size="lg"
      variant={longMessage ? 'secondary' : 'primary'}
      href={email.href}
      onClick={() => setFeedback({ kind: 'ok', text: mc.emailPrepared })}
      iconAfter={<ArrowOut />}
    >
      {formatTemplate(c.primaryCtaTemplate, { firstName: first })}
    </Button>
  ) : null;
  const copyAction = (
    <Button size="lg" variant={copyIsPrimary ? 'primary' : 'secondary'} onClick={copyMessage}>
      {c.controls.copy}
    </Button>
  );

  const statusText =
    feedback.kind === 'ok'
      ? feedback.text
      : feedback.kind === 'message-failed'
        ? `${c.feedback.copyFailed} ${mc.messageFallbackHint}`
        : feedback.kind === 'agenda-failed'
          ? c.feedback.copyFailed
          : '';

  return (
    <SectionShell id="m10" header={false} title={c.title} surface="paper" width="wide">
      <div className={styles.layout}>
        <SectionHeader
          className={styles.head}
          titleId={sectionTitleId('m10')}
          eyebrow="Contato"
          title={c.title}
          intro={c.body}
          flush
        />

        <div className={styles.person} role="group" aria-label={`${executive.fullName}, ${executive.role}`}>
          <Portrait executive={executive} />
          <div className={styles.personText}>
            <p className={styles.personName}>{executive.fullName}</p>
            <p className={styles.personRole}>{executive.role} · CRED MHS</p>
          </div>
        </div>

        <div className={styles.flow}>
          <div className={`panel-action ${styles.composer}`}>
            <div className={styles.composerHead}>
              <label htmlFor="m10-mensagem" className={`t-h3 ${styles.composerTitle}`}>
                {c.previewTitle}
              </label>
              <Button variant="link" size="sm" onClick={focusEditor}>
                {c.controls.edit}
              </Button>
            </div>
            <p id="m10-mensagem-dica" className={styles.hint}>
              {mc.messageHint}
            </p>

            {isMessageOutdated ? (
              <div className={styles.outdated}>
                <p>{mc.outdated}</p>
                <Button variant="secondary" size="sm" onClick={() => actions.refreshMessage()}>
                  {c.controls.refresh}
                </Button>
              </div>
            ) : null}

            <textarea
              ref={textareaRef}
              id="m10-mensagem"
              className={`field ${styles.textarea}`}
              value={message}
              rows={Math.min(14, Math.max(7, message.split('\n').length + 2))}
              aria-describedby={`m10-mensagem-dica${longMessage ? ' m10-mensagem-longa' : ''}`}
              spellCheck
              onChange={(e) => actions.setMessageDraft(e.target.value)}
            />

            {longMessage ? (
              <p id="m10-mensagem-longa" className={styles.longNote}>
                {c.feedback.longMessage}
              </p>
            ) : null}

            {/* Mesma linha, mesmo size (lg). Mensagem longa: "Copiar mensagem" vira primary e vem antes. */}
            <div className={styles.actions}>
              {copyIsPrimary ? (
                <>
                  {copyAction}
                  {emailAction}
                </>
              ) : (
                <>
                  {emailAction}
                  {copyAction}
                </>
              )}
            </div>

            <p className={styles.noAutoSend}>{keepEmailTogether(mc.noAutoSend)}</p>

            <p className={styles.status} role="status" aria-live="polite">
              {statusText}
            </p>

            {feedback.kind === 'agenda-failed' ? (
              <AgendaTextFallback id="m10-pauta-texto" label={mc.agendaFallbackLabel} text={agendaCopy.agendaText} />
            ) : null}
          </div>

          <div className={styles.secondaryRow}>
            <Button variant="secondary" onClick={copyAgenda}>
              {c.alternatives.copyAgenda}
            </Button>
            <Button variant="link" onClick={() => scrollToChapter('m09')} iconBefore={<ArrowBack />}>
              {c.controls.back}
            </Button>
          </div>
        </div>

        <div className={styles.channels}>
          <p className={styles.channelsTitle}>{mc.otherChannels}</p>
          <ul role="list" className={styles.channelList}>
            {executive.email ? (
              <li>
                {/* E-mail como texto (docs/02, "Contato documentado"): útil para quem não usa app de e-mail. */}
                <a className={styles.channel} href={`mailto:${executive.email}`}>
                  <span className={styles.channelLabel}>{mc.emailLabel}</span>
                  <span className={styles.channelValue}>{executive.email}</span>
                </a>
              </li>
            ) : null}
            {contacts.phone ? (
              <li>
                <a className={styles.channel} href={contacts.phone.href}>
                  <span className={styles.channelLabel}>
                    {formatTemplate(c.alternatives.callTemplate, { firstName: first })}
                  </span>
                  <span className={styles.channelValue}>{contacts.phone.label}</span>
                </a>
              </li>
            ) : null}
            {contacts.linkedIn ? (
              <li>
                <a className={styles.channel} href={contacts.linkedIn.href} target="_blank" rel="noopener noreferrer">
                  <span className={styles.channelLabel}>{c.alternatives.linkedIn}</span>
                  <span className={styles.channelValue}>
                    {contacts.linkedIn.href.replace(/^https?:\/\/(www\.)?/, '')}
                    <span className="visually-hidden"> {mc.newTab}</span>
                  </span>
                </a>
              </li>
            ) : null}
            {contacts.website ? (
              <li>
                <a className={styles.channel} href={contacts.website.href} target="_blank" rel="noopener noreferrer">
                  <span className={styles.channelLabel}>{mc.website}</span>
                  <span className={styles.channelValue}>
                    {contacts.website.label}
                    <span className="visually-hidden"> {mc.newTab}</span>
                  </span>
                </a>
              </li>
            ) : null}
            {contacts.whatsApp ? (
              <li>
                <a className={styles.channel} href={contacts.whatsApp.href} target="_blank" rel="noopener noreferrer">
                  <span className={styles.channelLabel}>
                    {formatTemplate(c.whatsAppCtaTemplate, { firstName: first })}
                  </span>
                  <span className="visually-hidden"> {mc.newTab}</span>
                </a>
              </li>
            ) : null}
          </ul>
        </div>
      </div>
    </SectionShell>
  );
}

/** Evita a quebra "e-/mail" sem alterar a copy: o termo hifenizado fica numa linha só. */
function keepEmailTogether(text: string): ReactNode {
  const parts = text.split('e-mail');
  if (parts.length === 1) return text;
  return parts.flatMap((part, i) =>
    i === 0 ? [part] : [<span key={i} className="nowrap">e-mail</span>, part],
  );
}

/**
 * Retrato real do executivo; variantes otimizadas só para o retrato do projeto (`bundled`).
 * Foto remota que falhar ao carregar cai na inicial (mesmo layout de perfil sem foto).
 */
function Portrait({ executive }: { executive: Executive }) {
  const [failedPhoto, setFailedPhoto] = useState<string | null>(null);
  if (!executive.photo || executive.photo === failedPhoto) {
    return (
      <div className={styles.portraitFallback} aria-hidden="true">
        {executive.firstName.charAt(0)}
      </div>
    );
  }
  const base = `/media/executives/${executive.id}`;
  const hasVariants = executive.photoSource === 'bundled' && executive.photo === `${base}.png`;
  const w = executive.photoWidth ?? 1098;
  const h = executive.photoHeight ?? 1433;
  return (
    <picture className={styles.portrait}>
      {hasVariants ? (
        <>
          <source
            type="image/avif"
            srcSet={`${base}-640.avif 640w, ${base}-1098.avif 1098w`}
            sizes="(min-width: 1024px) 30vw, 60vw"
          />
          <source
            type="image/webp"
            srcSet={`${base}-640.webp 640w, ${base}-1098.webp 1098w`}
            sizes="(min-width: 1024px) 30vw, 60vw"
          />
        </>
      ) : null}
      <img
        src={hasVariants ? `${base}-1098.jpg` : executive.photo}
        alt={executive.photoAlt}
        width={w}
        height={h}
        loading="lazy"
        decoding="async"
        onError={() => setFailedPhoto(executive.photo)}
      />
    </picture>
  );
}

function ArrowOut() {
  return (
    <svg
      viewBox="0 0 20 20"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.4"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M4 10h11M11 5.5 15.5 10 11 14.5" />
    </svg>
  );
}

function ArrowBack() {
  return (
    <svg
      viewBox="0 0 20 20"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.4"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M10 16V4M5 9l5-5 5 5" />
    </svg>
  );
}
