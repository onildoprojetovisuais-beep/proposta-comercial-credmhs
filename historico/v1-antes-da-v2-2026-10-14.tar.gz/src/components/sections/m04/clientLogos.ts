/**
 * M04 — conciliação imagem ↔ nome dos logos extraídos do slide 16 (public/media/pptx/clientes).
 * Cada par foi conferido visualmente (folha de contato dos 40 arquivos, 2026-10-08): só entram
 * arquivos em que a imagem é claramente a marca do nome listado em src/content/clients.ts.
 * Fora do mapa (nome em tipografia): Villefort Atacadista (arquivo de 127 px, marca ilegível em
 * escala útil). Fora da página: Unicred (imagem sem nome na relação textual — P07) e a variante
 * recortada de Cimed. `crop` = [x, y, largura, altura] da área útil, para equilibrar margens
 * internas desiguais dos arquivos do PPTX sem editar as imagens.
 */
export interface ClientLogo {
  file: string;
  w: number;
  h: number;
  crop: [number, number, number, number];
}

export const CLIENT_LOGO_BY_ID: Readonly<Record<string, ClientLogo>> = {
  'cervantes': { file: 'cervantes', w: 800, h: 283, crop: [15, 20, 773, 253] },
  'cimento-nacional': { file: 'cimento-nacional', w: 300, h: 161, crop: [0, 0, 300, 161] },
  'apia': { file: 'apia', w: 334, h: 151, crop: [21, 29, 292, 96] },
  'caparao': { file: 'caparao', w: 464, h: 108, crop: [0, 0, 464, 108] },
  'cencosud': { file: 'cencosud', w: 800, h: 438, crop: [0, 0, 800, 438] },
  'loja-eletrica-ltda': { file: 'loja-eletrica', w: 800, h: 240, crop: [7, 7, 786, 227] },
  'sg-ompi': { file: 'sg-ompi', w: 228, h: 138, crop: [1, 15, 226, 107] },
  'per-fa-alimentos': { file: 'perfa-alimentos', w: 598, h: 165, crop: [0, 0, 598, 165] },
  'hyatt': { file: 'hyatt', w: 235, h: 119, crop: [0, 0, 235, 119] },
  'grupo-sotreq': { file: 'grupo-sotreq', w: 283, h: 173, crop: [14, 17, 254, 140] },
  'storm-group': { file: 'storm-group', w: 225, h: 225, crop: [0, 0, 225, 225] },
  'minalba-brasil': { file: 'minalba-brasil', w: 300, h: 168, crop: [79, 67, 152, 52] },
  'radix-engenharia-e-software': { file: 'radix', w: 200, h: 101, crop: [0, 0, 200, 101] },
  'alianca-a-nova-geracao-da-energia': { file: 'alianca-energia', w: 402, h: 125, crop: [16, 22, 371, 92] },
  'banco-bmg': { file: 'banco-bmg', w: 300, h: 168, crop: [72, 40, 155, 88] },
  'tora': { file: 'tora', w: 229, h: 220, crop: [0, 0, 229, 220] },
  'orguel': { file: 'orguel', w: 331, h: 95, crop: [24, 20, 283, 55] },
  'guara': { file: 'guara', w: 204, h: 192, crop: [21, 62, 162, 69] },
  'economart-atacadista': { file: 'economart', w: 204, h: 192, crop: [20, 76, 163, 41] },
  'nacional-gas': { file: 'nacional-gas', w: 204, h: 192, crop: [25, 81, 154, 31] },
  'trigo': { file: 'trigo', w: 308, h: 76, crop: [5, 2, 298, 72] },
  'radisson-barra-rio-de-janeiro': { file: 'radisson-barra', w: 242, h: 135, crop: [15, 5, 224, 125] },
  'hotel-santa-teresa-mgallery-rio': { file: 'hotel-santa-teresa', w: 493, h: 349, crop: [109, 70, 275, 203] },
  'grupo-iter': { file: 'grupo-iter', w: 362, h: 125, crop: [7, 29, 335, 76] },
  'hn-hotel-nacional-rio-de-janeiro': { file: 'hotel-nacional', w: 330, h: 130, crop: [0, 0, 330, 130] },
  'ferrareze-freitas-advogados': { file: 'ferrareze-freitas', w: 163, h: 88, crop: [0, 0, 163, 88] },
  'rede-manaus': { file: 'rede-manaus', w: 175, h: 68, crop: [4, 1, 169, 67] },
  'ombrello': { file: 'ombrello', w: 300, h: 52, crop: [0, 0, 300, 52] },
  'fairmont-rio-de-janeiro-copacabana': { file: 'fairmont-copacabana', w: 345, h: 152, crop: [24, 24, 297, 104] },
  'dom-atacadista': { file: 'dom-atacadista', w: 225, h: 225, crop: [0, 0, 225, 225] },
  'caixa-caixa-economica-federal': { file: 'caixa', w: 225, h: 225, crop: [8, 78, 209, 68] },
  'cimed': { file: 'cimed', w: 148, h: 148, crop: [4, 55, 140, 38] },
  'brasfrigo': { file: 'brasfrigo', w: 153, h: 148, crop: [6, 45, 141, 54] },
  'jia-group': { file: 'jia-group', w: 230, h: 148, crop: [52, 45, 127, 58] },
  'csn': { file: 'csn', w: 161, h: 148, crop: [6, 50, 149, 48] },
  'cesari': { file: 'cesari', w: 248, h: 148, crop: [45, 32, 158, 88] },
};

export const clientLogoSrc = (logo: ClientLogo) => `/media/pptx/clientes/${logo.file}.png`;
