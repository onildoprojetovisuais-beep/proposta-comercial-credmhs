/** ID do catálogo adicional de M05 — destino de "Outras soluções"/"Ver outras soluções" (M07). */
export const M05_ADDITIONAL_ID = 'm05-outras-solucoes';
