import { useEffect, useRef, useState } from 'react';
import styles from './M06.module.css';

const POSTER = '/media/m06/m06-gestao-poster.webp';
/**
 * MP4 (H.264 High, yuv420p, faixa limitada BT.709) primeiro: decodificação mais estável em hardware
 * (Chrome/Edge no Windows, Safari/iOS). WebM VP9 fica como alternativa.
 * Os dois precisam ser renderizados com `--pixel-format yuv420p --color-space bt709` (ver remotion/README.md):
 * o VP9 em faixa "full" (yuvj) gerava PIPELINE_ERROR_DECODE no decodificador de hardware do Chrome/Edge.
 */
const SOURCES = [
  { src: '/media/m06/m06-gestao.mp4', type: 'video/mp4; codecs="avc1.640020"' },
  { src: '/media/m06/m06-gestao.webm', type: 'video/webm; codecs="vp9"' },
] as const;

/** Texto alternativo do recurso animado (o conteúdo também está em HTML ao lado). */
export const M06_MEDIA_ALT =
  'Esquema animado: Acompanhamento, Integração e Informação gerencial aparecem juntos, se conectam em triângulo e convergem para a gestão, com o logotipo CRED MHS ao centro.';
const POSTER_ALT =
  'Esquema: Acompanhamento, Integração e Informação gerencial conectados em triângulo, convergindo para a gestão, com o logotipo CRED MHS ao centro.';

type PlayState = 'idle' | 'playing' | 'paused' | 'failed';

interface M06MediaProps {
  caption: string;
  reducedMotion: boolean;
}

/**
 * Recurso Remotion de M06 (ciclo de 20 s em loop, 1:1, sem áudio).
 * - Versão neutra: mostra o conjunto (os três aspectos com o mesmo peso, ligados e convergindo ao centro),
 *   sem acender um aspecto por vez. Quem indica a etapa ativa é o scroll, no texto ao lado; assim o vídeo,
 *   que corre no próprio tempo, nunca sugere um estado concorrente (revisão da experiência, ajuste 4).
 * - Loop contínuo: forma-se devagar, respira e se dissolve; o último quadro emenda no primeiro.
 *   Toca enquanto está em vista e pausa fora dela (economia); volta a tocar ao reaparecer,
 *   a menos que o visitante tenha pausado.
 * - Botão pausar/reproduzir (movimento contínuo precisa de pausa, WCAG 2.2.2).
 *   Autoplay bloqueado → fica no poster com "Reproduzir animação".
 * - Reduced motion: só o poster estático, sem vídeo nem autoplay.
 */
export function M06Media({ caption, reducedMotion }: M06MediaProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [state, setState] = useState<PlayState>('idle');
  /** Pausa feita pelo visitante: a volta à tela não retoma o vídeo. */
  const userPausedRef = useRef(false);
  /** Pausa feita pelo observador de visibilidade (não muda o rótulo do botão). */
  const autoPausingRef = useRef(false);
  const captionId = 'm06-media-legenda';

  useEffect(() => {
    if (reducedMotion) return;
    const video = videoRef.current;
    if (!video) return;
    video.muted = true;
    if (typeof IntersectionObserver === 'undefined') return;
    const io = new IntersectionObserver(
      (entries) => {
        const visible = entries.some((e) => e.isIntersecting);
        if (visible) {
          if (!userPausedRef.current && video.paused) safePlay(video);
        } else if (!video.paused) {
          autoPausingRef.current = true;
          video.pause();
        }
      },
      { threshold: 0.35 },
    );
    io.observe(video);
    return () => io.disconnect();
  }, [reducedMotion]);

  const toggle = () => {
    const video = videoRef.current;
    if (!video) return;
    if (!video.paused) {
      userPausedRef.current = true;
      video.pause();
      return;
    }
    userPausedRef.current = false;
    safePlay(video);
  };

  /** play() com a promessa tratada: AbortError (pausa/troca de fonte no meio) é esperado e ignorado. */
  function safePlay(video: HTMLVideoElement) {
    video.muted = true;
    const p = video.play();
    if (!p) return;
    p.catch((err: unknown) => {
      const name = err instanceof DOMException ? err.name : '';
      if (name === 'AbortError') return;
      if (name === 'NotAllowedError') {
        setState('idle'); // autoplay bloqueado: fica no poster com "Reproduzir"
        return;
      }
      // NotSupportedError etc.: o evento "error" decide entre tentar a outra fonte ou cair no poster.
      if (!video.error && video.networkState === HTMLMediaElement.NETWORK_NO_SOURCE) setState('failed');
    });
  }

  /**
   * Erro de mídia (decodificação, rede, formato). O navegador não passa sozinho para o próximo <source>
   * depois que um deles foi escolhido, então tentamos a alternativa manualmente; sem alternativa, poster estático.
   */
  const triedRef = useRef<Set<string>>(new Set());
  const handleMediaError = () => {
    const video = videoRef.current;
    if (!video) return;
    const wanted = state !== 'paused';
    if (video.currentSrc) triedRef.current.add(new URL(video.currentSrc, location.href).pathname);
    const next = SOURCES.find((s) => !triedRef.current.has(s.src) && video.canPlayType(s.type) !== '');
    if (!next) {
      setState('failed');
      return;
    }
    triedRef.current.add(next.src);
    video.src = next.src;
    video.load();
    if (wanted) safePlay(video);
  };

  const label = state === 'playing' ? 'Pausar animação' : 'Reproduzir animação';

  return (
    <figure className={styles.media} aria-labelledby={captionId}>
      <div className={styles.mediaFrame}>
        {reducedMotion || state === 'failed' ? (
          <img
            className={styles.mediaEl}
            src={POSTER}
            alt={POSTER_ALT}
            width={1080}
            height={1080}
            loading="lazy"
            decoding="async"
          />
        ) : (
          <video
            ref={videoRef}
            className={styles.mediaEl}
            width={1080}
            height={1080}
            poster={POSTER}
            muted
            loop
            playsInline
            preload="none"
            disablePictureInPicture
            aria-label={M06_MEDIA_ALT}
            onPlay={() => setState('playing')}
            onPause={() => {
              // Pausa automática (fora de vista) mantém o rótulo; só a do visitante vira "Reproduzir".
              if (autoPausingRef.current) {
                autoPausingRef.current = false;
                return;
              }
              setState('paused');
            }}
            onError={handleMediaError}
          >
            {SOURCES.map((s, i) => (
              <source
                key={s.src}
                src={s.src}
                type={s.type}
                // Erro no último <source> = nenhuma fonte carregou (404, tipo não suportado).
                onError={i === SOURCES.length - 1 ? handleMediaError : undefined}
              />
            ))}
          </video>
        )}
      </div>
      <div className={styles.mediaFoot}>
        <figcaption id={captionId} className={`t-small ${styles.caption}`}>
          {caption}
        </figcaption>
        {reducedMotion || state === 'failed' ? null : (
          <button
            type="button"
            className={styles.playButton}
            onClick={toggle}
            data-state={state}
            aria-label={label}
          >
            <span className={styles.playIcon} aria-hidden="true" />
            <span className={styles.playLabel}>{state === 'playing' ? 'Pausar' : 'Reproduzir'}</span>
          </button>
        )}
      </div>
    </figure>
  );
}
