import { useCallback, useLayoutEffect, useRef, useState } from 'react';
import type { RefObject } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

/**
 * Mesma condição do CSS (M06.module.css): sticky só com área suficiente e sem reduced motion.
 * Abaixo disso (mobile, zoom alto, reduced motion) não há ScrollTrigger: os três aspectos ficam no fluxo.
 */
export const M06_STICKY_QUERY =
  '(min-width: 1024px) and (min-height: 700px) and (prefers-reduced-motion: no-preference)';

export interface M06Scroll {
  /** true quando o palco sticky está ativo (desktop com área suficiente). */
  enhanced: boolean;
  /** Fase atual (0..count-1). Fora do modo sticky, sempre 0 e sem efeito visual. */
  phase: number;
  /** Rola até a fase i (instantâneo com reduced motion). Não intercepta roda/toque/teclado. */
  goToPhase(i: number): void;
}

/**
 * Scroll narrativo de M06 com ScrollTrigger (sem pin do GSAP: o palco usa position: sticky em CSS,
 * então o layout não depende do JS e nada fica fixo fora da seção).
 * O ScrollTrigger só lê o progresso do trilho → fase ativa + variável CSS --m06-p (barra de progresso).
 */
export function useM06Scroll(trackRef: RefObject<HTMLElement>, count: number): M06Scroll {
  const [enhanced, setEnhanced] = useState(false);
  const [phase, setPhase] = useState(0);
  const stRef = useRef<ScrollTrigger | null>(null);

  useLayoutEffect(() => {
    const track = trackRef.current;
    if (!track) return;

    const ctx = gsap.context(() => {
      const mm = gsap.matchMedia();
      mm.add(M06_STICKY_QUERY, () => {
        const headerH = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--header-h')) || 64;
        let last = -1;
        const st = ScrollTrigger.create({
          trigger: track,
          start: () => `top top+=${headerH}`,
          end: 'bottom bottom',
          invalidateOnRefresh: true,
          onUpdate: (self) => {
            track.style.setProperty('--m06-p', self.progress.toFixed(4));
            const next = Math.min(count - 1, Math.floor(self.progress * count));
            if (next !== last) {
              last = next;
              setPhase(next);
            }
          },
          onRefresh: (self) => {
            track.style.setProperty('--m06-p', self.progress.toFixed(4));
            const next = Math.min(count - 1, Math.floor(self.progress * count));
            last = next;
            setPhase(next);
          },
        });
        stRef.current = st;
        setEnhanced(true);
        return () => {
          stRef.current = null;
          track.style.removeProperty('--m06-p');
          setEnhanced(false);
          setPhase(0);
        };
      });
    }, track);

    // Recalcula depois que as fontes carregam e quando a altura da página muda
    // (acordeões de outros capítulos alteram a posição do trilho).
    let raf = 0;
    const refresh = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => ScrollTrigger.refresh());
    };
    document.fonts?.ready.then(refresh).catch(() => undefined);
    let lastH = document.body.scrollHeight;
    const ro =
      typeof ResizeObserver !== 'undefined'
        ? new ResizeObserver(() => {
            const h = document.body.scrollHeight;
            if (Math.abs(h - lastH) > 2) {
              lastH = h;
              refresh();
            }
          })
        : null;
    ro?.observe(document.body);

    return () => {
      cancelAnimationFrame(raf);
      ro?.disconnect();
      ctx.revert();
    };
  }, [trackRef, count]);

  const goToPhase = useCallback(
    (i: number) => {
      const st = stRef.current;
      if (!st) return;
      const span = st.end - st.start;
      // Entra um pouco dentro do intervalo da fase para não oscilar na fronteira.
      const target = i <= 0 ? st.start + 2 : st.start + span * ((i + 0.12) / count);
      const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      window.scrollTo({ top: Math.round(target), behavior: reduce ? 'auto' : 'smooth' });
    },
    [count],
  );

  return { enhanced, phase, goToPhase };
}
