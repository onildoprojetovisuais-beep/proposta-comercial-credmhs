/**
 * Microcopy nova de M07 (não consta em docs/02). Apenas rótulos de estado/feedback,
 * sem fatos novos. Registrada em qa/RELATORIO.md pelo responsável de M07–M10.
 */
export const m07Microcopy = {
  inAgenda: 'Na pauta',
  added: 'adicionado à pauta.',
  removed: 'removido da pauta.',
  alternativeLead: 'Outras necessidades da operação aparecem no catálogo de soluções.',
} as const;
