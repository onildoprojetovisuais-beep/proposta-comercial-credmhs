import type { SourceSlide } from '../../../types';

/**
 * M08 — fallback "Pessoas e estrutura" (docs/01 M08; docs/02 M08, fontes slides 8, 11 e 18).
 * Breve retomada de equipe e estrutura reais, sem métricas (não duplicar M03) e
 * sem afirmação de certificação. Textos condensados do slide de origem, sem ampliar promessas.
 * Microcopy nova: rótulos curtos dos três pontos. Registrada em qa/RELATORIO.md.
 */
export interface TrustPoint {
  id: string;
  label: string;
  text: string;
  sourceSlides: SourceSlide[];
}

export const trustFallbackPoints: readonly TrustPoint[] = [
  {
    id: 'equipe',
    label: 'Equipe multidisciplinar',
    text: 'Engenheiros do Trabalho, Técnicos de Segurança e profissionais de áreas afins participam da implantação e adequação das soluções de Segurança do Trabalho.',
    sourceSlides: [8],
  },
  {
    id: 'equipamentos',
    label: 'Equipamentos próprios',
    text: 'A CRED dispõe de parque próprio de equipamentos tecnológicos para realização de medições.',
    sourceSlides: [11],
  },
  {
    id: 'acompanhamento',
    label: 'Recursos de acompanhamento',
    text: 'O portal de serviços online permite ao cliente acompanhar o atendimento e o SLA.',
    sourceSlides: [11],
  },
];
