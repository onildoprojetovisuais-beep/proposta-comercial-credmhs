import { forwardRef, useEffect, useRef, useState } from 'react';
import type { FormEvent, KeyboardEvent, ReactNode } from 'react';
import { copy } from '../../../content';
import { formatTemplate, CUSTOM_ITEM_MAX_LENGTH } from '../../../lib';
import type { AgendaEntry, CustomAgendaItem, TopicId } from '../../../types';
import type { PresentationActions } from '../../../state';
import { Button } from '../../ui';
import { kindLabel, m09Microcopy as mc } from './microcopy';
import styles from './M09Pauta.module.css';

interface AgendaListProps {
  entries: AgendaEntry[];
  actions: PresentationActions;
  announce(text: string): void;
}

const isCustom = (e: AgendaEntry): e is AgendaEntry & { id: CustomAgendaItem['id'] } => e.kind === 'nota';

/**
 * Lista editável de assuntos da pauta.
 * - Assuntos do catálogo e itens livres reordenam dentro do próprio grupo (botões, não arrastar).
 * - Itens livres podem ser editados; esvaziar o texto remove o item (regra do store).
 * - Depois de mover/remover, o foco vai para um controle equivalente e a mudança é anunciada.
 */
export function AgendaList({ entries, actions, announce }: AgendaListProps) {
  const a = copy.m09.actions;
  const controls = useRef(new Map<string, HTMLElement>());
  const pendingFocus = useRef<string[] | null>(null);
  const addInputRef = useRef<HTMLInputElement>(null);
  const [draft, setDraft] = useState('');
  const [addError, setAddError] = useState('');
  const [editingId, setEditingId] = useState<CustomAgendaItem['id'] | null>(null);
  const [editText, setEditText] = useState('');

  const topicEntries = entries.filter((e) => !isCustom(e));
  const customEntries = entries.filter(isCustom);

  useEffect(() => {
    const keys = pendingFocus.current;
    if (!keys) return;
    pendingFocus.current = null;
    for (const key of keys) {
      const el = key === 'add' ? addInputRef.current : controls.current.get(key);
      if (el && !(el as HTMLButtonElement).disabled) {
        el.focus();
        return;
      }
    }
  });

  const register = (key: string) => (el: HTMLElement | null) => {
    if (el) controls.current.set(key, el);
    else controls.current.delete(key);
  };

  function move(entry: AgendaEntry, delta: -1 | 1) {
    const group = isCustom(entry) ? customEntries : topicEntries;
    const from = group.findIndex((e) => e.id === entry.id);
    const to = from + delta;
    if (from < 0 || to < 0 || to >= group.length) return;
    if (isCustom(entry)) actions.moveCustomItem(entry.id, delta);
    else actions.moveTopic(entry.id as TopicId, delta);
    const position = entries.findIndex((e) => e.id === entry.id) + 1 + delta;
    pendingFocus.current = delta < 0 ? [`${entry.id}:up`, `${entry.id}:down`] : [`${entry.id}:down`, `${entry.id}:up`];
    announce(formatTemplate(mc.moved, { label: entry.label, position }));
  }

  function remove(entry: AgendaEntry) {
    const index = entries.findIndex((e) => e.id === entry.id);
    const next = entries[index + 1] ?? entries[index - 1];
    if (isCustom(entry)) actions.removeCustomItem(entry.id);
    else actions.removeTopic(entry.id as TopicId);
    pendingFocus.current = next ? [`${next.id}:remove`, 'add'] : ['add'];
    announce(formatTemplate(mc.removed, { label: entry.label }));
  }

  function submitNew(e: FormEvent) {
    e.preventDefault();
    const text = draft.trim();
    if (!text) {
      setAddError(mc.empty);
      addInputRef.current?.focus();
      return;
    }
    const id = actions.addCustomItem(text);
    if (!id) {
      const duplicate = customEntries.some((c) => c.label.toLowerCase() === text.replace(/\s+/g, ' ').toLowerCase());
      setAddError(duplicate ? mc.duplicate : mc.limit);
      addInputRef.current?.focus();
      return;
    }
    setDraft('');
    setAddError('');
    announce(formatTemplate(mc.added, { label: text }));
    addInputRef.current?.focus();
  }

  function startEdit(entry: AgendaEntry & { id: CustomAgendaItem['id'] }) {
    setEditingId(entry.id);
    setEditText(entry.label);
  }

  function finishEdit(save: boolean) {
    if (!editingId) return;
    const id = editingId;
    if (save) {
      const willRemove = !editText.trim();
      actions.updateCustomItem(id, editText);
      const oldLabel = entries.find((e) => e.id === id)?.label ?? '';
      announce(willRemove ? formatTemplate(mc.removed, { label: oldLabel }) : mc.updated);
      pendingFocus.current = willRemove ? ['add'] : [`${id}:edit`];
    } else {
      pendingFocus.current = [`${id}:edit`];
    }
    setEditingId(null);
    setEditText('');
  }

  function onEditKey(e: KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Escape') {
      e.preventDefault();
      finishEdit(false);
    }
  }

  return (
    <>
      {entries.length > 0 ? (
        <ol className={styles.topics} role="list">
          {entries.map((entry, i) => {
            const group = isCustom(entry) ? customEntries : topicEntries;
            const gi = group.findIndex((e) => e.id === entry.id);
            const canUp = gi > 0;
            const canDown = gi < group.length - 1;
            const editing = isCustom(entry) && editingId === entry.id;
            const inputId = `m09-editar-${entry.id.replace(/[^a-z0-9-]/gi, '-')}`;

            return (
              <li key={entry.id} className={styles.topic} data-kind={entry.kind}>
                <span className={styles.topicNumber} aria-hidden="true">
                  {i + 1}
                </span>

                {editing ? (
                  <form
                    className={styles.editForm}
                    onSubmit={(e) => {
                      e.preventDefault();
                      finishEdit(true);
                    }}
                  >
                    <label htmlFor={inputId} className="visually-hidden">
                      {mc.editLabel}
                    </label>
                    <input
                      id={inputId}
                      className={`field ${styles.input}`}
                      value={editText}
                      maxLength={CUSTOM_ITEM_MAX_LENGTH}
                      onChange={(e) => setEditText(e.target.value)}
                      onKeyDown={onEditKey}
                      autoFocus
                    />
                    <div className={styles.editActions}>
                      <Button type="submit" variant="secondary" size="sm">
                        {a.saveCustom}
                      </Button>
                      <Button variant="link" size="sm" onClick={() => finishEdit(false)}>
                        {mc.cancel}
                      </Button>
                    </div>
                  </form>
                ) : (
                  <div className={styles.topicText}>
                    <span className={styles.topicLabel}>{entry.label}</span>
                    <span className={styles.topicKind}>{kindLabel[entry.kind]}</span>
                  </div>
                )}

                {!editing && (
                  <div className={styles.topicControls}>
                    <IconButton
                      ref={register(`${entry.id}:up`)}
                      label={`${a.moveUp}: ${entry.label}`}
                      disabled={!canUp}
                      onClick={() => move(entry, -1)}
                    >
                      <path d="M10 15V5M5.5 9.5 10 5l4.5 4.5" />
                    </IconButton>
                    <IconButton
                      ref={register(`${entry.id}:down`)}
                      label={`${a.moveDown}: ${entry.label}`}
                      disabled={!canDown}
                      onClick={() => move(entry, 1)}
                    >
                      <path d="M10 5v10M5.5 10.5 10 15l4.5-4.5" />
                    </IconButton>
                    {/* Célula fixa: sem "Editar", o espaço fica reservado e ↑ ↓ ✕ não mudam de posição. */}
                    {isCustom(entry) ? (
                      <IconButton
                        ref={register(`${entry.id}:edit`)}
                        label={`${a.editCustom}: ${entry.label}`}
                        onClick={() => startEdit(entry)}
                      >
                        <path d="M4 16h3l8.5-8.5-3-3L4 13v3zM11.5 5.5l3 3" />
                      </IconButton>
                    ) : (
                      <span className={styles.iconSpacer} aria-hidden="true" />
                    )}
                    <IconButton
                      ref={register(`${entry.id}:remove`)}
                      label={`${a.removeTopic}: ${entry.label}`}
                      onClick={() => remove(entry)}
                      tone="remove"
                    >
                      <path d="M5.5 5.5l9 9M14.5 5.5l-9 9" />
                    </IconButton>
                  </div>
                )}
              </li>
            );
          })}
        </ol>
      ) : (
        <p className={styles.groupEmpty}>{mc.noTopics}</p>
      )}

      <form className={`field-group ${styles.addForm}`} onSubmit={submitNew} noValidate>
        <label htmlFor="m09-novo-assunto" className="field-label">
          {a.addCustom}
        </label>
        <p id="m09-novo-assunto-dica" className="field-hint">
          {formatTemplate(mc.addHint, { max: CUSTOM_ITEM_MAX_LENGTH })}
        </p>
        <div className={styles.addRow}>
          <input
            ref={addInputRef}
            id="m09-novo-assunto"
            className={`field ${styles.input}`}
            value={draft}
            maxLength={CUSTOM_ITEM_MAX_LENGTH}
            placeholder={a.customPlaceholder}
            aria-describedby={addError ? 'm09-novo-assunto-dica m09-novo-assunto-erro' : 'm09-novo-assunto-dica'}
            aria-invalid={addError ? true : undefined}
            onChange={(e) => {
              setDraft(e.target.value);
              if (addError) setAddError('');
            }}
          />
          <Button type="submit" variant="secondary" className={styles.addButton}>
            {mc.addButton}
          </Button>
        </div>
        {addError ? (
          <p id="m09-novo-assunto-erro" className={styles.addError} role="alert">
            {addError}
          </p>
        ) : null}
      </form>
    </>
  );
}

interface IconButtonProps {
  label: string;
  onClick(): void;
  disabled?: boolean;
  tone?: 'default' | 'remove';
  children: ReactNode;
}

const IconButton = forwardRef<HTMLButtonElement, IconButtonProps>(function IconButton(
  { label, onClick, disabled, tone = 'default', children },
  ref,
) {
  return (
    <button
      ref={ref}
      type="button"
      className={styles.iconButton}
      data-tone={tone}
      aria-label={label}
      title={label.split(':')[0]}
      disabled={disabled}
      onClick={onClick}
    >
      <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        {children}
      </svg>
    </button>
  );
});
