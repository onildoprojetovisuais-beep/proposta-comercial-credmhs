import type { AgendaEntry } from '../../../types';

/**
 * Microcopy nova de M09 (não consta em docs/02): rótulos de apoio da pauta editável e
 * mensagens de anúncio acessível. Nenhum fato novo. Registrada em qa/RELATORIO.md.
 */
export const m09Microcopy = {
  sheetTitle: 'Pauta de conversa',
  sheetWithTemplate: 'com {fullName}, {role}',
  noPriorities: 'Nenhuma prioridade escolhida.',
  noTopics: 'Nenhum assunto adicionado ainda.',
  addButton: 'Incluir',
  addHint: 'Escreva com suas palavras. Até {max} caracteres.',
  cancel: 'Cancelar',
  editLabel: 'Editar assunto',
  duplicate: 'Esse assunto já está na pauta.',
  limit: 'A pauta chegou ao limite de assuntos livres. Remova um para incluir outro.',
  empty: 'Escreva um assunto antes de incluir.',
  added: '{label} adicionado à pauta.',
  updated: 'Assunto atualizado.',
  removed: '{label} removido da pauta.',
  moved: '{label} agora está na posição {position}.',
  cleared: 'Escolhas limpas. A pauta está vazia.',
  clearConfirmTitle: 'Limpar escolhas?',
  clearConfirmBody: 'As prioridades e os assuntos desta pauta serão apagados. O nome da empresa é mantido.',
  clearKeep: 'Manter pauta',
  /** "Copiar pauta" em M09 com a pauta vazia (botão desabilitado + orientação visível). */
  copyEmptyHint: 'Escolha uma prioridade ou adicione um assunto para copiar a pauta.',
} as const;

export const kindLabel: Record<AgendaEntry['kind'], string> = {
  frente: 'Frente',
  aplicacao: 'Aplicação',
  servico: 'Serviço',
  nota: 'Seu assunto',
};
