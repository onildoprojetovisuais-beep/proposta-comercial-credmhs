import { useEffect, useRef } from 'react';
import styles from './AgendaTextFallback.module.css';

/**
 * Último passo da cadeia de "Copiar pauta" (Clipboard API → execCommand → texto selecionável),
 * compartilhado por M09 e M10: quando a cópia automática falha, mostra o texto da pauta já
 * selecionado para a cópia manual (docs/03).
 */
export function AgendaTextFallback({ id, label, text }: { id: string; label: string; text: string }) {
  const ref = useRef<HTMLTextAreaElement>(null);
  useEffect(() => {
    ref.current?.select();
  }, []);
  return (
    <div className={styles.fallback}>
      <label htmlFor={id} className={styles.label}>
        {label}
      </label>
      <textarea
        ref={ref}
        id={id}
        className={`field ${styles.textarea}`}
        readOnly
        value={text}
        rows={Math.min(14, text.split('\n').length + 1)}
      />
    </div>
  );
}
