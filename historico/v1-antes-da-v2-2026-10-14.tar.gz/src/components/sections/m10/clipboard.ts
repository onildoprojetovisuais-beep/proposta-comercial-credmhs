/**
 * Copia texto iniciado por gesto do visitante.
 * 1) Clipboard API (contexto seguro); 2) execCommand('copy') com textarea temporária;
 * 3) false → a UI mostra o texto selecionável e orienta a cópia manual (docs/03).
 */
export async function copyText(text: string): Promise<boolean> {
  try {
    if (typeof navigator !== 'undefined' && navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    // segue para o fallback
  }
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.top = '-1000px';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    const active = document.activeElement as HTMLElement | null;
    ta.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    active?.focus({ preventScroll: true });
    return ok;
  } catch {
    return false;
  }
}
