/**
 * Microcopy nova de M10 (não consta em docs/02): orientações de uso dos canais.
 * Nenhuma promete envio. Registrada em qa/RELATORIO.md.
 */
export const m10Microcopy = {
  messageHint: 'Revise e ajuste o texto. Ele só sai daqui quando você decidir.',
  outdated: 'Suas escolhas mudaram depois que você editou o texto.',
  emailPrepared: 'Mensagem preparada. Revise e envie pelo seu aplicativo de e-mail.',
  noAutoSend: 'Os botões abrem o seu aplicativo de e-mail, telefone ou navegador. Nada é enviado automaticamente.',
  otherChannels: 'Outros canais',
  emailLabel: 'E-mail',
  agendaFallbackLabel: 'Texto da pauta',
  messageFallbackHint: 'O texto da mensagem está selecionado no campo acima.',
  website: 'Site da CRED MHS',
  newTab: '(abre em nova aba)',
} as const;
