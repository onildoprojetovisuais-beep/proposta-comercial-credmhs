import { useEffect, useState } from 'react';
import { usePresentationState } from '../../../state';
import { copyText } from './clipboard';

export type AgendaCopyStatus = 'idle' | 'copied' | 'failed';

/**
 * "Copiar pauta" compartilhado por M09 e M10: mesmo texto (`agendaText`, de buildAgendaText) e
 * mesma cadeia de cópia (copyText). O status volta a 'idle' no reset/limpeza e quando a pauta muda,
 * para nenhum feedback antigo descrever um texto diferente do atual.
 */
export function useAgendaCopy() {
  const { agendaText, state } = usePresentationState();
  const [status, setStatus] = useState<AgendaCopyStatus>('idle');

  useEffect(() => setStatus('idle'), [state.resetCount, agendaText]);

  async function copyAgenda(): Promise<boolean> {
    const ok = await copyText(agendaText);
    setStatus(ok ? 'copied' : 'failed');
    return ok;
  }

  return { agendaText, status, copyAgenda, resetStatus: () => setStatus('idle') };
}
