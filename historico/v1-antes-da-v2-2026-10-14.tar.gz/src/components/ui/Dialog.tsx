import { useEffect, useId, useRef } from 'react';
import type { ReactNode, RefObject } from 'react';
import styles from './Dialog.module.css';

/**
 * Dialog — <dialog> nativo com showModal(): fundo inerte, foco preso no diálogo,
 * Esc fecha e o foco volta ao elemento que abriu.
 *
 * Props:
 * - open: estado controlado.
 * - onClose(): chamado em Esc, clique no fundo e botão Fechar.
 * - title: título visível (aria-labelledby).
 * - description?: apoio curto sob o título (aria-describedby).
 * - children: conteúdo; footer?: ações no rodapé.
 * - size?: 'sm' | 'md' (padrão) | 'lg'.
 * - placement?: 'center' (padrão) | 'side' (painel lateral ≥1024px). No mobile vira folha inferior.
 * - closeLabel?: rótulo do botão de fechar (padrão "Fechar").
 * - initialFocusRef?: elemento que recebe foco ao abrir (padrão: botão Fechar).
 * - returnFocusRef?: para onde devolver o foco (padrão: elemento ativo antes de abrir).
 */
export interface DialogProps {
  open: boolean;
  onClose: () => void;
  title: ReactNode;
  description?: ReactNode;
  children?: ReactNode;
  footer?: ReactNode;
  size?: 'sm' | 'md' | 'lg';
  placement?: 'center' | 'side';
  closeLabel?: string;
  initialFocusRef?: RefObject<HTMLElement>;
  returnFocusRef?: RefObject<HTMLElement>;
  className?: string;
}

export function Dialog({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  size = 'md',
  placement = 'center',
  closeLabel = 'Fechar',
  initialFocusRef,
  returnFocusRef,
  className,
}: DialogProps) {
  const ref = useRef<HTMLDialogElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const openerRef = useRef<HTMLElement | null>(null);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;
  const returnRef = useRef(returnFocusRef);
  returnRef.current = returnFocusRef;
  const titleId = useId();
  const descId = useId();

  useEffect(() => {
    const dialog = ref.current;
    if (!dialog) return;
    if (open && !dialog.open) {
      openerRef.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
      dialog.showModal();
      document.documentElement.dataset.dialogOpen = 'true';
      (initialFocusRef?.current ?? closeRef.current)?.focus();
    } else if (!open && dialog.open) {
      dialog.close();
    }
  }, [open, initialFocusRef]);

  useEffect(() => {
    const dialog = ref.current;
    if (!dialog) return;
    // Ao fechar: libera rolagem e devolve o foco ao acionador.
    const handleClose = () => {
      delete document.documentElement.dataset.dialogOpen;
      const target = returnRef.current?.current ?? openerRef.current;
      if (target && document.contains(target)) target.focus({ preventScroll: true });
    };
    // Esc dispara "cancel": o estado controlado decide o fechamento.
    const handleCancel = (e: Event) => {
      e.preventDefault();
      onCloseRef.current();
    };
    dialog.addEventListener('close', handleClose);
    dialog.addEventListener('cancel', handleCancel);
    return () => {
      dialog.removeEventListener('close', handleClose);
      dialog.removeEventListener('cancel', handleCancel);
      delete document.documentElement.dataset.dialogOpen;
    };
  }, []);

  return (
    <dialog
      ref={ref}
      className={[styles.dialog, styles[size], styles[placement], className ?? ''].filter(Boolean).join(' ')}
      aria-labelledby={titleId}
      aria-describedby={description ? descId : undefined}
      onClick={(e) => {
        // Clique no backdrop (o próprio <dialog>, fora do conteúdo) fecha.
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className={styles.inner}>
        <header className={styles.header}>
          <div className={styles.heading}>
            <h2 id={titleId} className={styles.title}>
              {title}
            </h2>
            {description ? (
              <p id={descId} className={styles.description}>
                {description}
              </p>
            ) : null}
          </div>
          <button ref={closeRef} type="button" className={styles.close} onClick={onClose}>
            <span className={styles.closeIcon} aria-hidden="true" />
            <span className={styles.closeLabel}>{closeLabel}</span>
          </button>
        </header>
        {children ? <div className={styles.body}>{children}</div> : null}
        {footer ? <footer className={styles.footer}>{footer}</footer> : null}
      </div>
    </dialog>
  );
}
