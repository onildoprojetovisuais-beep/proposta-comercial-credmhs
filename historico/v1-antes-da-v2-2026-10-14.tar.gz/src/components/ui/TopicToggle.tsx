import { forwardRef } from 'react';
import type { ButtonHTMLAttributes } from 'react';
import { IconCheck, IconPlus } from './icons';
import styles from './TopicToggle.module.css';

/**
 * TopicToggle — ÚNICO controle "Adicionar à conversa / Remover da conversa" (M05, M06, M07…).
 *
 * Estado (layout v2, igual em toda a página):
 * - fora da pauta: contorno + ícone "+" + addLabel.
 * - na pauta:      PREENCHIDO (tinta no claro/amarelo; branco no escuro) + "✓" + removeLabel.
 * A11y: `aria-pressed` reflete o estado; o nome acessível contém o rótulo visível + o assunto
 * ("Remover da conversa: eSocial"), cumprindo WCAG 2.5.3 (label in name).
 * Altura fixa (--toggle-h 48px), 16px bold, sem quebra de linha.
 *
 * Props:
 * - selected: boolean — o assunto está na pauta.
 * - onToggle(): alterna.
 * - subject: nome do assunto (entra só no nome acessível).
 * - tone?: 'light' (padrão; superfícies paper/white/yellow) | 'dark' (superfície escura).
 * - addLabel? / removeLabel?: rótulos visíveis (padrão = copy docs/02). Prefira passar os de `copy`.
 * - block?: ocupa a largura do container (use só no mobile, se a composição pedir).
 * - compact?: abaixo de 560px vira um disco de 48×48 só com o ícone (+ / ✓). O rótulo continua no
 *   nome acessível ("Adicionar à conversa: assunto"). Use em listas longas (M05 catálogo), onde o
 *   rótulo do assunto fica ao lado e a linha inteira também alterna.
 */
export interface TopicToggleProps
  extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'onClick' | 'children' | 'aria-pressed'> {
  selected: boolean;
  onToggle: () => void;
  subject: string;
  tone?: 'light' | 'dark';
  addLabel?: string;
  removeLabel?: string;
  block?: boolean;
  compact?: boolean;
}

export const TopicToggle = forwardRef<HTMLButtonElement, TopicToggleProps>(function TopicToggle(
  {
    selected,
    onToggle,
    subject,
    tone = 'light',
    addLabel = 'Adicionar à conversa',
    removeLabel = 'Remover da conversa',
    block,
    compact,
    className,
    type,
    ...rest
  },
  ref,
) {
  return (
    <button
      ref={ref}
      type={type ?? 'button'}
      aria-pressed={selected}
      data-selected={selected}
      className={[styles.toggle, styles[tone], block ? styles.block : '', compact ? styles.compact : '', className ?? '']
        .filter(Boolean)
        .join(' ')}
      onClick={onToggle}
      {...rest}
    >
      <span className={styles.icon} aria-hidden="true">
        {selected ? <IconCheck /> : <IconPlus />}
      </span>
      <span className={styles.label}>
        {selected ? removeLabel : addLabel}
        <span className="visually-hidden">: {subject}</span>
      </span>
    </button>
  );
});
