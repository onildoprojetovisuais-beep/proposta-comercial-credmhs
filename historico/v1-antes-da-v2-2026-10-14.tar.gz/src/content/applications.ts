import type { Application, ApplicationId } from '../types';

/**
 * M07 — Aplicações específicas (docs/02-copy.md, M07; slides 11–14).
 * - eSocial: não inventar as "4 soluções" do slide 11 (P08).
 * - FAP/NTEP: sem promessa de redução de alíquota/economia; arquitetura "seu sistema" ambígua (P11).
 * - Riscos Psicossociais: nunca renomear como VIVA (P16).
 */
export const applications: readonly Application[] = [
  {
    id: 'esocial',
    label: 'eSocial',
    summary: 'Integração entre a gestão de saúde e segurança, com recursos de conexão entre sistemas.',
    detail:
      'Um sistema de gestão online interliga os locais de atendimento da CRED e integra informações de saúde e segurança, com parametrização para o eSocial e recursos de integração via webservice com sistemas ERP.',
    topicId: 'aplicacao:esocial',
    sourceSlides: [11, 12],
  },
  {
    id: 'fap-ntep',
    label: 'Gestão de FAP/NTEP',
    summary: 'Integração de informações e acompanhamento das etapas do processo.',
    detail:
      'Os envolvidos acompanham as etapas do processo, com integração entre os sistemas de gestão de saúde e segurança.',
    topicId: 'aplicacao:fap-ntep',
    sourceSlides: [13],
  },
  {
    id: 'riscos-psicossociais',
    label: 'Riscos Psicossociais',
    summary: 'Programa de Vigilância Epidemiológica estruturado sob medida.',
    detail:
      'Programa desenvolvido para a realidade da empresa e integrado às demais legislações e iniciativas sobre o tema.',
    topicId: 'aplicacao:riscos-psicossociais',
    sourceSlides: [14],
  },
];

export const applicationById: Readonly<Record<ApplicationId, Application>> = Object.fromEntries(
  applications.map((a) => [a.id, a]),
) as Record<ApplicationId, Application>;
