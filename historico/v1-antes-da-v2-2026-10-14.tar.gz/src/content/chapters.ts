import type { CapacityDetailId, Chapter, ChapterId } from '../types';

/**
 * Copy completa por capítulo (docs/02-copy.md). Variáveis entre chaves são preenchidas com
 * `formatTemplate` (src/lib/format.ts): {firstName}, {fullName}, {empresa}, {count}.
 * Notas internas e marcadores de fonte NÃO fazem parte destes textos.
 * Itens marcados "microcopy nova" não estão em docs/02; são complementos mínimos de interface.
 */
export const copy = {
  m01: {
    eyebrowTemplate: '{fullName}',
    roleTemplate: '{role}',
    titleTemplate: 'Olá, eu sou {firstName}.',
    body: 'Quero conhecer sua empresa e apresentar como a CRED MHS pode apoiar sua gestão de saúde e segurança do trabalho.',
    cta: 'Conhecer a CRED',
    brand: 'CRED MHS',
    brandDescriptor: 'Gestão de Saúde e Segurança do Trabalho',
  },

  m02: {
    title: 'A gestão de saúde e segurança começa pelo seu negócio',
    body: 'A CRED MHS é uma Operadora de Saúde e Segurança do Trabalho com atuação nacional e experiência multissetorial. Nossa equipe entende as necessidades de cada empresa para propor soluções na medida certa.',
    question: 'O que merece mais atenção na sua operação hoje?',
    instruction: 'Escolha até duas prioridades.',
    // Microcopy nova (docs/07, P21): explica cedo a função da pauta. {firstName} vem do perfil.
    agendaHintTemplate: 'Ao explorar as soluções, você pode reunir assuntos para conversar com {firstName}.',
    // Opções: usar `priorities` (src/content/priorities.ts), na ordem definida.
    company: {
      toggleLabel: 'Personalizar com o nome da empresa',
      fieldLabel: 'Nome da empresa',
      placeholder: 'Como sua empresa se chama?',
      help: 'Opcional. O nome será usado para organizar sua pauta nesta apresentação.',
    },
    confirmation: 'Vamos destacar essas frentes ao longo da apresentação.',
    cta: 'Continuar',
    alternative: 'Conhecer a atuação completa',
    limitMessage: 'Para escolher outra prioridade, remova uma das duas selecionadas.',
    transition: 'Conheça a estrutura que sustenta essa atuação.',
  },

  m03: {
    title: 'Estrutura nacional para apoiar sua operação',
    body: 'Unidades, rede credenciada e equipe multidisciplinar sustentam a atuação da CRED em saúde e segurança do trabalho.',
    // Indicadores: usar `capacityFacts` (src/content/facts.ts). Alcance: `reachText`.
    reach: 'Atuação nacional',
    cta: 'Conhecer a estrutura',
    details: [
      {
        id: 'equipe' as CapacityDetailId,
        label: 'Equipe multidisciplinar',
        text: 'Engenheiros do Trabalho, Técnicos de Segurança e profissionais de áreas afins participam da implantação e adequação das soluções de Segurança do Trabalho.',
        sourceSlides: [8],
      },
      {
        id: 'recursos-proprios' as CapacityDetailId,
        label: 'Recursos próprios',
        text: 'A CRED dispõe de parque próprio de equipamentos tecnológicos para realização de medições.',
        sourceSlides: [11],
      },
      {
        id: 'in-company' as CapacityDetailId,
        label: 'Atendimento na empresa',
        text: 'O portfólio inclui exames ocupacionais in company.',
        sourceSlides: [7],
      },
    ],
    transition: 'Essa atuação está presente no percurso de empresas de diferentes contextos.',
  },

  m04: {
    title: 'Empresas no percurso da CRED',
    body: 'Conheça algumas das empresas que fazem parte do percurso da CRED MHS.',
    cta: 'Ver outras empresas',
    collapse: 'Mostrar menos empresas',
    // Marcas: `featuredClients` / `otherClients` (src/content/clients.ts).
  },

  m05: {
    title: 'Soluções conectadas à realidade da sua empresa',
    body: 'Saúde Ocupacional, Segurança do Trabalho, Gestão e Tecnologia e Treinamentos compõem um ecossistema de serviços integrados e adaptáveis às necessidades da sua operação.',
    priorityBadge: 'Sua prioridade',
    controls: {
      showServices: 'Ver serviços',
      hideServices: 'Ocultar serviços',
      add: 'Adicionar à conversa',
      remove: 'Remover da conversa',
    },
    // Microcopy nova (docs/07, P21): explicada uma vez no início do ecossistema, não em cada item.
    addHintTemplate: 'Use “Adicionar à conversa” nos assuntos que quiser retomar com {firstName}. Eles aparecem na sua pauta, no final.',
    // Frentes: `serviceAreas`; adicionais: `additionalServices` + `additionalServicesCopy` (src/content/ecosystem.ts).
  },

  m06: {
    title: 'Informações para acompanhar a gestão',
    body: 'Portal de serviços, integrações com sistemas e indicadores ampliam a visibilidade sobre a operação de saúde e segurança.',
    aspects: [
      {
        id: 'acompanhamento',
        label: 'Acompanhamento',
        text: 'Um portal de serviços online permite ao cliente acompanhar atendimento e SLA.',
        sourceSlides: [11],
      },
      {
        id: 'integracao',
        label: 'Integração',
        text: 'Recursos de conexão entre sistemas, importação e exportação de dados apoiam a integração da gestão de saúde e segurança.',
        sourceSlides: [9, 12],
      },
      {
        id: 'informacao-gerencial',
        label: 'Informação gerencial',
        text: 'Customização de dados, indicadores e integração à Fábrica de Power BI apoiam a visão da gestão.',
        sourceSlides: [9, 11],
      },
    ],
    mediaCaption: 'Visão conceitual das capacidades de gestão',
    cta: 'Explorar recursos de tecnologia',
    complementary: [
      'Teleatendimento e telediagnóstico',
      'Gestão eletrônica de documentos',
      'Assinatura digital',
      'Aplicativo móvel',
      'Acervo fotográfico',
      'Saúde remota',
      'Biometria',
      'Sistema em nuvem',
      'Central EAD integrada',
    ],
    shortcut: 'Ir para aplicações',
  },

  m07: {
    title: 'Qual necessidade vamos aprofundar?',
    body: 'Explore frentes que se aproximam da realidade da sua empresa.',
    controls: {
      open: 'Conhecer a solução',
      add: 'Adicionar à conversa',
      remove: 'Remover da conversa',
    },
    alternative: 'Ver outras soluções',
    // Aplicações: `applications` (src/content/applications.ts).
  },

  m08: {
    // Use `trustMode` (src/content/credentials.ts) para escolher o estado. Hoje: 'fallback'.
    credentials: {
      title: 'Referências de qualidade e gestão',
      // Cada credencial exibível usa apenas label/holder/scope/validity fornecidos.
    },
    fallback: {
      title: 'Pessoas e estrutura para apoiar a gestão',
      body: 'Equipe multidisciplinar, equipamentos próprios e recursos de acompanhamento apoiam a gestão de saúde e segurança.',
    },
  },

  m09: {
    titleWithCompanyTemplate: 'Uma conversa sobre {empresa}',
    titleWithoutCompany: 'Uma conversa sobre a sua operação',
    bodyTemplate: 'Estas são as prioridades e os assuntos que você selecionou para conversar com {firstName}.',
    groupPriorities: 'Suas prioridades',
    groupTopics: 'Assuntos para aprofundar',
    actions: {
      editPriorities: 'Editar prioridades',
      exploreMore: 'Explorar mais soluções',
      removeTopic: 'Remover assunto',
      clear: 'Limpar escolhas',
      // Microcopy nova (edição/reordenação de itens livres da pauta):
      addCustom: 'Incluir outro assunto',
      customPlaceholder: 'Escreva um assunto para a conversa',
      saveCustom: 'Salvar',
      editCustom: 'Editar',
      moveUp: 'Mover para cima',
      moveDown: 'Mover para baixo',
    },
    empty: 'Podemos começar entendendo sua operação. Se preferir, explore as soluções e selecione os assuntos que deseja conversar.',
    cta: 'Preparar a conversa',
    commercialNote: 'A seleção organiza nossa conversa. O escopo da atuação será discutido com a sua empresa.',
  },

  m10: {
    title: 'Vamos conversar sobre a sua empresa?',
    body: 'Podemos entender suas necessidades e pensar juntos como a CRED MHS pode integrar sua gestão.',
    primaryCtaTemplate: 'Preparar e-mail para {firstName}',
    alternatives: {
      copyAgenda: 'Copiar pauta',
      callTemplate: 'Ligar para {firstName}',
      linkedIn: 'Ver LinkedIn',
    },
    whatsAppCtaTemplate: 'Conversar com {firstName} pelo WhatsApp',
    previewTitle: 'Sua mensagem',
    controls: {
      edit: 'Editar mensagem',
      openEmail: 'Abrir meu e-mail',
      copy: 'Copiar mensagem',
      back: 'Voltar',
      refresh: 'Atualizar mensagem com minhas escolhas',
    },
    feedback: {
      agendaCopied: 'Pauta copiada.',
      messageCopied: 'Mensagem copiada.',
      copyFailed: 'Não foi possível copiar automaticamente. Selecione e copie o texto abaixo.',
      messagePrepared: 'Mensagem preparada',
      // Microcopy nova (docs/03: mensagem acima do limite de URL):
      longMessage: 'A mensagem ficou longa para abrir completa no e-mail. Copie o texto e cole na mensagem que será aberta.',
    },
    emailSubject: 'Conversa sobre a CRED MHS',
  },

  global: {
    menu: 'Conteúdo',
    skipLink: 'Pular para o conteúdo',
    agendaCounterTemplate: 'Sua pauta ({count})',
    // Microcopy nova (layout v2): rótulo visível do contador em telas < 480px.
    agendaCounterShortTemplate: 'Pauta {count}',
    // "Nova apresentação" (pedido de Nil): mesmo fluxo do antigo "Reiniciar apresentação",
    // para preparar a apresentação para o próximo cliente. Mantém o executivo da URL.
    reset: {
      label: 'Nova apresentação',
      confirm:
        'Começar uma nova apresentação apaga o nome da empresa, as prioridades e a pauta desta sessão. O executivo continua o mesmo.',
      confirmAction: 'Começar nova',
      cancelAction: 'Continuar apresentação',
    },
    close: 'Fechar',
  },
} as const;

/**
 * Capítulos e índice (docs/02 "Navegação e estados globais"; docs/07 matriz de cobertura).
 * `slug` é o hash da URL. URL só identifica executivo e capítulo.
 */
export const chapters: readonly Chapter[] = [
  { id: 'm01', code: 'M01', slug: 'apresentacao', navLabel: 'Apresentação', title: copy.m01.titleTemplate, body: copy.m01.body, sourceSlides: [1, 2, 3, 19], contentKey: 'm01' },
  { id: 'm02', code: 'M02', slug: 'prioridades', navLabel: 'Suas prioridades', title: copy.m02.title, body: copy.m02.body, sourceSlides: [2, 3, 4, 5], contentKey: 'm02' },
  { id: 'm03', code: 'M03', slug: 'estrutura', navLabel: 'Estrutura', title: copy.m03.title, body: copy.m03.body, sourceSlides: [6, 7, 8, 11, 17], contentKey: 'm03' },
  { id: 'm04', code: 'M04', slug: 'empresas', navLabel: 'Empresas', title: copy.m04.title, body: copy.m04.body, sourceSlides: [16], contentKey: 'm04' },
  { id: 'm05', code: 'M05', slug: 'ecossistema', navLabel: 'Ecossistema', title: copy.m05.title, body: copy.m05.body, sourceSlides: [5, 7, 8, 9, 10, 15], contentKey: 'm05' },
  { id: 'm06', code: 'M06', slug: 'gestao-e-tecnologia', navLabel: 'Gestão e tecnologia', title: copy.m06.title, body: copy.m06.body, sourceSlides: [9, 10, 11, 12], contentKey: 'm06' },
  { id: 'm07', code: 'M07', slug: 'aplicacoes', navLabel: 'Aplicações', title: copy.m07.title, body: copy.m07.body, sourceSlides: [11, 12, 13, 14], contentKey: 'm07' },
  { id: 'm08', code: 'M08', slug: 'confianca', navLabel: 'Confiança', title: copy.m08.fallback.title, body: copy.m08.fallback.body, sourceSlides: [8, 9, 11, 18], contentKey: 'm08' },
  { id: 'm09', code: 'M09', slug: 'sua-pauta', navLabel: 'Sua pauta', title: copy.m09.titleWithoutCompany, sourceSlides: [2, 5, 14, 19], contentKey: 'm09' },
  { id: 'm10', code: 'M10', slug: 'contato', navLabel: 'Contato', title: copy.m10.title, body: copy.m10.body, sourceSlides: [19], contentKey: 'm10' },
];

export const chapterById: Readonly<Record<ChapterId, Chapter>> = Object.fromEntries(
  chapters.map((c) => [c.id, c]),
) as Record<ChapterId, Chapter>;

/** Resolve um hash (#estrutura) para o capítulo; desconhecido → null. */
export function chapterFromHash(hash: string): Chapter | null {
  let slug = hash.replace(/^#/, '');
  try {
    slug = decodeURIComponent(slug);
  } catch {
    return null;
  }
  slug = slug.trim().toLowerCase();
  return chapters.find((c) => c.slug === slug) ?? null;
}
