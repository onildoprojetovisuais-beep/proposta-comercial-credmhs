import type { ChapterId, SourceSlide } from '../types';

/**
 * Mapa de cobertura fonte → destino (docs/05 "Dados de conteúdo"; docs/07 "Matriz de cobertura").
 * Uso interno de rastreabilidade. Nunca renderizar ao prospect.
 *
 * treatment:
 * - principal: aparece na leitura principal
 * - detalhe: preservado em aprofundamento (expansão/catálogo)
 * - condensado: sintetizado; redação original preservada em sources/
 * - inventario: preservado só no inventário (dados/fonte), não exibido
 * - retido: retido por pendência (ID de docs/07)
 */
export type CoverageTreatment = 'principal' | 'detalhe' | 'condensado' | 'inventario' | 'retido';

export interface CoverageEntry {
  slide: SourceSlide;
  item: string;
  destination: ChapterId[];
  /** Local no código de conteúdo. */
  dataRef: string;
  treatment: CoverageTreatment;
  pendingRef?: string;
  note?: string;
}

export const coverage: readonly CoverageEntry[] = [
  // Slide 01
  { slide: 1, item: 'Marca CRED MHS', destination: ['m01'], dataRef: 'copy.m01.brand', treatment: 'principal' },
  { slide: 1, item: '“entre as 5 maiores em Saúde e Segurança do Trabalho”', destination: [], dataRef: 'facts#ranking', treatment: 'retido', pendingRef: 'P02' },

  // Slide 02
  { slide: 2, item: 'Caminhar lado a lado dos clientes na jornada de gestão', destination: ['m01', 'm02'], dataRef: 'copy.m01.body / copy.m02.body', treatment: 'condensado' },
  { slide: 2, item: 'Equipe personalizada que entende necessidades e sugere soluções na medida certa', destination: ['m02', 'm09'], dataRef: 'copy.m02.body', treatment: 'principal' },

  // Slide 03
  { slide: 3, item: '“Pessoas no centro” e convite a descobrir benefícios', destination: ['m01', 'm02'], dataRef: 'copy.m01 (orientação humana, retrato)', treatment: 'condensado', note: 'O slide anuncia benefícios sem especificá-los; nenhum benefício foi criado.' },
  { slide: 3, item: 'www.credmhs.com.br', destination: ['m10'], dataRef: 'executives.websiteUrl', treatment: 'principal' },

  // Slide 04
  { slide: 4, item: 'Operadora de Saúde e Segurança do Trabalho, atuação estratégica, abrangência nacional, experiência multissetorial', destination: ['m02', 'm03'], dataRef: 'copy.m02.body / copy.m03.reach', treatment: 'condensado' },
  { slide: 4, item: '“30 anos”', destination: [], dataRef: 'facts#tempo-experiencia', treatment: 'retido', pendingRef: 'P01' },
  { slide: 4, item: 'Investimento em pessoas; gestão de SST como força estratégica para o negócio', destination: ['m02'], dataRef: 'copy.m02.title', treatment: 'condensado', note: 'Redação original preservada em sources/apresentacao-original.md.' },

  // Slide 05
  { slide: 5, item: 'Ecossistema de soluções com serviços integrados, customização, “do seu jeito”', destination: ['m05', 'm02'], dataRef: 'copy.m05.body', treatment: 'condensado' },
  { slide: 5, item: 'Quatro frentes (Gestão de Tecnologia padronizada como Gestão e Tecnologia)', destination: ['m02', 'm05'], dataRef: 'serviceAreas / priorities', treatment: 'principal' },

  // Slide 06
  { slide: 6, item: 'Gestão estratégica e valor em SSO, disponível para empresas de todo Brasil', destination: ['m03'], dataRef: 'copy.m03.title / reachText', treatment: 'condensado', note: 'Sem geolocalização ou endereços inventados.' },

  // Slide 07
  { slide: 7, item: 'Solução para requisitos da NR-7, documentos obrigatórios e ferramentas auxiliares', destination: ['m05'], dataRef: 'serviceAreas#saude.detail / extras', treatment: 'detalhe' },
  { slide: 7, item: 'PCMSO, ASO, Relatório Anual, PPP, Gestão dos Exames, Convocação de Periódicos', destination: ['m05'], dataRef: 'serviceAreas#saude.services', treatment: 'detalhe' },
  { slide: 7, item: 'Exames Ocupacionais In Company', destination: ['m05', 'm03'], dataRef: 'serviceAreas#saude.services / copy.m03.details#in-company', treatment: 'detalhe' },
  { slide: 7, item: '“e muitos outros…”', destination: [], dataRef: 'sources', treatment: 'inventario', note: 'Não enumerar itens não citados.' },

  // Slide 08
  { slide: 8, item: 'Equipe multidisciplinar (Engenheiros, Técnicos, áreas afins); implantação, adequação, auditoria', destination: ['m05', 'm03', 'm08'], dataRef: 'serviceAreas#seguranca.detail / copy.m03.details#equipe / copy.m08.fallback', treatment: 'principal' },
  { slide: 8, item: 'PGR/GRO, PCMAT, LTCAT, CIPA, Perícias, Laudos, Ordens de Serviço, Gestão de EPI', destination: ['m05'], dataRef: 'serviceAreas#seguranca.services', treatment: 'detalhe', pendingRef: 'P10' },

  // Slide 09
  { slide: 9, item: 'Customização de dados, mentoria para ativação de módulos, aprendizagem dos profissionais, indicadores', destination: ['m05', 'm06'], dataRef: 'serviceAreas#gestao.detail / copy.m06.aspects', treatment: 'detalhe' },
  { slide: 9, item: 'Integração ERP, interface online, GED, assinatura digital, app, acervo fotográfico, saúde remota, biometria, nuvem', destination: ['m05', 'm06'], dataRef: 'serviceAreas#gestao.services / copy.m06.complementary', treatment: 'detalhe' },
  { slide: 9, item: '“100% aderente” / “100% na nuvem”', destination: ['m05'], dataRef: 'serviceAreas#gestao.services', treatment: 'condensado', note: '“100%” preservado só na fonte (docs/02).' },
  { slide: 9, item: '“Certificada ISO 9001 e ISO45001”', destination: [], dataRef: 'credentials', treatment: 'retido', pendingRef: 'P05' },
  { slide: 9, item: '“Totalmente adequada à LGPD”', destination: [], dataRef: 'credentials#lgpd', treatment: 'retido', pendingRef: 'P06' },

  // Slide 10
  { slide: 10, item: 'Central EAD, mais de 77 cursos, conformidade declarada com NR1', destination: ['m05'], dataRef: 'serviceAreas#treinamento.detail / facts#cursos-ead', treatment: 'detalhe', pendingRef: 'P09', note: 'Conformidade NR1 mantida no registro, não exibida como certificação.' },
  { slide: 10, item: 'Lista de 12 temas NR', destination: ['m05'], dataRef: 'serviceAreas#treinamento.services', treatment: 'detalhe', pendingRef: 'P10' },
  { slide: 10, item: 'Emissão/gestão de certificados, conteúdo programático, listas de presença integrados ao software', destination: ['m05', 'm06'], dataRef: 'serviceAreas#treinamento.detail / copy.m06.complementary', treatment: 'detalhe' },
  { slide: 10, item: 'Mapeamento dos normativos e automação dos personalizados; multiplataforma', destination: ['m05'], dataRef: 'serviceAreas#treinamento.extras', treatment: 'detalhe' },
  { slide: 10, item: '“Prático, Seguro, Intuitivo, Econômico, Atualizado”', destination: [], dataRef: 'sources', treatment: 'inventario', note: 'Adjetivos não exibidos; “Multi-plataformas” preservado como acesso multiplataforma.' },

  // Slide 11
  { slide: 11, item: 'Portal de Serviços On-line; acompanhamento do atendimento e SLA', destination: ['m06'], dataRef: 'copy.m06.aspects#acompanhamento', treatment: 'principal' },
  { slide: 11, item: 'Teleatendimento e Telediagnóstico', destination: ['m06'], dataRef: 'copy.m06.complementary', treatment: 'detalhe' },
  { slide: 11, item: 'Ecossistema “em um único lugar”', destination: ['m05'], dataRef: 'copy.m05.body', treatment: 'condensado' },
  { slide: 11, item: 'Parque Próprio de Equipamentos Tecnológicos para medições', destination: ['m03', 'm08'], dataRef: 'copy.m03.details#recursos-proprios / copy.m08.fallback', treatment: 'detalhe', note: '“de última geração” não reproduzido.' },
  { slide: 11, item: '4 Soluções para o eSocial', destination: ['m07'], dataRef: 'facts#solucoes-esocial', treatment: 'retido', pendingRef: 'P08' },
  { slide: 11, item: 'Integração à Fábrica de Power BI', destination: ['m06'], dataRef: 'copy.m06.aspects#informacao-gerencial', treatment: 'principal' },
  { slide: 11, item: 'Central EAD integrada ao software de gestão', destination: ['m05', 'm06'], dataRef: 'serviceAreas#treinamento / copy.m06.complementary', treatment: 'detalhe' },

  // Slide 12
  { slide: 12, item: 'Sistema online que interliga locais de atendimento; parametrização eSocial; webservice com ERP', destination: ['m07', 'm06'], dataRef: 'applications#esocial', treatment: 'detalhe', note: '“100%”, “em tempo real” e “qualquer software ERP” preservados só na fonte.' },

  // Slide 13
  { slide: 13, item: 'Gestão do FAP/NTEP: acompanhamento das etapas pelos envolvidos, integração entre sistemas', destination: ['m07'], dataRef: 'applications#fap-ntep', treatment: 'condensado', pendingRef: 'P11' },

  // Slide 14
  { slide: 14, item: 'Riscos Psicossociais NR1: Programa de Vigilância Epidemiológica sob medida', destination: ['m07'], dataRef: 'applications#riscos-psicossociais', treatment: 'principal', pendingRef: 'P16', note: 'Referência “NR1” preservada na fonte; não renomear como VIVA.' },

  // Slide 15
  { slide: 15, item: 'Dez soluções adicionais', destination: ['m05', 'm09'], dataRef: 'additionalServices', treatment: 'detalhe' },

  // Slide 16
  { slide: 16, item: 'Título “Empresas que estão no percurso com soluções exclusivas, inovadoras e sob medida”', destination: ['m04'], dataRef: 'copy.m04.title', treatment: 'condensado' },
  { slide: 16, item: 'Relação textual de 37 empresas', destination: ['m04'], dataRef: 'clients', treatment: 'principal', pendingRef: 'P07' },
  { slide: 16, item: 'Logos incorporados em imagem no PPTX', destination: ['m04'], dataRef: 'clients[].logo', treatment: 'retido', pendingRef: 'P07', note: 'Conciliação imagem ↔ nome pendente.' },
  { slide: 16, item: 'Copyright “Todos os direitos reservados a Sabrina Ferreira”', destination: [], dataRef: 'sources', treatment: 'retido', pendingRef: 'P17' },

  // Slide 17
  { slide: 17, item: '16 Unidades; +700 Clínicas Credenciadas; +550k Vidas Gerenciadas; +5k Clientes Atendidos', destination: ['m03'], dataRef: 'capacityFacts', treatment: 'principal', pendingRef: 'P03' },
  { slide: 17, item: '27 Estados Atendidos', destination: ['m03'], dataRef: 'facts#estados-atendidos (fallback “Atuação nacional”)', treatment: 'retido', pendingRef: 'P04' },
  { slide: 17, item: '34 Anos de Experiência', destination: [], dataRef: 'facts#tempo-experiencia', treatment: 'retido', pendingRef: 'P01' },

  // Slide 18
  { slide: 18, item: 'ISO 27001, ISO 9001:2015, ISO 45001', destination: ['m08'], dataRef: 'credentials', treatment: 'retido', pendingRef: 'P05', note: 'M08 usa fallback de pessoas e estrutura.' },
  { slide: 18, item: 'Referência visual LGPD', destination: [], dataRef: 'credentials#lgpd', treatment: 'retido', pendingRef: 'P06' },

  // Slide 19
  { slide: 19, item: 'Sabrina Ferreira, Executiva de Negócios, foto', destination: ['m01', 'm10'], dataRef: 'executives#sabrina-ferreira', treatment: 'principal' },
  { slide: 19, item: 'Telefone, LinkedIn, e-mail, site', destination: ['m10'], dataRef: 'executives#sabrina-ferreira / contactLinks', treatment: 'principal', pendingRef: 'P13' },
  { slide: 19, item: 'Convite a agendar conversa e pensar juntos a integração da gestão', destination: ['m10'], dataRef: 'copy.m10.body', treatment: 'condensado', pendingRef: 'P14', note: 'Sem CTA “Agendar” (não há fluxo de agendamento).' },
];

/** Slides sem nenhuma entrada de cobertura (deve ser vazio). */
export function uncoveredSlides(): SourceSlide[] {
  const covered = new Set(coverage.map((c) => c.slide));
  return Array.from({ length: 19 }, (_, i) => i + 1).filter((s) => !covered.has(s));
}
