import type { Credential } from '../types';

/**
 * M08 — Credenciais (slides 9 e 18; docs/07 P05 e P06).
 * Todas modeladas, nenhuma exibível: faltam titular, escopo e validade.
 * LGPD é tratada separadamente e nunca vira selo de "certificação LGPD".
 */
export const credentials: readonly Credential[] = [
  {
    id: 'iso-27001',
    label: 'ISO 27001',
    kind: 'iso',
    sourceSlides: [18],
    verificationStatus: 'missing',
    displayPolicy: 'hidden-until-confirmed',
    internalNote: 'Citada só no slide 18 (não aparece no slide 9). Falta titular, escopo e validade.',
  },
  {
    id: 'iso-9001',
    label: 'ISO 9001:2015',
    kind: 'iso',
    sourceSlides: [9, 18],
    verificationStatus: 'missing',
    displayPolicy: 'hidden-until-confirmed',
    internalNote: 'Slide 9: "Certificada ISO 9001" dentro da lista de tecnologia — titularidade ambígua (empresa ou sistema).',
  },
  {
    id: 'iso-45001',
    label: 'ISO 45001',
    kind: 'iso',
    sourceSlides: [9, 18],
    verificationStatus: 'missing',
    displayPolicy: 'hidden-until-confirmed',
    internalNote: 'Slide 9: "ISO45001" na lista de tecnologia. Falta titular, escopo e validade.',
  },
  {
    id: 'lgpd',
    label: 'LGPD',
    kind: 'data-protection',
    sourceSlides: [9, 18],
    verificationStatus: 'source-supplied',
    displayPolicy: 'inventory-only',
    internalNote: 'Slide 9: "Totalmente adequada à LGPD"; referência visual no slide 18. Não é certificação (P06).',
  },
];

/** Uma credencial só pode ser exibida com status confirmado e titular/escopo/validade preenchidos. */
export function isCredentialDisplayable(c: Credential): boolean {
  return (
    c.kind === 'iso' &&
    c.verificationStatus === 'confirmed' &&
    !!c.holder?.trim() &&
    !!c.scope?.trim() &&
    !!c.validity?.trim()
  );
}

export const displayableCredentials: readonly Credential[] = credentials.filter(isCredentialDisplayable);

/**
 * Estado de M08: 'credentials' quando houver credencial confirmada e completa; senão 'fallback'
 * (pessoas e estrutura). Hoje: 'fallback'.
 */
export const trustMode: 'credentials' | 'fallback' = displayableCredentials.length > 0 ? 'credentials' : 'fallback';
