import type { AdditionalService, ServiceArea, ServiceAreaId } from '../types';

/**
 * M05 — Ecossistema. Copy de docs/02-copy.md, "Frente 1" a "Frente 4" e "Soluções adicionais".
 * Correções editoriais autorizadas (docs/07): "Annual" → "Anual", plural de "Periódicos",
 * "multidiciplinar" → "multidisciplinar", "Gestão de Tecnologia" → "Gestão e Tecnologia".
 */
export const serviceAreas: readonly ServiceArea[] = [
  {
    id: 'saude',
    label: 'Saúde Ocupacional',
    summary: 'Programas, exames e ferramentas de acompanhamento da saúde do trabalho.',
    detail:
      'A atuação reúne documentos, gestão de exames, relatórios, softwares, soluções customizadas de dados e consultoria especializada para apoiar a gestão de saúde do trabalho.',
    servicesLabel: 'Serviços',
    services: [
      'PCMSO',
      'ASO — Atestado de Saúde Ocupacional',
      'Relatório Anual',
      'PPP — Perfil Profissional Previdenciário',
      'Gestão dos Exames Ocupacionais',
      'Gestão de Convocação de Periódicos',
      'Exames Ocupacionais In Company',
    ],
    extras: [
      {
        label: 'Aprofundamento técnico',
        // Redação comercial (docs/07, P22): a referência à NR-7 fica no inventário até redação técnica validada pela CRED.
        text: 'Além dos documentos obrigatórios, a CRED oferece ferramentas auxiliares para organizar e acompanhar a gestão de saúde do trabalho.',
      },
    ],
    topicId: 'frente:saude',
    sourceSlides: [5, 7],
  },
  {
    id: 'seguranca',
    label: 'Segurança do Trabalho',
    summary: 'Equipe multidisciplinar e soluções para implantação e gestão de segurança.',
    detail:
      'Engenheiros do Trabalho, Técnicos de Segurança e profissionais de áreas afins apoiam a implantação, a adequação e a auditoria dos requisitos de Segurança do Trabalho.',
    servicesLabel: 'Serviços',
    services: [
      'PGR/GRO',
      'PCMAT',
      'LTCAT',
      'CIPA',
      'Perícias',
      'Laudos de Insalubridade e Periculosidade',
      'Ordens de Serviço',
      'Gestão de EPI',
    ],
    topicId: 'frente:seguranca',
    sourceSlides: [5, 8],
  },
  {
    id: 'gestao',
    label: 'Gestão e Tecnologia',
    summary: 'Sistemas, dados e indicadores para acompanhar a operação.',
    detail:
      'A CRED trabalha com customização de dados, desenvolvimento de indicadores e mentoria para ativação de módulos do sistema de gestão. A atuação também apoia a aprendizagem dos profissionais técnicos e especialistas.',
    servicesLabel: 'Recursos',
    services: [
      'Integração com softwares ERP',
      'Interface online para importação e exportação de dados',
      'Gestão Eletrônica de Documentos',
      'Assinatura digital',
      'Aplicativo móvel',
      'Acervo fotográfico',
      'Saúde remota',
      'Tecnologia de biometria',
      'Sistema em nuvem',
    ],
    topicId: 'frente:gestao',
    sourceSlides: [5, 9],
  },
  {
    id: 'treinamento',
    label: 'Treinamentos',
    summary: 'Central EAD integrada à gestão de cursos e registros.',
    detail:
      'A central de treinamentos reúne mais de 77 cursos e integra a emissão e gestão de certificados, conteúdo programático e listas de presença ao software de gestão.',
    servicesLabel: 'Temas de treinamento',
    services: [
      'NR-01 — Disposições Gerais',
      'NR-05 — CIPA',
      'NR-06 — Equipamento de Proteção Individual',
      'NR-10 — Segurança Elétrica',
      'NR-10 — SEP, Sistema Elétrico de Potência',
      'NR-11 — Transporte, Movimentação, Armazenagem e Manuseio de Materiais',
      'NR-12 — Segurança no Trabalho em Máquinas e Equipamentos',
      'NR-13 — Segurança na Operação de Caldeiras',
      'NR-17 — Ergonomia',
      'NR-20 — Segurança no Trabalho com Inflamáveis e Combustíveis',
      'NR-33 — Segurança e Saúde em Espaço Confinado',
      'NR-35 — Trabalho em Altura',
    ],
    extras: [
      {
        label: 'Recursos complementares',
        text: 'Mapeamento dos treinamentos normativos e automação dos personalizados, com acesso multiplataforma.',
      },
      {
        // CTA específico do catálogo de temas (substitui "Ver serviços" nesta frente).
        ctaLabel: 'Ver temas de treinamento',
      },
    ],
    topicId: 'frente:treinamento',
    sourceSlides: [5, 10],
  },
];

export const serviceAreaById: Readonly<Record<ServiceAreaId, ServiceArea>> = Object.fromEntries(
  serviceAreas.map((a) => [a.id, a]),
) as Record<ServiceAreaId, ServiceArea>;

export const DEFAULT_AREA_ID: ServiceAreaId = 'saude';

/** Soluções adicionais do slide 15 — cada item é selecionável; só nome, sem descrição inventada. */
export const additionalServicesCopy = {
  title: 'Outras necessidades da operação',
  body: 'Conheça outras soluções do portfólio da CRED.',
} as const;

const additional: [string, string][] = [
  ['gestao-absenteismo', 'Gestão de Absenteísmo'],
  ['telemedicina', 'Monitoramento por Telemedicina'],
  ['ambulatorios', 'Administração de Ambulatórios'],
  ['continuidade-negocios', 'Plano de Continuidade de Negócios'],
  ['mao-de-obra', 'Locação de Mão de Obra'],
  ['veiculo-urgencia', 'Locação de Veículo de Urgência e Emergência'],
  ['analise-ergonomica', 'Análise Ergonômica'],
  ['campanhas-vacinais', 'Campanhas Vacinais'],
  ['ginastica-laboral', 'Ginástica Laboral e afins'],
  ['sipat-digital', 'SIPAT Digital'],
];

export const additionalServices: readonly AdditionalService[] = additional.map(([id, label]) => ({
  id,
  label,
  topicId: `servico:${id}` as const,
  sourceSlides: [15],
}));
