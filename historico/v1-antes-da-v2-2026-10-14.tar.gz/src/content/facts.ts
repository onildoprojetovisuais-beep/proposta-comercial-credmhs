import type { Fact } from '../types';

/**
 * Fatos e números (docs/02 M03; docs/07 P01–P04, P08, P09).
 * Valores do slide 17 são declarações da apresentação recebida, sem data-base (P03).
 * Nunca reescrever qualificadores ("Clientes atendidos" ≠ "clientes ativos";
 * "Clínicas credenciadas" ≠ unidades próprias). Não somar indicadores.
 */
export const facts: readonly Fact[] = [
  {
    id: 'unidades',
    value: '16',
    qualifier: 'Unidades',
    sourceSlides: [17],
    verificationStatus: 'source-supplied',
    displayPolicy: 'show',
    pendingRef: 'P03',
  },
  {
    id: 'clinicas-credenciadas',
    value: '+700',
    qualifier: 'Clínicas credenciadas',
    sourceSlides: [17],
    verificationStatus: 'source-supplied',
    displayPolicy: 'show',
    pendingRef: 'P03',
  },
  {
    id: 'vidas-gerenciadas',
    value: '+550 mil',
    qualifier: 'Vidas gerenciadas',
    sourceSlides: [17],
    verificationStatus: 'source-supplied',
    displayPolicy: 'show',
    pendingRef: 'P03',
    internalNote: 'Original: "+550k Vidas Gerenciadas".',
  },
  {
    id: 'clientes-atendidos',
    value: '+5 mil',
    qualifier: 'Clientes atendidos',
    sourceSlides: [17],
    verificationStatus: 'source-supplied',
    displayPolicy: 'show',
    pendingRef: 'P03',
    internalNote: 'Original: "+5k Clientes Atendidos". Nunca "clientes ativos".',
  },
  {
    id: 'estados-atendidos',
    value: '27',
    qualifier: 'Estados atendidos',
    sourceSlides: [17],
    verificationStatus: 'source-supplied',
    displayPolicy: 'use-fallback',
    fallbackText: 'Atuação nacional',
    pendingRef: 'P04',
    internalNote: 'Confirmar nomenclatura (27 unidades federativas / DF) antes de exibir o número.',
  },
  {
    id: 'tempo-experiencia',
    value: '',
    qualifier: 'Anos de experiência',
    sourceSlides: [4, 17],
    verificationStatus: 'conflict',
    displayPolicy: 'use-fallback',
    fallbackText: 'experiência multissetorial',
    variants: [
      { value: '30 anos', source: 'slide 4' },
      { value: '34 anos', source: 'slide 17' },
      { value: '35 anos', source: 'briefing-original.txt' },
    ],
    pendingRef: 'P01',
    internalNote: 'Não mostrar idade nem escolher um valor arbitrariamente.',
  },
  {
    id: 'ranking',
    value: 'entre as 5 maiores em Saúde e Segurança do Trabalho',
    qualifier: 'Ranking',
    sourceSlides: [1],
    verificationStatus: 'missing',
    displayPolicy: 'inventory-only',
    pendingRef: 'P02',
    internalNote: 'Sem fonte/critério. Não usar em headline.',
  },
  {
    id: 'cursos-ead',
    value: 'mais de 77',
    qualifier: 'cursos na central EAD',
    sourceSlides: [10],
    verificationStatus: 'source-supplied',
    displayPolicy: 'show',
    pendingRef: 'P09',
    internalNote: 'Exibido no detalhe da frente Treinamentos. Não inferir 77 NRs.',
  },
  {
    id: 'solucoes-esocial',
    value: '4',
    qualifier: 'soluções para o eSocial',
    sourceSlides: [11],
    verificationStatus: 'source-supplied',
    displayPolicy: 'inventory-only',
    pendingRef: 'P08',
    internalNote: 'Modalidades não descritas; não inventar quatro nomes.',
  },
];

export const factById: ReadonlyMap<string, Fact> = new Map(facts.map((f) => [f.id, f]));

/** Indicadores exibíveis em M03, na ordem da copy (docs/02, tabela do slide 17). */
export const capacityFacts: readonly Fact[] = ['unidades', 'clinicas-credenciadas', 'vidas-gerenciadas', 'clientes-atendidos']
  .map((id) => factById.get(id))
  .filter((f): f is Fact => !!f && f.displayPolicy === 'show');

/** Alcance textual de M03 (fallback do fato territorial). */
export const reachText: string = factById.get('estados-atendidos')?.fallbackText ?? 'Atuação nacional';
