import type { Priority, PriorityId } from '../types';

/** Máximo de prioridades simultâneas (docs/03). */
export const MAX_PRIORITIES = 2;

/**
 * Prioridades de M02 (docs/03, tabela "Prioridades").
 * Destaque = rótulo/ênfase editorial e sugestão de navegação, não avaliação de adequação.
 * Riscos Psicossociais nunca é destacado por prioridade (continua disponível para todos).
 */
export const priorities: readonly Priority[] = [
  {
    id: 'saude',
    label: 'Saúde Ocupacional',
    initialArea: 'saude',
    highlightNote: 'Saúde Ocupacional e seus recursos de acompanhamento',
    highlights: { areas: ['saude'], applications: [], chapters: ['m05'], capacityDetails: ['in-company'] },
  },
  {
    id: 'seguranca',
    label: 'Segurança do Trabalho',
    initialArea: 'seguranca',
    highlightNote: 'Equipe e catálogo de Segurança do Trabalho',
    highlights: { areas: ['seguranca'], applications: [], chapters: ['m05'], capacityDetails: ['equipe', 'recursos-proprios'] },
  },
  {
    id: 'gestao',
    label: 'Gestão e Tecnologia',
    initialArea: 'gestao',
    highlightNote: 'M06, eSocial e FAP/NTEP',
    highlights: { areas: ['gestao'], applications: ['esocial', 'fap-ntep'], chapters: ['m05', 'm06', 'm07'], capacityDetails: [] },
  },
  {
    id: 'treinamento',
    label: 'Treinamentos',
    initialArea: 'treinamento',
    highlightNote: 'EAD, registros e temas de treinamento',
    highlights: { areas: ['treinamento'], applications: [], chapters: ['m05'], capacityDetails: [] },
  },
];

export const priorityById: Readonly<Record<PriorityId, Priority>> = Object.fromEntries(
  priorities.map((p) => [p.id, p]),
) as Record<PriorityId, Priority>;

export function isPriorityId(value: unknown): value is PriorityId {
  return typeof value === 'string' && Object.prototype.hasOwnProperty.call(priorityById, value);
}
