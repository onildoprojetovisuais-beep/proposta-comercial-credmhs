import type { Topic, TopicId } from '../types';
import { additionalServices, serviceAreas } from './ecosystem';
import { applications } from './applications';

/**
 * Assuntos selecionáveis da pauta (docs/03, "Assuntos da pauta").
 * Três categorias: frente:* (4), aplicacao:* (3), servico:* (10 do slide 15).
 * Siglas do catálogo principal não viram controles individuais.
 */
export const topics: readonly Topic[] = [
  ...serviceAreas.map((a) => ({ id: a.topicId, label: a.label, type: 'frente' as const, sourceSlides: a.sourceSlides })),
  ...applications.map((a) => ({ id: a.topicId, label: a.label, type: 'aplicacao' as const, sourceSlides: a.sourceSlides })),
  ...additionalServices.map((s) => ({ id: s.topicId, label: s.label, type: 'servico' as const, sourceSlides: s.sourceSlides })),
];

export const topicById: ReadonlyMap<TopicId, Topic> = new Map(topics.map((t) => [t.id, t]));

export function isTopicId(value: unknown): value is TopicId {
  return typeof value === 'string' && topicById.has(value as TopicId);
}
