/**
 * Asserções executáveis dos "Casos obrigatórios" de docs/03-personalizacao.md.
 * Sem framework de teste. Executar com um runner TS (ex.: `npx tsx src/lib/__checks__.ts`,
 * se instalado) ou Node ≥ 23 com type stripping + resolução de imports sem extensão.
 * Não importa React nem acessa rede: a RPC do Supabase é simulada com `fetch` injetado e a
 * configuração é passada explicitamente (`import.meta.env` não existe no Node).
 *
 * Execução verificada (Node 24, type stripping nativo + hook de resolução sem extensão):
 *   node --import ./src/lib/checks-resolve.mjs src/lib/__checks__.ts
 * Ver qa/RELATORIO.md / relatório do agente de conteúdo.
 */
import type { StorageLike } from '../state/store';
import { createPresentationStore } from '../state/store';
import { readExecutiveRequest, resolveExecutive, resolveLocalExecutive } from './executive';
import { fetchPublicExecutive, parsePublicExecutiveRow, parsePublicProfileResponse } from './supabase/publicProfile';
import { mapPublicExecutiveRow, photoAltFor } from './supabase/mapping';
import { buildPresentationLink } from './supabase/slug';
import type { PublicExecutiveRow } from './supabase/types';
import type { SupabasePublicConfig } from './supabase/config';
import { buildAgendaText, buildMessage, contactLinks, getActiveArea, getHighlights } from './personalization';
import { STORAGE_KEY, validateState, normalizeCompanyName } from './validateState';
import { sabrinaFerreira } from '../content/executives';
import { topics } from '../content/topics';
import { additionalServices, serviceAreas } from '../content/ecosystem';
import { trustMode } from '../content/credentials';
import { capacityFacts, facts } from '../content/facts';
import { uncoveredSlides } from '../content/coverage';
import { chapterFromHash, chapters, copy } from '../content/chapters';
import type { Executive } from '../types';

/** Asserções mínimas (sem node:assert, para tipar só com o lib DOM do projeto). */
const assert = {
  ok(value: unknown, message?: string): void {
    if (!value) throw new Error(message ?? 'assert.ok falhou');
  },
  equal(actual: unknown, expected: unknown, message?: string): void {
    if (!Object.is(actual, expected)) throw new Error(message ?? `esperado ${String(expected)}, recebido ${String(actual)}`);
  },
  notEqual(actual: unknown, expected: unknown, message?: string): void {
    if (Object.is(actual, expected)) throw new Error(message ?? `não deveria ser ${String(expected)}`);
  },
  deepEqual(actual: unknown, expected: unknown, message?: string): void {
    const a = JSON.stringify(actual);
    const b = JSON.stringify(expected);
    if (a !== b) throw new Error(message ?? `esperado ${b}, recebido ${a}`);
  },
};

let passed = 0;
const queue: { name: string; fn: () => void | Promise<void> }[] = [];
/** Registra uma verificação (síncrona ou assíncrona); todas rodam em ordem no fim do arquivo. */
function check(name: string, fn: () => void | Promise<void>): void {
  queue.push({ name, fn });
}

function memoryStorage(): StorageLike & { data: Map<string, string> } {
  const data = new Map<string, string>();
  return {
    data,
    getItem: (k) => data.get(k) ?? null,
    setItem: (k, v) => void data.set(k, v),
    removeItem: (k) => void data.delete(k),
  };
}

const brokenStorage: StorageLike = {
  getItem() {
    throw new Error('SecurityError');
  },
  setItem() {
    throw new Error('QuotaExceeded');
  },
  removeItem() {
    throw new Error('SecurityError');
  },
};

const SAB = 'sabrina-ferreira';

// --- Executivo (sem Supabase: perfis locais) -------------------------------
check('perfil padrão e query de Sabrina resolvem o mesmo contato', () => {
  const a = resolveLocalExecutive('');
  const b = resolveLocalExecutive('?executivo=sabrina-ferreira');
  assert.ok(a.status === 'ready' && b.status === 'ready');
  if (a.status !== 'ready' || b.status !== 'ready') return;
  assert.equal(a.reason, 'default');
  assert.equal(b.reason, 'matched');
  assert.equal(a.executive.email, b.executive.email);
  assert.equal(resolveLocalExecutive('?executivo=').status, 'ready', 'parâmetro vazio = sem identificador');
  assert.equal(resolveLocalExecutive('?executivo=%20Sabrina-Ferreira%20').status, 'ready', 'trim + minúsculas');
});

// Regra atual de Nil (prevalece sobre docs/03): identificador desconhecido NÃO cai em Sabrina.
check('ID de executivo desconhecido mostra "não encontrada" (sem fallback silencioso)', () => {
  for (const q of ['?executivo=joao', '?executivo=<script>', '?executivo=%E0%A4%A', '?executivo=a', '?executivo=catarina']) {
    const r = resolveLocalExecutive(q);
    assert.equal(r.status, 'not-found', q);
    assert.ok(!('executive' in r), 'nenhum perfil é entregue');
  }
  assert.equal(readExecutiveRequest('?executivo=Ana--Paula').kind, 'invalid');
});

check('query não injeta telefone/e-mail', () => {
  const r = resolveLocalExecutive('?executivo=sabrina-ferreira&email=x@y.com&telefone=1');
  assert.ok(r.status === 'ready');
  if (r.status !== 'ready') return;
  assert.equal(r.executive.email, 'sabrina.ferreira@credmhs.com.br');
  assert.equal(r.executive.phoneE164, '+5521988967369');
});

// --- Prioridades ----------------------------------------------------------
check('zero, uma e duas prioridades; frente inicial', () => {
  const s = createPresentationStore({ executiveId: SAB });
  assert.equal(getActiveArea(s.getState().priorities, null), 'saude');
  assert.equal(s.actions.togglePriority('treinamento'), 'added');
  assert.equal(getActiveArea(s.getState().priorities, null), 'treinamento');
  assert.equal(s.actions.togglePriority('gestao'), 'added');
  assert.deepEqual(s.getState().priorities, ['treinamento', 'gestao']);
  assert.equal(getActiveArea(s.getState().priorities, null), 'treinamento');
  const h = getHighlights(s.getState().priorities);
  assert.deepEqual(h.applications, ['esocial', 'fap-ntep']);
  assert.ok(!h.applications.includes('riscos-psicossociais'));
});

check('terceira prioridade mantém as duas e sinaliza limite', () => {
  const s = createPresentationStore({ executiveId: SAB });
  s.actions.togglePriority('saude');
  s.actions.togglePriority('seguranca');
  assert.equal(s.actions.togglePriority('gestao'), 'limit');
  assert.deepEqual(s.getState().priorities, ['saude', 'seguranca']);
  assert.equal(s.getState().priorityLimitReached, true);
  assert.equal(s.actions.togglePriority('saude'), 'removed');
  assert.equal(s.actions.togglePriority('gestao'), 'added');
  assert.deepEqual(s.getState().priorities, ['seguranca', 'gestao']);
  assert.equal(s.getState().priorityLimitReached, false);
});

check('troca manual de frente prevalece até mudar prioridades', () => {
  const s = createPresentationStore({ executiveId: SAB });
  s.actions.togglePriority('seguranca');
  s.actions.setActiveArea('treinamento');
  assert.equal(getActiveArea(s.getState().priorities, s.getState().manualArea), 'treinamento');
  s.actions.togglePriority('saude');
  assert.equal(getActiveArea(s.getState().priorities, s.getState().manualArea), 'seguranca');
});

check('"Conhecer a atuação completa" limpa prioridades e mantém assuntos', () => {
  const s = createPresentationStore({ executiveId: SAB });
  s.actions.togglePriority('saude');
  s.actions.addTopic('servico:sipat-digital');
  s.actions.clearPriorities();
  assert.deepEqual(s.getState().priorities, []);
  assert.deepEqual(s.getState().topics, ['servico:sipat-digital']);
});

// --- Nome da empresa --------------------------------------------------------
check('nome vazio, longo, acentuado e com caracteres especiais', () => {
  const s = createPresentationStore({ executiveId: SAB });
  s.actions.setCompanyName('   ');
  assert.equal(normalizeCompanyName(s.getState().companyName), '');
  s.actions.setCompanyName('A'.repeat(200));
  assert.equal(s.getState().companyName.length, 80);
  const special = 'Ação & Cia <b>"Ltda"</b>\n— São João';
  s.actions.setCompanyName(special);
  const name = normalizeCompanyName(s.getState().companyName);
  assert.ok(!name.includes('\n'));
  assert.ok(name.includes('<b>'), 'mantido como texto literal; a UI renderiza como texto, nunca HTML');
  assert.ok(buildMessage(s.getState(), sabrinaFerreira).includes('Ação & Cia'));
});

// --- Assuntos --------------------------------------------------------------
check('adicionar duas vezes, remover, adicionar novamente', () => {
  const s = createPresentationStore({ executiveId: SAB });
  assert.equal(s.actions.addTopic('aplicacao:esocial'), 'added');
  assert.equal(s.actions.addTopic('aplicacao:esocial'), 'unchanged');
  assert.deepEqual(s.getState().topics, ['aplicacao:esocial']);
  assert.equal(s.actions.removeTopic('aplicacao:esocial'), 'removed');
  assert.deepEqual(s.getState().topics, []);
  assert.equal(s.actions.addTopic('aplicacao:esocial'), 'added');
  assert.equal(s.actions.addTopic('frente:inexistente' as never), 'invalid');
});

check('itens livres e reordenação da pauta', () => {
  const s = createPresentationStore({ executiveId: SAB });
  s.actions.addTopic('frente:saude');
  s.actions.addTopic('servico:telemedicina');
  s.actions.moveTopic('servico:telemedicina', -1);
  assert.deepEqual(s.getState().topics, ['servico:telemedicina', 'frente:saude']);
  const id = s.actions.addCustomItem('  Prazos de   implantação ');
  assert.ok(id);
  assert.equal(s.actions.addCustomItem('prazos de implantação'), null, 'sem duplicar');
  assert.equal(s.actions.addCustomItem('   '), null);
  s.actions.updateCustomItem(id!, 'Unidades em SP');
  assert.equal(s.getState().customItems[0].text, 'Unidades em SP');
  s.actions.removeCustomItem(id!);
  assert.equal(s.getState().customItems.length, 0);
});

// --- Persistência ------------------------------------------------------------
check('recarregar restaura seleção válida', () => {
  const st = memoryStorage();
  const a = createPresentationStore({ executiveId: SAB, storage: st });
  a.actions.setCompanyName('  Empresa X ');
  a.actions.togglePriority('gestao');
  a.actions.addTopic('aplicacao:fap-ntep');
  a.actions.setMessageDraft('rascunho');
  const b = createPresentationStore({ executiveId: SAB, storage: st });
  assert.equal(b.getState().companyName, 'Empresa X');
  assert.deepEqual(b.getState().priorities, ['gestao']);
  assert.deepEqual(b.getState().topics, ['aplicacao:fap-ntep']);
  assert.equal(b.getState().messageDraft, null, 'rascunho não é persistido');
  assert.ok(!st.data.get(STORAGE_KEY)!.includes('rascunho'));
});

check('storage inválido é descartado', () => {
  for (const raw of ['{quebrado', '[]', '{"schemaVersion":99,"executiveId":"sabrina-ferreira"}', 'null']) {
    const st = memoryStorage();
    st.data.set(STORAGE_KEY, raw);
    const s = createPresentationStore({ executiveId: SAB, storage: st });
    assert.deepEqual(s.getState().priorities, []);
  }
  const v = validateState(
    { schemaVersion: 1, executiveId: SAB, companyName: 5, priorities: ['saude', 'saude', 'x', 'gestao', 'treinamento'], topics: ['frente:saude', 'hack', 'frente:saude'], customItems: [{ id: 'nota:a', text: '<i>ok</i>' }, { id: 'bad', text: 'x' }] },
    SAB,
  );
  assert.ok(v);
  assert.equal(v!.companyName, '');
  assert.deepEqual(v!.priorities, ['saude', 'gestao']);
  assert.deepEqual(v!.topics, ['frente:saude']);
  assert.equal(v!.customItems.length, 1);
  // Restauração regrava só a forma validada (campos inválidos não ficam no storage).
  const st2 = memoryStorage();
  st2.data.set(STORAGE_KEY, JSON.stringify({ schemaVersion: 1, executiveId: SAB, companyName: '<b>X</b>'.repeat(20), priorities: ['saude', 'hack'], topics: ['x:y'], customItems: [] }));
  createPresentationStore({ executiveId: SAB, storage: st2 });
  const saved = JSON.parse(st2.data.get(STORAGE_KEY)!);
  assert.equal(saved.companyName, '');
  assert.deepEqual(saved.priorities, ['saude']);
  assert.deepEqual(saved.topics, []);
});

check('storage indisponível mantém a experiência em memória', () => {
  const s = createPresentationStore({ executiveId: SAB, storage: brokenStorage });
  assert.equal(s.getState().storageAvailable, false);
  s.actions.togglePriority('saude');
  s.actions.addTopic('frente:saude');
  assert.deepEqual(s.getState().priorities, ['saude']);
  s.actions.reset();
  assert.deepEqual(s.getState().priorities, []);
});

check('reset limpa contexto, rascunho e storage; mantém executivo', () => {
  const st = memoryStorage();
  const s = createPresentationStore({ executiveId: SAB, storage: st });
  s.actions.setCompanyName('Empresa');
  s.actions.togglePriority('saude');
  s.actions.addTopic('frente:saude');
  s.actions.addCustomItem('nota');
  s.actions.setExpandedDetail('m03-estrutura');
  s.actions.setMessageDraft('texto');
  const before = s.getState().resetCount;
  s.actions.reset();
  const st2 = s.getState();
  assert.equal(st2.companyName, '');
  assert.deepEqual([st2.priorities, st2.topics, st2.customItems], [[], [], []]);
  assert.equal(st2.messageDraft, null);
  assert.equal(st2.expandedDetail, null);
  assert.equal(st2.executiveId, SAB);
  assert.equal(st2.resetCount, before + 1);
  assert.equal(st.data.has(STORAGE_KEY), false);
});

check('"Limpar escolhas" mantém nome da empresa', () => {
  const s = createPresentationStore({ executiveId: SAB });
  s.actions.setCompanyName('Empresa');
  s.actions.togglePriority('saude');
  s.actions.addTopic('frente:saude');
  s.actions.clearChoices();
  assert.equal(s.getState().companyName, 'Empresa');
  assert.deepEqual(s.getState().topics, []);
});

check('alternância entre executivos sem vazamento de contexto', () => {
  const st = memoryStorage();
  st.data.set(STORAGE_KEY, JSON.stringify({ schemaVersion: 1, executiveId: 'outro-executivo', companyName: 'Vazou', priorities: ['saude'], topics: [], customItems: [] }));
  const s = createPresentationStore({ executiveId: SAB, storage: st });
  assert.equal(s.getState().companyName, '');
  assert.equal(st.data.has(STORAGE_KEY), false);
  s.actions.setCompanyName('Empresa');
  s.actions.switchExecutive(SAB); // mesmo executivo: nada muda
  assert.equal(s.getState().companyName, 'Empresa');
});

// --- Mensagem e contatos ------------------------------------------------------
check('mensagem sem escolhas, com contexto e sem repetição', () => {
  const empty = { companyName: '', priorities: [], topics: [], customItems: [] };
  const m0 = buildMessage(empty, sabrinaFerreira);
  assert.ok(m0.startsWith('Olá, Sabrina!'));
  assert.ok(!m0.includes('Prioridades:'));
  assert.ok(!m0.includes('Assuntos'));
  const m1 = buildMessage({ companyName: 'Acme', priorities: ['saude', 'gestao'], topics: ['frente:saude', 'aplicacao:esocial'], customItems: [] }, sabrinaFerreira);
  assert.ok(m1.includes('conversar sobre Acme.'));
  assert.ok(m1.includes('Prioridades: Saúde Ocupacional e Gestão e Tecnologia.'));
  assert.ok(m1.includes('Assuntos para aprofundar: eSocial.'), 'frente já citada como prioridade não se repete');
  const m2 = buildMessage({ companyName: '', priorities: ['treinamento'], topics: [], customItems: [] }, sabrinaFerreira);
  assert.ok(m2.includes('sobre a minha empresa.'));
  assert.ok(!m2.includes('Assuntos'));
  for (const m of [m0, m1, m2]) assert.ok(!/enviad|diagn[oó]stic|garant/i.test(m));
});

check('alteração de escolhas após editar a mensagem não sobrescreve', () => {
  const s = createPresentationStore({ executiveId: SAB });
  s.actions.togglePriority('saude');
  s.actions.setMessageDraft('Meu texto');
  s.actions.addTopic('servico:sipat-digital');
  const st = s.getState();
  assert.equal(st.messageDraft, 'Meu texto');
  assert.notEqual(st.messageDraftBasis, buildMessage(st, sabrinaFerreira), 'deve sinalizar desatualização');
  s.actions.refreshMessage();
  assert.equal(s.getState().messageDraft, null);
});

check('links codificados, fallback para mensagem longa, WhatsApp desabilitado', () => {
  const msg = buildMessage({ companyName: 'Ação & Cia?=#', priorities: ['saude'], topics: [], customItems: [] }, sabrinaFerreira);
  const l = contactLinks(sabrinaFerreira, msg);
  assert.ok(l.email && l.phone);
  if (!l.email || !l.phone) return;
  assert.ok(l.email.href.startsWith('mailto:sabrina.ferreira@credmhs.com.br?subject='));
  assert.ok(l.email.bodyIncluded);
  assert.ok(l.email.href.includes('%26%20Cia%3F%3D%23'));
  assert.ok(l.email.href.includes('%0D%0A'));
  assert.equal(l.phone.href, 'tel:+5521988967369');
  assert.equal(l.whatsApp, null);
  const longMsg = 'x'.repeat(3000);
  const l2 = contactLinks(sabrinaFerreira, longMsg);
  assert.equal(l2.email?.bodyIncluded, false);
  assert.ok(!l2.email?.href.includes('body='));
  const fake: Executive = { ...sabrinaFerreira, whatsAppEnabled: true, whatsAppNumber: null };
  assert.equal(contactLinks(fake, msg).whatsApp, null, 'sem número confirmado, sem WhatsApp');
});

check('pauta vazia e pauta longa', () => {
  const empty = buildAgendaText({ companyName: '', priorities: [], topics: [], customItems: [] }, sabrinaFerreira);
  assert.ok(empty.includes('Uma conversa sobre a sua operação'));
  const all = buildAgendaText({ companyName: 'Acme', priorities: ['saude', 'seguranca'], topics: topics.map((t) => t.id), customItems: [] }, sabrinaFerreira);
  assert.equal(all.split('\n').filter((l) => l.startsWith('- ')).length, 2 + topics.length);
});

// --- Conteúdo -----------------------------------------------------------------
check('cobertura de conteúdo e fatos', () => {
  assert.deepEqual(uncoveredSlides(), []);
  assert.equal(topics.length, 4 + 3 + 10);
  assert.equal(additionalServices.length, 10);
  assert.equal(serviceAreas.length, 4);
  assert.equal(trustMode, 'fallback');
  assert.deepEqual(capacityFacts.map((f) => f.qualifier), ['Unidades', 'Clínicas credenciadas', 'Vidas gerenciadas', 'Clientes atendidos']);
  assert.ok(!facts.some((f) => /ativos/i.test(f.qualifier)));
  assert.equal(facts.find((f) => f.id === 'tempo-experiencia')!.verificationStatus, 'conflict');
  assert.equal(chapters.length, 10);
});

check('link direto a capítulo sem estado anterior', () => {
  assert.equal(chapterFromHash('#estrutura')?.id, 'm03');
  assert.equal(chapterFromHash('#%E0%A4%A'), null);
  assert.equal(chapterFromHash('#nao-existe'), null);
  const s = createPresentationStore({ executiveId: SAB, storage: memoryStorage() });
  assert.deepEqual(s.getState().topics, []);
});

// --- Supabase: linha pública → perfil ------------------------------------------
const CONFIG: SupabasePublicConfig = { url: 'https://mock-projeto.supabase.co', anonKey: 'anon-falsa' };
const UID = '0b9c2f9e-1d2a-4c3b-9a8f-7e6d5c4b3a21';
const photoUrlFor = (path: string) => `${CONFIG.url}/storage/v1/object/public/executive-photos/${path}`;

function row(patch: Partial<PublicExecutiveRow> & Record<string, unknown> = {}): PublicExecutiveRow & Record<string, unknown> {
  return {
    slug: 'catarina',
    available: true,
    full_name: 'Catarina Souza',
    display_name: 'Catarina',
    role: 'Executiva de Negócios',
    contact_email: 'catarina.souza@credmhs.com.br',
    phone_display: '+55 (21) 99999-0000',
    phone_e164: '+5521999990000',
    photo_path: `${UID}/retrato.webp`,
    photo_width: 900,
    photo_height: 1200,
    linkedin_url: 'https://www.linkedin.com/in/catarina',
    website_url: 'https://www.credmhs.com.br',
    updated_at: '2026-10-10T12:00:00+00:00',
    ...patch,
  };
}

check('mapeamento da linha pública (campos extras ignorados, foto remota, alt gerado)', () => {
  const parsed = parsePublicExecutiveRow(row({ id: 'uuid-interno', user_id: UID, is_default: true, email_login: 'x@y.z' }));
  assert.ok(parsed);
  assert.ok(!('user_id' in parsed!) && !('id' in parsed!), 'campos extras não são copiados');
  const e = mapPublicExecutiveRow(parsed!, { photoUrlFor })!;
  assert.equal(e.id, 'catarina');
  assert.equal(e.firstName, 'Catarina');
  assert.equal(e.fullName, 'Catarina Souza');
  assert.equal(e.email, 'catarina.souza@credmhs.com.br');
  assert.equal(e.phoneE164, '+5521999990000');
  assert.equal(e.photoSource, 'remote');
  assert.ok(e.photo!.startsWith(`${CONFIG.url}/storage/v1/object/public/executive-photos/${UID}/retrato.webp?v=`));
  assert.deepEqual([e.photoWidth, e.photoHeight], [900, 1200]);
  assert.equal(e.photoAlt, photoAltFor('Catarina Souza', 'Executiva de Negócios'));
  assert.equal(e.photoAlt, 'Retrato de Catarina Souza, Executiva de Negócios da CRED MHS');
  assert.equal(e.whatsAppEnabled, false);
  assert.equal(e.whatsAppNumber, null);
  // Sem dimensões → 1098×1433.
  const noDims = mapPublicExecutiveRow(row({ photo_width: null, photo_height: 99999 }), { photoUrlFor })!;
  assert.deepEqual([noDims.photoWidth, noDims.photoHeight], [1098, 1433]);
});

check('mapeamento: e-mail/telefone/links inválidos ocultam o canal; foto ausente', () => {
  const bad = mapPublicExecutiveRow(
    row({
      contact_email: 'ana@x.com?bcc=outro@y.com',
      phone_e164: '21 9999',
      linkedin_url: 'javascript:alert(1)',
      website_url: 'https://user:senha@site.com',
      photo_path: '../../etc/passwd',
    }),
    { photoUrlFor },
  )!;
  assert.equal(bad.email, null);
  assert.equal(bad.phoneE164, null);
  assert.equal(bad.phoneDisplay, null);
  assert.equal(bad.linkedInUrl, null);
  assert.equal(bad.websiteUrl, null);
  assert.equal(bad.photo, null, 'caminho fora do padrão não vira URL');
  const links = contactLinks(bad, 'Olá');
  assert.equal(links.email, null);
  assert.equal(links.phone, null);
  assert.equal(links.linkedIn, null);
  assert.equal(links.website, null);
  // Telefone exibido malformado, E.164 válido → exibe o E.164.
  const p = mapPublicExecutiveRow(row({ phone_display: '<b>21</b>' }), { photoUrlFor })!;
  assert.equal(p.phoneDisplay, '+5521999990000');
  // Sem foto: outro executivo → layout tipográfico; Sabrina → retrato do projeto.
  assert.equal(mapPublicExecutiveRow(row({ photo_path: null }), { photoUrlFor })!.photo, null);
  const sab = mapPublicExecutiveRow(row({ slug: SAB, photo_path: null }), { photoUrlFor })!;
  assert.equal(sab.photoSource, 'bundled');
  assert.equal(sab.photo, sabrinaFerreira.photo);
  // Texto com controles é limpo; nome de apresentação ausente → linha inválida.
  assert.equal(mapPublicExecutiveRow(row({ full_name: 'Catarina‮ Souza\n' }), { photoUrlFor })!.fullName, 'Catarina Souza');
  assert.equal(mapPublicExecutiveRow(row({ display_name: '   ' }), { photoUrlFor }), null);
  assert.equal(mapPublicExecutiveRow(row({ available: false }), { photoUrlFor }), null);
});

check('validação da resposta da RPC (vazia, inativa, malformada, outro slug)', () => {
  assert.equal(parsePublicProfileResponse([], 'catarina').kind, 'not-found');
  const inactive = parsePublicProfileResponse([{ slug: 'catarina', available: false }], 'catarina');
  assert.equal(inactive.kind, 'unavailable');
  assert.equal(parsePublicProfileResponse([row()], 'catarina').kind, 'found');
  assert.equal(parsePublicProfileResponse(row(), 'catarina').kind, 'found', 'objeto único também é aceito');
  for (const bad of ['texto', 42, null, [1], [row(), row()], [row({ available: 'sim' as never })], [row({ full_name: 5 as never })], [row({ photo_width: '9' as never })], [{ available: true }]]) {
    const r = parsePublicProfileResponse(bad, 'catarina');
    assert.equal(r.kind, 'error', JSON.stringify(bad).slice(0, 60));
  }
  assert.equal(parsePublicProfileResponse([row({ slug: 'outra-pessoa' })], 'catarina').kind, 'error', 'nunca outro perfil');
  assert.equal(parsePublicProfileResponse([row({ slug: SAB })], null).kind, 'found', 'padrão aceita o slug devolvido');
});

// --- Supabase: resolução com fetch simulado ---------------------------------------
type Call = { url: string; init: RequestInit };
function mockFetch(handler: (body: { p_slug: string | null }) => Response | Promise<Response> | 'network' | 'hang'): {
  fetchImpl: typeof fetch;
  calls: Call[];
} {
  const calls: Call[] = [];
  const fetchImpl = ((url: string, init: RequestInit) => {
    calls.push({ url, init });
    const out = handler(JSON.parse(String(init.body)));
    if (out === 'network') return Promise.reject(new TypeError('Failed to fetch'));
    if (out === 'hang') {
      return new Promise<Response>((_, reject) => {
        init.signal?.addEventListener('abort', () => reject(new DOMException('aborted', 'AbortError')));
      });
    }
    return Promise.resolve(out);
  }) as unknown as typeof fetch;
  return { fetchImpl, calls };
}
const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json' } });

check('resolução sem Supabase configurado = perfis locais', async () => {
  const a = await resolveExecutive('', { config: null });
  assert.ok(a.status === 'ready' && a.origin === 'local' && a.executive.id === SAB);
  assert.equal((await resolveExecutive('?executivo=catarina', { config: null })).status, 'not-found');
});

check('resolução com Supabase: requisição, sucesso, inexistente, inativo, formato inválido', async () => {
  const m = mockFetch(({ p_slug }) => (p_slug === 'catarina' ? json([row()]) : p_slug === 'inativo' ? json([{ slug: 'inativo', available: false }]) : json([])));
  const opts = { config: CONFIG, fetchImpl: m.fetchImpl, photoUrlFor, warn: () => undefined };
  const ok = await resolveExecutive('?executivo=Catarina', opts);
  assert.ok(ok.status === 'ready' && ok.origin === 'remote' && ok.executive.firstName === 'Catarina');
  const call = m.calls[0];
  assert.equal(call.url, `${CONFIG.url}/rest/v1/rpc/get_public_executive`);
  assert.equal(call.init.method, 'POST');
  assert.equal(call.init.cache, 'no-store');
  const headers = call.init.headers as Record<string, string>;
  assert.equal(headers.apikey, 'anon-falsa');
  assert.equal(headers.Authorization, 'Bearer anon-falsa');
  assert.equal(call.init.body, '{"p_slug":"catarina"}', 'só o identificador sai do navegador');
  assert.equal((await resolveExecutive('?executivo=nao-existe', opts)).status, 'not-found');
  assert.equal((await resolveExecutive('?executivo=inativo', opts)).status, 'unavailable');
  const before = m.calls.length;
  assert.equal((await resolveExecutive('?executivo=<script>', opts)).status, 'not-found');
  assert.equal((await resolveExecutive('?executivo=a', opts)).status, 'not-found');
  assert.equal(m.calls.length, before, 'formato inválido não chama a rede');
  // Sem identificador: p_slug null.
  const d = mockFetch(() => json([row({ slug: SAB, photo_path: null })]));
  const def = await resolveExecutive('', { ...opts, fetchImpl: d.fetchImpl });
  assert.equal(d.calls[0].init.body, '{"p_slug":null}');
  assert.ok(def.status === 'ready' && def.reason === 'default' && def.executive.photoSource === 'bundled');
});

check('falha de rede: padrão → perfil local (com aviso); com identificador → erro, sem fallback', async () => {
  const warnings: string[] = [];
  const warn = (msg: string) => void warnings.push(msg);
  for (const failure of ['network', 'hang', 'http500', 'invalid', 'empty'] as const) {
    const m = mockFetch(() =>
      failure === 'network' ? 'network' : failure === 'hang' ? 'hang' : failure === 'http500' ? json({ message: 'x' }, 500) : failure === 'invalid' ? new Response('<html>', { status: 200 }) : json([]),
    );
    const opts = { config: CONFIG, fetchImpl: m.fetchImpl, photoUrlFor, warn, timeoutMs: 30 };
    const def = await resolveExecutive('', opts);
    assert.ok(def.status === 'ready' && def.origin === 'local' && def.reason === 'default-fallback' && def.executive.id === SAB, failure);
    if (failure === 'empty') continue; // 0 linhas com identificador = not-found (coberto acima)
    const withSlug = await resolveExecutive('?executivo=catarina', opts);
    assert.equal(withSlug.status, 'error', `com identificador (${failure})`);
    assert.ok(!('executive' in withSlug));
  }
  assert.equal(warnings.length, 5);
  // Tempo-limite devolve 'timeout'.
  const hang = mockFetch(() => 'hang');
  const r = await fetchPublicExecutive('catarina', { config: CONFIG, fetchImpl: hang.fetchImpl, timeoutMs: 20 });
  assert.ok(r.kind === 'error' && r.cause === 'timeout');
  // "Tentar novamente": a nova chamada resolve normalmente.
  let fail = true;
  const retry = mockFetch(() => (fail ? 'network' : json([row()])));
  const o = { config: CONFIG, fetchImpl: retry.fetchImpl, photoUrlFor, warn };
  assert.equal((await resolveExecutive('?executivo=catarina', o)).status, 'error');
  fail = false;
  assert.equal((await resolveExecutive('?executivo=catarina', o)).status, 'ready');
});

// --- Isolamento da sessão ---------------------------------------------------------
check('troca de executivo zera a sessão; "Nova apresentação" zera e mantém o executivo', () => {
  const catarina = mapPublicExecutiveRow(row(), { photoUrlFor })!;
  const outro = mapPublicExecutiveRow(row({ slug: 'bruno', display_name: 'Bruno', full_name: 'Bruno Lima' }), { photoUrlFor })!;
  const st = memoryStorage();
  const s = createPresentationStore({ executive: catarina, storage: st });
  s.actions.setCompanyName('Empresa A');
  s.actions.togglePriority('saude');
  s.actions.addTopic('frente:saude');
  s.actions.addCustomItem('Prazos');
  s.actions.setMessageDraft('rascunho');
  // Mesmo slug com dados atualizados: sessão mantida.
  s.actions.switchExecutive({ ...catarina, role: 'Gerente Comercial' });
  assert.equal(s.getState().companyName, 'Empresa A');
  assert.equal(s.getExecutive().role, 'Gerente Comercial');
  // Outro slug: tudo zerado.
  const before = s.getState().resetCount;
  s.actions.switchExecutive(outro);
  const z = s.getState();
  assert.equal(s.getExecutive().id, 'bruno');
  assert.deepEqual([z.companyName, z.priorities, z.topics, z.customItems, z.messageDraft], ['', [], [], [], null]);
  assert.equal(z.executiveId, 'bruno');
  assert.equal(z.resetCount, before + 1);
  assert.equal(st.data.has(STORAGE_KEY), false);
  // "Nova apresentação" (reset) zera e mantém o executivo.
  s.actions.setCompanyName('Empresa B');
  s.actions.togglePriority('gestao');
  s.actions.reset();
  assert.equal(s.getState().companyName, '');
  assert.deepEqual(s.getState().priorities, []);
  assert.equal(s.getExecutive().id, 'bruno');
  assert.equal(s.getState().executiveId, 'bruno');
  assert.equal(copy.global.reset.label, 'Nova apresentação');
});

check('sessão de A não restaura em B; storage só guarda o slug do executivo', () => {
  const catarina = mapPublicExecutiveRow(row(), { photoUrlFor })!;
  const bruno = mapPublicExecutiveRow(row({ slug: 'bruno', display_name: 'Bruno', full_name: 'Bruno Lima' }), { photoUrlFor })!;
  const st = memoryStorage();
  const a = createPresentationStore({ executive: catarina, storage: st });
  a.actions.setCompanyName('Empresa A');
  a.actions.togglePriority('seguranca');
  a.actions.addCustomItem('Unidades');
  const saved = JSON.parse(st.data.get(STORAGE_KEY)!);
  assert.deepEqual(Object.keys(saved).sort(), ['companyName', 'customItems', 'executiveId', 'priorities', 'schemaVersion', 'topics']);
  assert.equal(saved.executiveId, 'catarina');
  const raw = st.data.get(STORAGE_KEY)!;
  for (const leak of ['Catarina Souza', 'catarina.souza@', '+5521999990000', 'storage/v1', 'linkedin']) assert.ok(!raw.includes(leak), leak);
  // Mesma aba, nova carga com B: nada de A.
  const b = createPresentationStore({ executive: bruno, storage: st });
  assert.equal(b.getState().companyName, '');
  assert.deepEqual(b.getState().priorities, []);
  assert.equal(st.data.has(STORAGE_KEY), false, 'sessão de A descartada');
  // Recarregar A (mesmo slug) restaura A.
  const st2 = memoryStorage();
  createPresentationStore({ executive: catarina, storage: st2 }).actions.setCompanyName('Empresa A');
  assert.equal(createPresentationStore({ executive: catarina, storage: st2 }).getState().companyName, 'Empresa A');
});

check('link compartilhável não contém dados do cliente', () => {
  const link = buildPresentationLink('catarina', 'https://apresentacao.credmhs.com.br');
  assert.equal(link, 'https://apresentacao.credmhs.com.br/?executivo=catarina');
  const s = createPresentationStore({ executiveId: SAB });
  s.actions.setCompanyName('Empresa Sigilosa');
  s.actions.togglePriority('saude');
  const l2 = buildPresentationLink(s.getState().executiveId, 'https://x.test');
  assert.ok(!/Empresa|saude|prioridade|pauta/i.test(l2));
  assert.equal(l2, 'https://x.test/?executivo=sabrina-ferreira');
});

for (const { name, fn } of queue) {
  try {
    await fn();
    passed += 1;
    console.log(`ok  - ${name}`);
  } catch (err) {
    console.error(`FAIL - ${name}`);
    throw err;
  }
}

console.log(`\n${passed} verificações passaram.`);
