export { formatTemplate, joinPtBr } from './format';
export { resolveExecutive, resolveLocalExecutive, readExecutiveRequest, getExecutiveById, getDefaultExecutive } from './executive';
export type { ExecutiveRequest, ResolveExecutiveOptions } from './executive';
export {
  validateState,
  parseStoredState,
  emptyPersistedState,
  sanitizeCompanyInput,
  normalizeCompanyName,
  normalizeCustomText,
  STATE_SCHEMA_VERSION,
  STORAGE_KEY,
  COMPANY_NAME_MAX,
  CUSTOM_ITEM_MAX_LENGTH,
  CUSTOM_ITEMS_MAX,
} from './validateState';
export {
  getHighlights,
  getActiveArea,
  getAgenda,
  buildAgendaText,
  buildMessage,
  contactLinks,
  MAX_CONTACT_URL_LENGTH,
} from './personalization';
export type { Agenda } from './personalization';
