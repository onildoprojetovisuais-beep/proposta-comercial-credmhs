import type {
  AgendaEntry,
  ContactLinks,
  Executive,
  Highlights,
  PersistedState,
  Priority,
  PriorityId,
  ServiceAreaId,
} from '../types';
import { priorityById } from '../content/priorities';
import { DEFAULT_AREA_ID, serviceAreas } from '../content/ecosystem';
import { topicById } from '../content/topics';
import { copy } from '../content/chapters';
import { formatTemplate, joinPtBr } from './format';
import { normalizeCompanyName } from './validateState';

type Choices = Pick<PersistedState, 'companyName' | 'priorities' | 'topics' | 'customItems'>;

// ---------------------------------------------------------------------------
// Destaques
// ---------------------------------------------------------------------------

/**
 * Destaques personalizados derivados das prioridades (docs/03, "Prioridades").
 * Ênfase editorial e sugestão de navegação — nunca oculta soluções nem avalia adequação.
 * Sem prioridades → nenhum destaque e Saúde Ocupacional como frente inicial.
 */
export function getHighlights(priorityIds: readonly PriorityId[]): Highlights {
  const list: Priority[] = priorityIds.map((id) => priorityById[id]).filter(Boolean);
  const uniq = <T,>(arr: T[]): T[] => Array.from(new Set(arr));
  return {
    priorities: list,
    initialArea: list[0]?.initialArea ?? DEFAULT_AREA_ID,
    areas: uniq(list.flatMap((p) => p.highlights.areas)),
    applications: uniq(list.flatMap((p) => p.highlights.applications)),
    chapters: uniq(list.flatMap((p) => p.highlights.chapters)),
    capacityDetails: uniq(list.flatMap((p) => p.highlights.capacityDetails)),
  };
}

/** Frente aberta em M05: escolha manual prevalece; senão 1ª prioridade; senão Saúde Ocupacional. */
export function getActiveArea(priorityIds: readonly PriorityId[], manualArea: ServiceAreaId | null): ServiceAreaId {
  if (manualArea && serviceAreas.some((a) => a.id === manualArea)) return manualArea;
  return getHighlights(priorityIds).initialArea;
}

// ---------------------------------------------------------------------------
// Pauta
// ---------------------------------------------------------------------------

export interface Agenda {
  companyName: string;
  priorities: Priority[];
  /** Assuntos adicionados (catálogo + itens livres), na ordem da pauta. */
  entries: AgendaEntry[];
  isEmpty: boolean;
}

export function getAgenda(state: Choices): Agenda {
  const priorities = state.priorities.map((id) => priorityById[id]).filter(Boolean);
  const entries: AgendaEntry[] = [
    ...state.topics
      .map((id) => topicById.get(id))
      .filter((t): t is NonNullable<typeof t> => !!t)
      .map((t) => ({ id: t.id, label: t.label, kind: t.type })),
    ...state.customItems.map((c) => ({ id: c.id, label: c.text, kind: 'nota' as const })),
  ];
  return {
    companyName: normalizeCompanyName(state.companyName),
    priorities,
    entries,
    isEmpty: priorities.length === 0 && entries.length === 0,
  };
}

/**
 * Assuntos para a mensagem: remove frentes já citadas como prioridade, para não repetir
 * a mesma frase (docs/03, "evitar repetir a mesma frase na mensagem final").
 */
function messageTopicLabels(state: Choices): string[] {
  const priorityLabels = new Set(state.priorities.map((id) => priorityById[id]?.label));
  return getAgenda(state)
    .entries.filter((e) => !(e.kind === 'frente' && priorityLabels.has(e.label)))
    .map((e) => e.label);
}

/** Texto da pauta para "Copiar pauta". */
export function buildAgendaText(state: Choices, executive: Executive): string {
  const agenda = getAgenda(state);
  const lines: string[] = [];
  lines.push(
    agenda.companyName
      ? formatTemplate(copy.m09.titleWithCompanyTemplate, { empresa: agenda.companyName })
      : copy.m09.titleWithoutCompany,
  );
  lines.push(`${executive.fullName} — ${executive.role}, CRED MHS`);
  if (agenda.isEmpty) {
    lines.push('', copy.m09.empty);
    return lines.join('\n');
  }
  if (agenda.priorities.length) {
    lines.push('', `${copy.m09.groupPriorities}:`, ...agenda.priorities.map((p) => `- ${p.label}`));
  }
  if (agenda.entries.length) {
    lines.push('', `${copy.m09.groupTopics}:`, ...agenda.entries.map((e) => `- ${e.label}`));
  }
  return lines.join('\n');
}

// ---------------------------------------------------------------------------
// Mensagem
// ---------------------------------------------------------------------------

/**
 * Prévia da mensagem (docs/02 M10). Omite linhas vazias; sem nenhuma escolha nem empresa,
 * usa a "Mensagem sem escolhas". Nada é enviado: o visitante revisa e decide.
 */
export function buildMessage(state: Choices, executive: Executive): string {
  const company = normalizeCompanyName(state.companyName);
  const priorityLabels = state.priorities.map((id) => priorityById[id]?.label).filter(Boolean) as string[];
  const topicLabels = messageTopicLabels(state);
  const greeting = `Olá, ${executive.firstName}!`;

  if (!company && priorityLabels.length === 0 && topicLabels.length === 0) {
    return [
      greeting,
      '',
      'Conheci a apresentação da CRED MHS e gostaria de conversar sobre as necessidades da minha empresa e como a CRED pode apoiar nossa gestão.',
    ].join('\n');
  }

  const lines = [greeting, '', `Conheci a apresentação da CRED MHS e gostaria de conversar sobre ${company || 'a minha empresa'}.`];
  if (priorityLabels.length) lines.push('', `Prioridades: ${joinPtBr(priorityLabels)}.`);
  if (topicLabels.length) lines.push('', `Assuntos para aprofundar: ${topicLabels.join('; ')}.`);
  lines.push('', 'Podemos conversar sobre como a CRED pode apoiar nossa gestão?');
  return lines.join('\n');
}

// ---------------------------------------------------------------------------
// Contatos
// ---------------------------------------------------------------------------

/** Limite conservador de URL para mailto/WhatsApp (docs/03). Acima disso, não incluir o corpo. */
export const MAX_CONTACT_URL_LENGTH = 1800;

function encodeBody(text: string): string {
  // RFC 6068: quebras de linha como CRLF.
  return encodeURIComponent(text.replace(/\r?\n/g, '\r\n'));
}

/**
 * Links de contato iniciados pelo visitante. Nada é enviado automaticamente.
 * - E-mail: destinatário + assunto + corpo; se exceder o limite, só destinatário e assunto
 *   (`bodyIncluded: false`) e a UI deve orientar a cópia (copy.m10.feedback.longMessage).
 * - E-mail/telefone: null quando o perfil não tem valor válido (o canal some da interface).
 * - Telefone: tel: com E.164.
 * - WhatsApp: só se `whatsAppEnabled` e número confirmado; senão null.
 */
export function contactLinks(executive: Executive, message: string): ContactLinks {
  const subject = copy.m10.emailSubject;
  let email: ContactLinks['email'] = null;
  if (executive.email) {
    const base = `mailto:${executive.email}?subject=${encodeURIComponent(subject)}`;
    const full = message.trim() ? `${base}&body=${encodeBody(message)}` : base;
    const emailFits = full.length <= MAX_CONTACT_URL_LENGTH;
    email = { href: emailFits ? full : base, subject, bodyIncluded: emailFits && !!message.trim() };
  }

  let whatsApp: ContactLinks['whatsApp'] = null;
  const waDigits = executive.whatsAppNumber?.replace(/\D/g, '') ?? '';
  if (executive.whatsAppEnabled && /^\d{10,15}$/.test(waDigits)) {
    const waBase = `https://wa.me/${waDigits}`;
    const waFull = message.trim() ? `${waBase}?text=${encodeURIComponent(message)}` : waBase;
    const fits = waFull.length <= MAX_CONTACT_URL_LENGTH;
    whatsApp = { href: fits ? waFull : waBase, bodyIncluded: fits && !!message.trim() };
  }

  return {
    email,
    phone: executive.phoneE164 ? { href: `tel:${executive.phoneE164}`, label: executive.phoneDisplay ?? executive.phoneE164 } : null,
    linkedIn: executive.linkedInUrl ? { href: executive.linkedInUrl } : null,
    website: executive.websiteUrl
      ? { href: executive.websiteUrl, label: executive.websiteUrl.replace(/^https?:\/\//, '').replace(/\/$/, '') }
      : null,
    whatsApp,
  };
}
