import type { CustomAgendaItem, PersistedState, PriorityId, TopicId } from '../types';
import { MAX_PRIORITIES, isPriorityId } from '../content/priorities';
import { isTopicId } from '../content/topics';
import { stripControlChars } from './format';

export const STATE_SCHEMA_VERSION = 1;
export const STORAGE_KEY = 'cred-mhs:apresentacao';
export const COMPANY_NAME_MAX = 80;
export const CUSTOM_ITEM_MAX_LENGTH = 120;
export const CUSTOM_ITEMS_MAX = 20;

/** Sanitiza o nome enquanto o visitante digita (não faz trim para não atrapalhar a digitação). */
export function sanitizeCompanyInput(value: unknown): string {
  if (typeof value !== 'string') return '';
  return stripControlChars(value).slice(0, COMPANY_NAME_MAX);
}

/** Forma final do nome (para exibição, mensagem e persistência). */
export function normalizeCompanyName(value: unknown): string {
  return sanitizeCompanyInput(value).replace(/\s+/g, ' ').trim();
}

export function normalizeCustomText(value: unknown): string {
  if (typeof value !== 'string') return '';
  return stripControlChars(value).replace(/\s+/g, ' ').trim().slice(0, CUSTOM_ITEM_MAX_LENGTH);
}

export function sanitizePriorities(value: unknown): PriorityId[] {
  if (!Array.isArray(value)) return [];
  const out: PriorityId[] = [];
  for (const v of value) {
    if (isPriorityId(v) && !out.includes(v)) out.push(v);
    if (out.length >= MAX_PRIORITIES) break;
  }
  return out;
}

export function sanitizeTopics(value: unknown): TopicId[] {
  if (!Array.isArray(value)) return [];
  const out: TopicId[] = [];
  for (const v of value) if (isTopicId(v) && !out.includes(v)) out.push(v);
  return out;
}

const CUSTOM_ID = /^nota:[a-z0-9-]{1,40}$/;

export function sanitizeCustomItems(value: unknown): CustomAgendaItem[] {
  if (!Array.isArray(value)) return [];
  const out: CustomAgendaItem[] = [];
  for (const v of value) {
    if (!v || typeof v !== 'object') continue;
    const { id, text } = v as { id?: unknown; text?: unknown };
    if (typeof id !== 'string' || !CUSTOM_ID.test(id) || out.some((o) => o.id === id)) continue;
    const clean = normalizeCustomText(text);
    if (!clean) continue;
    out.push({ id: id as CustomAgendaItem['id'], text: clean });
    if (out.length >= CUSTOM_ITEMS_MAX) break;
  }
  return out;
}

export function emptyPersistedState(executiveId: string): PersistedState {
  return { schemaVersion: STATE_SCHEMA_VERSION, executiveId, companyName: '', priorities: [], topics: [], customItems: [] };
}

/**
 * Valida um estado restaurado (sessionStorage). Retorna null quando a estrutura deve ser
 * descartada inteira: não-objeto, versão incompatível ou executivo diferente do atual
 * (evita associar pauta ao contato errado). Campos inválidos são descartados individualmente.
 */
export function validateState(raw: unknown, expectedExecutiveId: string): PersistedState | null {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const r = raw as Record<string, unknown>;
  if (r.schemaVersion !== STATE_SCHEMA_VERSION) return null;
  if (typeof r.executiveId !== 'string' || r.executiveId !== expectedExecutiveId) return null;
  const company = typeof r.companyName === 'string' && r.companyName.length <= COMPANY_NAME_MAX ? normalizeCompanyName(r.companyName) : '';
  return {
    schemaVersion: STATE_SCHEMA_VERSION,
    executiveId: expectedExecutiveId,
    companyName: company,
    priorities: sanitizePriorities(r.priorities),
    topics: sanitizeTopics(r.topics),
    customItems: sanitizeCustomItems(r.customItems),
  };
}

/** Lê e valida a partir de uma string JSON (tolerante a JSON quebrado). */
export function parseStoredState(json: string | null, expectedExecutiveId: string): PersistedState | null {
  if (!json) return null;
  try {
    return validateState(JSON.parse(json), expectedExecutiveId);
  } catch {
    return null;
  }
}
