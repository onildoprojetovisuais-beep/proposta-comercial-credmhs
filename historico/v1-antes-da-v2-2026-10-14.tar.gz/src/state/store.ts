import type {
  CustomAgendaItem,
  Executive,
  PersistedState,
  PresentationState,
  PriorityId,
  ServiceAreaId,
  TogglePriorityResult,
  TopicId,
  TopicMutationResult,
} from '../types';
import { MAX_PRIORITIES, isPriorityId } from '../content/priorities';
import { isTopicId } from '../content/topics';
import { serviceAreas } from '../content/ecosystem';
import { getExecutiveById, getDefaultExecutive } from '../lib/executive';
import { buildMessage } from '../lib/personalization';
import {
  CUSTOM_ITEMS_MAX,
  STORAGE_KEY,
  emptyPersistedState,
  normalizeCompanyName,
  normalizeCustomText,
  parseStoredState,
  sanitizeCompanyInput,
} from '../lib/validateState';

/** Subconjunto de Storage usado pelo store (permite memória/mocks em testes). */
export interface StorageLike {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

/** sessionStorage quando disponível e funcional; senão null (estado só em memória). */
export function getSessionStorage(): StorageLike | null {
  try {
    if (typeof window === 'undefined' || !window.sessionStorage) return null;
    const probe = '__cred_probe__';
    window.sessionStorage.setItem(probe, '1');
    window.sessionStorage.removeItem(probe);
    return window.sessionStorage;
  } catch {
    return null;
  }
}

export interface PresentationActions {
  /** Atualiza o nome enquanto digita (sanitizado, máx. 80; nunca HTML). */
  setCompanyName(value: string): void;
  /** Alterna prioridade. 3ª escolha → 'limit', mantém as duas e liga `priorityLimitReached`. */
  togglePriority(id: PriorityId): TogglePriorityResult;
  /** "Conhecer a atuação completa": limpa prioridades, mantém assuntos. */
  clearPriorities(): void;
  dismissPriorityLimit(): void;
  /** Troca manual de frente em M05 (prevalece até as prioridades mudarem). */
  setActiveArea(id: ServiceAreaId): void;
  addTopic(id: TopicId): TopicMutationResult;
  removeTopic(id: TopicId): TopicMutationResult;
  toggleTopic(id: TopicId): TopicMutationResult;
  /** Reordena um assunto do catálogo na pauta (delta -1 sobe, +1 desce). */
  moveTopic(id: TopicId, delta: number): void;
  /** Item livre da pauta. Retorna o id criado ou null (vazio/limite). */
  addCustomItem(text: string): CustomAgendaItem['id'] | null;
  updateCustomItem(id: CustomAgendaItem['id'], text: string): void;
  removeCustomItem(id: CustomAgendaItem['id']): void;
  moveCustomItem(id: CustomAgendaItem['id'], delta: number): void;
  /** "Limpar escolhas" (M09): prioridades, assuntos, itens livres e rascunho. Mantém empresa e executivo. */
  clearChoices(): void;
  setExpandedDetail(id: string | null): void;
  /** Registra edição manual da mensagem. */
  setMessageDraft(text: string): void;
  /** "Atualizar mensagem com minhas escolhas": descarta o rascunho e volta à mensagem gerada. */
  refreshMessage(): void;
  /** "Nova apresentação": limpa tudo da sessão (empresa, escolhas, rascunho) e mantém o executivo da URL. */
  reset(): void;
  /**
   * Troca de executivo (outro slug): descarta o contexto e o sessionStorage para não associar
   * a pauta ao contato errado. Mesmo slug → só atualiza os dados do perfil e mantém a sessão.
   * Aceita o perfil resolvido ou o ID de um perfil local.
   */
  switchExecutive(next: Executive | string): void;
}

export interface PresentationStore {
  getState(): PresentationState;
  getExecutive(): Executive;
  subscribe(listener: () => void): () => void;
  actions: PresentationActions;
}

function freshState(executiveId: string, resetCount: number, storageAvailable: boolean): PresentationState {
  return {
    ...emptyPersistedState(executiveId),
    manualArea: null,
    expandedDetail: null,
    messageDraft: null,
    messageDraftBasis: null,
    priorityLimitReached: false,
    resetCount,
    storageAvailable,
  };
}

function moveItem<T>(list: readonly T[], index: number, delta: number): T[] {
  const target = index + delta;
  if (index < 0 || target < 0 || target >= list.length || delta === 0) return list.slice();
  const next = list.slice();
  const [item] = next.splice(index, 1);
  next.splice(target, 0, item);
  return next;
}

let customSeq = 0;
function newCustomId(): CustomAgendaItem['id'] {
  customSeq += 1;
  return `nota:${Date.now().toString(36)}-${customSeq.toString(36)}`;
}

export interface CreatePresentationStoreOptions {
  /** Perfil já resolvido (local ou Supabase). Prevalece sobre `executiveId`. */
  executive?: Executive;
  /** Atalho para perfis locais (checks). Desconhecido → perfil padrão local. */
  executiveId?: string;
  storage?: StorageLike | null;
}

/**
 * Store de sessão simples (sem dependências). Persiste só o ID do executivo (slug), empresa,
 * prioridades, assuntos e itens livres em sessionStorage; rascunho, detalhe aberto e frente
 * manual ficam em memória. Dados do executivo (nome, contatos, foto) nunca vão para o storage.
 * Falha de storage nunca interrompe a experiência.
 */
export function createPresentationStore(options: CreatePresentationStoreOptions): PresentationStore {
  let storage: StorageLike | null = options.storage ?? null;
  let executive: Executive = options.executive ?? getExecutiveById(options.executiveId) ?? getDefaultExecutive();
  const listeners = new Set<() => void>();

  let state: PresentationState = freshState(executive.id, 0, !!storage);
  if (storage) {
    try {
      const raw = storage.getItem(STORAGE_KEY);
      const restored = parseStoredState(raw, executive.id);
      if (restored) {
        state = { ...state, ...restored };
        // Regrava só a forma validada: campos descartados não ficam no sessionStorage (QA funcional).
        storage.setItem(STORAGE_KEY, JSON.stringify(restored));
      } else if (raw !== null) storage.removeItem(STORAGE_KEY); // inválido ou de outro executivo
    } catch {
      storage = null;
      state = { ...state, storageAvailable: false };
    }
  }

  function persist(s: PresentationState): PresentationState {
    if (!storage) return s;
    const data: PersistedState = {
      schemaVersion: s.schemaVersion,
      executiveId: s.executiveId,
      companyName: normalizeCompanyName(s.companyName),
      priorities: s.priorities,
      topics: s.topics,
      customItems: s.customItems,
    };
    try {
      storage.setItem(STORAGE_KEY, JSON.stringify(data));
      return s;
    } catch {
      storage = null;
      return { ...s, storageAvailable: false };
    }
  }

  function set(patch: Partial<PresentationState>, opts: { persist?: boolean } = { persist: true }): void {
    let next: PresentationState = { ...state, ...patch };
    if (opts.persist !== false) next = persist(next);
    state = next;
    listeners.forEach((l) => l());
  }

  function clearStorage(): void {
    if (!storage) return;
    try {
      storage.removeItem(STORAGE_KEY);
    } catch {
      storage = null;
    }
  }

  const actions: PresentationActions = {
    setCompanyName(value) {
      set({ companyName: sanitizeCompanyInput(value) });
    },

    togglePriority(id) {
      if (!isPriorityId(id)) return 'invalid';
      if (state.priorities.includes(id)) {
        set({ priorities: state.priorities.filter((p) => p !== id), manualArea: null, priorityLimitReached: false });
        return 'removed';
      }
      if (state.priorities.length >= MAX_PRIORITIES) {
        set({ priorityLimitReached: true }, { persist: false });
        return 'limit';
      }
      set({ priorities: [...state.priorities, id], manualArea: null, priorityLimitReached: false });
      return 'added';
    },

    clearPriorities() {
      set({ priorities: [], manualArea: null, priorityLimitReached: false });
    },

    dismissPriorityLimit() {
      if (state.priorityLimitReached) set({ priorityLimitReached: false }, { persist: false });
    },

    setActiveArea(id) {
      if (!serviceAreas.some((a) => a.id === id)) return;
      set({ manualArea: id }, { persist: false });
    },

    addTopic(id) {
      if (!isTopicId(id)) return 'invalid';
      if (state.topics.includes(id)) return 'unchanged';
      set({ topics: [...state.topics, id] });
      return 'added';
    },

    removeTopic(id) {
      if (!state.topics.includes(id)) return 'unchanged';
      set({ topics: state.topics.filter((t) => t !== id) });
      return 'removed';
    },

    toggleTopic(id) {
      return state.topics.includes(id) ? actions.removeTopic(id) : actions.addTopic(id);
    },

    moveTopic(id, delta) {
      set({ topics: moveItem(state.topics, state.topics.indexOf(id), Math.sign(delta)) });
    },

    addCustomItem(text) {
      const clean = normalizeCustomText(text);
      if (!clean || state.customItems.length >= CUSTOM_ITEMS_MAX) return null;
      if (state.customItems.some((c) => c.text.toLowerCase() === clean.toLowerCase())) return null;
      const id = newCustomId();
      set({ customItems: [...state.customItems, { id, text: clean }] });
      return id;
    },

    updateCustomItem(id, text) {
      const clean = normalizeCustomText(text);
      if (!clean) {
        actions.removeCustomItem(id);
        return;
      }
      set({ customItems: state.customItems.map((c) => (c.id === id ? { ...c, text: clean } : c)) });
    },

    removeCustomItem(id) {
      set({ customItems: state.customItems.filter((c) => c.id !== id) });
    },

    moveCustomItem(id, delta) {
      set({ customItems: moveItem(state.customItems, state.customItems.findIndex((c) => c.id === id), Math.sign(delta)) });
    },

    clearChoices() {
      set({
        priorities: [],
        topics: [],
        customItems: [],
        manualArea: null,
        priorityLimitReached: false,
        messageDraft: null,
        messageDraftBasis: null,
      });
    },

    setExpandedDetail(id) {
      set({ expandedDetail: id }, { persist: false });
    },

    setMessageDraft(text) {
      const basis = state.messageDraftBasis ?? buildMessage(state, executive);
      set({ messageDraft: typeof text === 'string' ? text : '', messageDraftBasis: basis }, { persist: false });
    },

    refreshMessage() {
      set({ messageDraft: null, messageDraftBasis: null }, { persist: false });
    },

    reset() {
      clearStorage();
      state = freshState(executive.id, state.resetCount + 1, !!storage);
      listeners.forEach((l) => l());
    },

    switchExecutive(target) {
      const next = typeof target === 'string' ? (getExecutiveById(target) ?? getDefaultExecutive()) : target;
      if (next.id === executive.id) {
        if (next !== executive) {
          executive = next;
          state = { ...state };
          listeners.forEach((l) => l());
        }
        return;
      }
      executive = next;
      clearStorage();
      state = freshState(executive.id, state.resetCount + 1, !!storage);
      listeners.forEach((l) => l());
    },
  };

  return {
    getState: () => state,
    getExecutive: () => executive,
    subscribe(listener) {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    actions,
  };
}
