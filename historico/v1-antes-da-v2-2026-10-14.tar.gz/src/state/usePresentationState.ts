import { useMemo, useSyncExternalStore } from 'react';
import type { ContactLinks, Executive, ExecutiveResolution, Highlights, PresentationState, ServiceAreaId } from '../types';
import {
  buildAgendaText,
  buildMessage,
  contactLinks,
  getActiveArea,
  getAgenda,
  getHighlights,
} from '../lib/personalization';
import type { Agenda } from '../lib/personalization';
import { normalizeCompanyName } from '../lib/validateState';
import { createPresentationStore, getSessionStorage } from './store';
import type { PresentationActions, PresentationStore } from './store';

let singleton: PresentationStore | null = null;
let resolution: ReadyResolution | null = null;

/** Resolução concluída com perfil (as telas de "não encontrada"/erro não criam store). */
export type ReadyResolution = Extract<ExecutiveResolution, { status: 'ready' }>;

/**
 * Cria o store da sessão DEPOIS que o executivo foi resolvido (src/app/PresentationRoot.tsx).
 * Chamado de novo com outro executivo (outro slug na mesma aba) → a sessão é zerada
 * (storage removido, estado limpo, resetCount++). Mesmo slug → mantém a sessão.
 */
export function initPresentationStore(ready: ReadyResolution): PresentationStore {
  if (!singleton) {
    singleton = createPresentationStore({ executive: ready.executive, storage: getSessionStorage() });
  } else {
    singleton.actions.switchExecutive(ready.executive);
  }
  resolution = ready;
  return singleton;
}

/** Store da sessão. Só existe depois da resolução do executivo. */
export function getPresentationStore(): PresentationStore {
  if (!singleton || !resolution) {
    throw new Error('Store da apresentação usado antes da resolução do executivo (initPresentationStore).');
  }
  return singleton;
}

export interface PresentationView {
  state: PresentationState;
  executive: Executive;
  /** Como o executivo foi resolvido (local/remoto; default/matched/default-fallback). Uso interno. */
  executiveResolution: ReadyResolution;
  /** Nome normalizado (trim) para exibição; '' quando vazio. Renderizar como texto. */
  companyName: string;
  highlights: Highlights;
  /** Frente aberta em M05. */
  activeArea: ServiceAreaId;
  agenda: Agenda;
  /** Contador do resumo persistente: assuntos adicionados (sem prioridades). */
  topicCount: number;
  isTopicSelected(id: string): boolean;
  /** Mensagem gerada pelas escolhas atuais. */
  generatedMessage: string;
  /** Mensagem exibida na prévia (rascunho editado ou gerada). */
  message: string;
  isMessageEdited: boolean;
  /** Escolhas mudaram depois da edição manual → mostrar "Atualizar mensagem com minhas escolhas". */
  isMessageOutdated: boolean;
  agendaText: string;
  contacts: ContactLinks;
  actions: PresentationActions;
}

/**
 * Estado da apresentação para componentes.
 * Nome/escolhas/rascunho nunca vão para a URL; persistência só em sessionStorage.
 */
export function usePresentationState(): PresentationView {
  const store = getPresentationStore();
  const state = useSyncExternalStore(store.subscribe, store.getState, store.getState);
  // Lido depois de `state`: troca de executivo sempre gera um novo estado (re-render).
  const executive = store.getExecutive();
  const res = resolution as ReadyResolution;

  return useMemo<PresentationView>(() => {
    const generatedMessage = buildMessage(state, executive);
    const message = state.messageDraft ?? generatedMessage;
    const topicSet = new Set<string>(state.topics);
    return {
      state,
      executive,
      executiveResolution: res,
      companyName: normalizeCompanyName(state.companyName),
      highlights: getHighlights(state.priorities),
      activeArea: getActiveArea(state.priorities, state.manualArea),
      agenda: getAgenda(state),
      topicCount: state.topics.length + state.customItems.length,
      isTopicSelected: (id: string) => topicSet.has(id),
      generatedMessage,
      message,
      isMessageEdited: state.messageDraft !== null,
      isMessageOutdated: state.messageDraft !== null && state.messageDraftBasis !== generatedMessage,
      agendaText: buildAgendaText(state, executive),
      contacts: contactLinks(executive, message),
      actions: store.actions,
    };
  }, [state, executive, res, store]);
}
