/**
 * Tipos de conteúdo e estado da apresentação CRED MHS.
 * Campos seguem docs/05-implementacao.md ("Campos recomendados") e docs/03-personalizacao.md.
 *
 * Regra: `verificationStatus` descreve a situação factual do dado;
 * `displayPolicy` descreve como a interface pode usá-lo. São independentes.
 * Nenhum desses campos deve ser exibido ao prospect.
 */

/** Situação factual de um dado. Transcrever do deck não o torna `confirmed`. */
export type VerificationStatus = 'source-supplied' | 'confirmed' | 'conflict' | 'missing';

/**
 * Política de exibição, separada do status factual.
 * - `show`: pode aparecer na leitura principal ou nos detalhes.
 * - `use-fallback`: não exibir o valor; usar `fallbackText`.
 * - `inventory-only`: preservado no inventário/código, nunca renderizado ao prospect.
 * - `hidden-until-confirmed`: modelado, só pode aparecer após confirmação dos campos exigidos.
 */
export type DisplayPolicy = 'show' | 'use-fallback' | 'inventory-only' | 'hidden-until-confirmed';

/** Número de slide da apresentação original (1–19). */
export type SourceSlide = number;

// ---------------------------------------------------------------------------
// Capítulos
// ---------------------------------------------------------------------------

export type ChapterId = 'm01' | 'm02' | 'm03' | 'm04' | 'm05' | 'm06' | 'm07' | 'm08' | 'm09' | 'm10';

export interface Chapter {
  id: ChapterId;
  /** Código editorial (M01–M10). Uso interno. */
  code: string;
  /** Âncora do hash (#slug). URL só identifica executivo e capítulo. */
  slug: string;
  /** Rótulo do índice "Conteúdo". */
  navLabel: string;
  /** Título principal do capítulo (pode conter {variáveis}; ver copy). */
  title: string;
  /** Apoio principal, quando aplicável. */
  body?: string;
  sourceSlides: SourceSlide[];
  /** Chave do objeto de copy completo em `copy` (src/content/chapters.ts). */
  contentKey: ChapterId;
}

// ---------------------------------------------------------------------------
// Ecossistema, aplicações e assuntos
// ---------------------------------------------------------------------------

export type ServiceAreaId = 'saude' | 'seguranca' | 'gestao' | 'treinamento';

export interface ServiceArea {
  id: ServiceAreaId;
  label: string;
  summary: string;
  detail: string;
  /** Rótulo da lista principal (ex.: "Serviços", "Recursos"). */
  servicesLabel: string;
  services: string[];
  /** Blocos complementares do aprofundamento (texto já revisado para o prospect). */
  extras?: { label?: string; text?: string; items?: string[]; ctaLabel?: string }[];
  /** ID do assunto selecionável que representa a frente. */
  topicId: TopicId;
  sourceSlides: SourceSlide[];
}

export type ApplicationId = 'esocial' | 'fap-ntep' | 'riscos-psicossociais';

export interface Application {
  id: ApplicationId;
  label: string;
  summary: string;
  detail: string;
  topicId: TopicId;
  sourceSlides: SourceSlide[];
}

export interface AdditionalService {
  id: string;
  label: string;
  topicId: TopicId;
  sourceSlides: SourceSlide[];
}

export type TopicType = 'frente' | 'aplicacao' | 'servico';

/** IDs no formato `frente:*`, `aplicacao:*`, `servico:*`. */
export type TopicId = `${TopicType}:${string}`;

export interface Topic {
  id: TopicId;
  label: string;
  type: TopicType;
  sourceSlides: SourceSlide[];
}

// ---------------------------------------------------------------------------
// Prioridades
// ---------------------------------------------------------------------------

export type PriorityId = 'saude' | 'seguranca' | 'gestao' | 'treinamento';

export interface Priority {
  id: PriorityId;
  label: string;
  /** Frente aberta inicialmente em M05 quando esta é a primeira prioridade. */
  initialArea: ServiceAreaId;
  /** Descrição editorial do destaque (uso interno/documentação). */
  highlightNote: string;
  highlights: {
    areas: ServiceAreaId[];
    applications: ApplicationId[];
    chapters: ChapterId[];
    /** Detalhes de M03 que ganham ênfase. */
    capacityDetails: CapacityDetailId[];
  };
}

/** Destaques derivados das prioridades. Ênfase editorial, nunca avaliação de adequação. */
export interface Highlights {
  priorities: Priority[];
  initialArea: ServiceAreaId;
  areas: ServiceAreaId[];
  applications: ApplicationId[];
  chapters: ChapterId[];
  capacityDetails: CapacityDetailId[];
}

export type CapacityDetailId = 'equipe' | 'recursos-proprios' | 'in-company';

// ---------------------------------------------------------------------------
// Fatos, clientes, credenciais
// ---------------------------------------------------------------------------

export interface Fact {
  id: string;
  /** Valor como exibido ("16", "+700", "+550 mil"). */
  value: string;
  /** Qualificador obrigatório, sem reescrita ("Clientes atendidos", nunca "ativos"). */
  qualifier: string;
  sourceSlides: SourceSlide[];
  verificationStatus: VerificationStatus;
  displayPolicy: DisplayPolicy;
  /** Texto a usar quando `displayPolicy === 'use-fallback'`. */
  fallbackText?: string;
  /** Valores divergentes por fonte (para `conflict`). Uso interno. */
  variants?: { value: string; source: string }[];
  /** ID da pendência em docs/07. Uso interno. */
  pendingRef?: string;
  /** Nota interna. Nunca renderizar. */
  internalNote?: string;
}

export type ClientRelationshipStatus =
  /** Nome consta no slide 16; vínculo (atual/histórico/outro) não qualificado. */
  'listed-in-source' | 'confirmed-current' | 'confirmed-past';

export interface Client {
  id: string;
  name: string;
  /** Caminho público do logo oficial (opcional). Nunca redesenhar a partir do nome. */
  logo?: string;
  logoAlt?: string;
  sourceSlides: SourceSlide[];
  relationshipStatus: ClientRelationshipStatus;
  verificationStatus: VerificationStatus;
}

export type CredentialKind = 'iso' | 'data-protection';

export interface Credential {
  id: string;
  label: string;
  kind: CredentialKind;
  holder?: string;
  scope?: string;
  validity?: string;
  /** Caminho de selo/documento oficial, se fornecido. */
  asset?: string;
  sourceSlides: SourceSlide[];
  verificationStatus: VerificationStatus;
  displayPolicy: DisplayPolicy;
  internalNote?: string;
}

// ---------------------------------------------------------------------------
// Executivo
// ---------------------------------------------------------------------------

/** Origem do retrato: arquivo do projeto (com derivados avif/webp/jpg) ou Storage do Supabase. */
export type ExecutivePhotoSource = 'bundled' | 'remote';

export interface Executive {
  /** Identificador público (= slug do Supabase, ex.: `sabrina-ferreira`). */
  id: string;
  /** Nome de apresentação ("Olá, {firstName}!"). */
  firstName: string;
  fullName: string;
  role: string;
  /**
   * Retrato real: caminho do projeto (`photoSource: 'bundled'`) ou URL absoluta pública do
   * Storage (`'remote'`). null → layout tipográfico.
   */
  photo: string | null;
  photoSource: ExecutivePhotoSource | null;
  photoAlt: string;
  /** Dimensões intrínsecas do retrato, para reservar espaço. */
  photoWidth?: number;
  photoHeight?: number;
  /** null → e-mail ausente ou inválido: o canal fica oculto. */
  email: string | null;
  /** null → telefone ausente ou inválido: o canal fica oculto. */
  phoneDisplay: string | null;
  /** Formato E.164, ex.: +5521988967369. */
  phoneE164: string | null;
  linkedInUrl: string | null;
  websiteUrl: string | null;
  /** Só true com confirmação explícita do canal. */
  whatsAppEnabled: boolean;
  /** Só preencher com número confirmado para WhatsApp (dígitos E.164 sem +). */
  whatsAppNumber: string | null;
  sourceSlides: SourceSlide[];
  verificationStatus: VerificationStatus;
}

/**
 * Resultado da resolução do executivo pela URL (`?executivo=<slug>`). Uso interno.
 * - ready: perfil pronto. `origin` diz de onde veio: `local` (perfil do projeto) ou `remote` (Supabase).
 *   `reason`: 'default' (sem identificador), 'matched' (identificador encontrado),
 *   'default-fallback' (sem identificador e o Supabase falhou → perfil local documentado).
 * - not-found: identificador inexistente ou com formato inválido.
 * - unavailable: perfil existe, mas está inativo.
 * - error: falha de conexão/servidor com identificador (oferece "Tentar novamente").
 */
export type ExecutiveResolution =
  | {
      status: 'ready';
      executive: Executive;
      origin: 'local' | 'remote';
      reason: 'default' | 'matched' | 'default-fallback';
      requestedId: string | null;
    }
  | { status: 'not-found'; requestedId: string }
  | { status: 'unavailable'; requestedId: string | null }
  | { status: 'error'; requestedId: string };

// ---------------------------------------------------------------------------
// Estado de sessão
// ---------------------------------------------------------------------------

/** Item livre escrito pelo visitante na pauta (texto, nunca HTML). */
export interface CustomAgendaItem {
  id: `nota:${string}`;
  text: string;
}

/** Parte persistida em sessionStorage. */
export interface PersistedState {
  schemaVersion: number;
  executiveId: string;
  companyName: string;
  priorities: PriorityId[];
  topics: TopicId[];
  customItems: CustomAgendaItem[];
}

/** Estado completo em memória (persistido + transitório). */
export interface PresentationState extends PersistedState {
  /** Frente escolhida manualmente em M05; null → derivar da 1ª prioridade. */
  manualArea: ServiceAreaId | null;
  /** Detalhe aberto (transitório). */
  expandedDetail: string | null;
  /** Texto editado da mensagem; null → usar mensagem gerada. Nunca persistido. */
  messageDraft: string | null;
  /** Mensagem gerada no momento da edição, para detectar mudança de escolhas. */
  messageDraftBasis: string | null;
  /** true quando a última tentativa foi uma 3ª prioridade. */
  priorityLimitReached: boolean;
  /** Incrementa a cada reset; usar como `key` para remontar estados locais. */
  resetCount: number;
  /** Indica se o armazenamento de sessão está funcionando (diagnóstico interno). */
  storageAvailable: boolean;
}

export type TogglePriorityResult = 'added' | 'removed' | 'limit' | 'invalid';
export type TopicMutationResult = 'added' | 'removed' | 'unchanged' | 'invalid';

/** Uma entrada da pauta para M09 e para a mensagem. */
export interface AgendaEntry {
  id: TopicId | CustomAgendaItem['id'];
  label: string;
  kind: TopicType | 'nota';
}

export interface ContactLinks {
  /** null quando o perfil não tem e-mail válido. */
  email: {
    href: string;
    subject: string;
    /** false → corpo longo demais; abrir só com destinatário/assunto e orientar a cópia. */
    bodyIncluded: boolean;
  } | null;
  /** null quando o perfil não tem telefone válido. */
  phone: { href: string; label: string } | null;
  linkedIn: { href: string } | null;
  website: { href: string; label: string } | null;
  /** null quando o canal não está confirmado. */
  whatsApp: { href: string; bodyIncluded: boolean } | null;
}
