# Status da implementação — V2 (rev. 2.1)

**Atualizado em:** 16/10/2026. **Estado:** V2 local implementada, integrada e revisada, com a rodada de refinamento de 16/10 (CTA e movimento). Nada foi publicado. Supabase segue só simulado.

## Rodada 16/10/2026 — refinamento (detalhes em `qa/RELATORIO.md`)
- CTA da abertura: “Saiba mais” (antes “Vamos começar”), mesmo destino `#institucional`; rolagem livre mantida.
- Trilha (06): camada de movimento Remotion (`@remotion/player` 4.0.534, chunk sob demanda de ~93 kB gzip; composição em `src/motion/trail/`, também registrada como `TrilhaValor` em `remotion/`). Uma reprodução por entrada, pausa ao sair/continua ao voltar, “Pausar/Continuar animação” e “Repetir animação”, reduced motion estático. B2 resolvido: Investimento com o mesmo marcador.
- Soluções (07): entrada coordenada dos quatro eixos. Dados (04): sequência disperso → organizado.
- Verificações: typecheck e build OK; checks 18/18 (novo: linha do tempo da trilha); RLS 64/64; Chromium em 1440/768/390/320 com e sem reduced motion. Capturas em `qa/capturas/v2/rodada-2026-10-16/`.
- 3C/3I visíveis (decisão do Nil, 16/10): selo do eixo no cabeçalho das seções 02–07 e legenda na institucional (`src/content/positioning.ts`). Checks 19/19.
- Novas pendências: P46 (validar mapeamento/legenda 3C/3I), P43 (transcrição de 13/10 ausente), P44 (revisão visual citada não encontrada), P45 (licença Remotion).
Autoridade: `docs/REVISAO-CRED-MHS-V2.md`. Contrato e divisão de arquivos: `docs/V2-CONTRATO.md`. Mapeamento dos frameworks: `docs/V2-MAPEAMENTO-FRAMEWORKS.md`. V1 recuperável em `historico/v1-antes-da-v2-2026-10-14.tar.gz`.

## O que existe
- Oito dobras: abertura (`#abertura`), institucional com números e empresas, relacionamento, dados, gestão integrada, trilha de valor (5 etapas), soluções (4 eixos + rede), contato. Componentes em `src/components/sections/v2/`.
- Conteúdo tipado: `src/content/chapters.ts`, `solutions.ts`, `valueTrail.ts`, `facts.ts`, `clients.ts`, `coverage.ts`.
- Estado: só o executivo resolvido (`src/state/ExecutiveContext.tsx`); sem sessionStorage; chave da V1 é limpa na carga.
- Contatos: `contactLinks(executive)` sem corpo de mensagem; WhatsApp e agendamento ocultos até haver canal/URL confirmados.
- Removidos: prioridades, pauta, mensagem gerada, “Nova apresentação”, frentes V1, TopicToggle, Dialog, seções M01–M10.
- Painel e Supabase: inalterados (Preview do painel usa a copy nova).

## Verificações (14/10)
- `npm run build` OK; checks 17/17; `npm run test:rls` 64/64.
- QA do coordenador em Chromium (1440/768/390/320, perfis simulados): 61/62. A falha é falso negativo do script (texto do perfil desativado correto).
- Revisão independente: `qa/V2-REVISAO-INDEPENDENTE.md`, sem bloqueantes. Corrigidos e recapturados (`qa/capturas/v2/pos-correcoes/`): A1 (foto não quadrada no contato), M1 (abertura sem foto no desktop), M2 (“CRED MHS” sem quebra), B1 (perfil sem canal válido mostra o site institucional), e B3 (saltos longos do índice vão direto; tempo não medido, só confirmado que CTA e hashes seguem passando). Em aberto: B2.
- QA final do coordenador após as correções: 62/62 (`qa/capturas/v2/final/`).
- Capturas: `qa/capturas/v2/integrada/`, `qa/capturas/v2/agente2/`, `qa/capturas/v2/revisao-independente/`.

## Próximos passos
1. Capturas do guia: feitas (`docs/guia/img/v2/`).
2. B2 resolvido em 16/10 (mesmo marcador nas cinco etapas).
3. Pendências de conteúdo em `docs/07-fontes-e-pendencias.md` (P33 JPEGs ausentes, P01 30/34/35 anos, P03/P04 números, P05 ISO, P13 WhatsApp, booking, P38 itens fora do framework, P41 validação da copy pela Sabrina).
4. Supabase real e hospedagem: seguir `docs/CONFIGURACAO-SUPABASE.md`, só com autorização de Nil.

O status V1 de 10/10 (Supabase) está em `historico/` dentro do tar.
