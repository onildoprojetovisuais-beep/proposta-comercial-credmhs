import React from "react";
import {
  AbsoluteFill,
  Img,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { aspects, theme, video } from "./theme";
import { BgMesh, Grade, Grain, Vignette } from "./layers";
import { ensureFonts } from "./fonts";

ensureFonts();

type Pt = { x: number; y: number };

// Geometria: três aspectos em triângulo ao redor de um centro comum (a gestão).
const S = video.size;
const HUB: Pt = { x: 540, y: 520 };
const NODES: Pt[] = [
  { x: 270, y: 340 },
  { x: 810, y: 340 },
  { x: 540, y: 770 },
];
const HUB_INNER = 104;
const LOGO_RATIO = 481 / 1600; // proporção do logo_nova.svg

// Roteiro em segundos (convertido para quadros via fps). Ciclo fechado para tocar em loop:
// formação lenta (0–8,5 s) → conjunto formado, respirando (até 16,5 s) → dissolução (16,5–19,4 s)
// → quadro vazio, igual ao quadro 0. Todo movimento ambiente tem período que divide o ciclo,
// então o último quadro emenda no primeiro sem salto.
// Versão neutra: nenhum aspecto é destacado isoladamente. Na página, quem indica a etapa ativa é o
// scroll (texto HTML); o vídeo só mostra o conjunto — três aspectos equivalentes que se conectam
// ao mesmo tempo e convergem para a gestão. O único amarelo fica no centro (convergência), nunca num nó.
const T = {
  hubIn: 0.4,
  nodesIn: 1.2,
  nodeStagger: 0.3, // entrada orgânica, curta demais para sugerir ordem
  ring: [3.2, 5.6], // as três ligações do triângulo se desenham juntas
  spokes: 5.4,
  spokeStagger: 0.25,
  spokeDur: 1.4,
  glow: 7.0, // convergência: anel amarelo no centro
  logo: 7.6,
  flowIn: 9.0, // pulsos discretos correndo dos aspectos para o centro
  out: [16.5, 19.4], // dissolução de volta ao fundo
} as const;

const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;
const dist = (a: Pt, b: Pt) => Math.hypot(b.x - a.x, b.y - a.y);

const useT = () => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const s = (sec: number) => sec * fps;
  // Onda periódica: k ciclos completos por loop (k inteiro garante a emenda).
  const wave = (k: number, phase = 0) => Math.sin((2 * Math.PI * k * frame) / durationInFrames + phase);
  // 1 enquanto o conjunto está formado; cai a 0 na dissolução.
  const out = interpolate(frame, [s(T.out[0]), s(T.out[1])], [1, 0], { ...clamp, easing: theme.ease.inOut });
  return { frame, fps, s, wave, out, durationInFrames };
};

// Linha que se desenha progressivamente.
const DrawLine: React.FC<{ a: Pt; b: Pt; start: number; end: number; width?: number; color?: string }> = ({
  a,
  b,
  start,
  end,
  width = 2,
  color = theme.colors.line,
}) => {
  const { frame, s, out } = useT();
  const len = dist(a, b);
  const p = interpolate(frame, [s(start), s(end)], [0, 1], { ...clamp, easing: theme.ease.inOut });
  return (
    <line
      x1={a.x}
      y1={a.y}
      x2={b.x}
      y2={b.y}
      stroke={color}
      strokeWidth={width}
      strokeLinecap="round"
      strokeDasharray={len}
      strokeDashoffset={len * (1 - p)}
      opacity={p > 0 ? out : 0}
    />
  );
};

const nodeStart = (i: number) => T.nodesIn + i * T.nodeStagger;

// Os três nós têm sempre o mesmo tratamento (branco), para não competir com a etapa ativa do texto.
const Node: React.FC<{ i: number }> = ({ i }) => {
  const { frame, fps, s, wave, out } = useT();
  const pt = NODES[i];
  const enter = spring({ frame: frame - s(nodeStart(i)), fps, config: theme.spring.slow }) * out;
  // Leve resposta simultânea quando as ligações se fecham (igual nos três).
  const linked = interpolate(frame, [s(T.ring[1]) - 8, s(T.ring[1]) + 12, s(T.ring[1]) + 40], [0, 1, 0], {
    ...clamp,
    easing: theme.ease.out,
  });
  // Respiração do ponto, a mesma nos três (nenhum se destaca).
  const pulse = 0.5 + 0.5 * wave(4, -Math.PI / 2);
  const float = wave(4, i * 2.1) * 3 * enter;
  return (
    <g transform={`translate(${pt.x} ${pt.y + float}) scale(${0.6 + 0.4 * enter})`} opacity={enter}>
      <circle r={30} fill={theme.colors.bg} stroke={theme.colors.line} strokeWidth={2} />
      <circle r={9 + 3 * linked + 1.2 * pulse * enter} fill={theme.colors.text} />
    </g>
  );
};

const Label: React.FC<{ i: number }> = ({ i }) => {
  const { frame, fps, s, wave, out } = useT();
  const pt = NODES[i];
  const below = pt.y > HUB.y;
  const tIn = s(nodeStart(i) + 0.4);
  const pTitle = spring({ frame: frame - tIn, fps, config: theme.spring.slow });
  const pDetail = spring({ frame: frame - tIn - s(0.35), fps, config: theme.spring.slow });
  const dir = below ? -1 : 1; // entra em direção ao nó
  const float = wave(4, i * 2.1) * 3 * pTitle * out;
  return (
    <div
      style={{
        position: "absolute",
        left: pt.x - 260,
        width: 520,
        top: below ? pt.y + 56 : undefined,
        bottom: below ? undefined : S - pt.y + 56,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        fontFamily: theme.fonts.family,
        color: theme.colors.text,
        transform: `translateY(${float}px)`,
      }}
    >
      <div
        style={{
          fontWeight: 700,
          fontSize: 50,
          lineHeight: 1.05,
          letterSpacing: "-0.01em",
          whiteSpace: "nowrap",
          opacity: pTitle * out,
          transform: `translateY(${interpolate(pTitle, [0, 1], [24 * dir, 0])}px) scale(${interpolate(pTitle, [0, 1], [0.96, 1])})`,
        }}
      >
        {aspects[i].title}
      </div>
      <div
        style={{
          marginTop: 12,
          fontWeight: 400,
          fontSize: 28,
          lineHeight: 1.2,
          whiteSpace: "nowrap",
          color: theme.colors.textDim,
          opacity: pDetail * out,
          transform: `translateY(${interpolate(pDetail, [0, 1], [18 * dir, 0])}px)`,
        }}
      >
        {aspects[i].detail}
      </div>
    </div>
  );
};

// Convergência: o único elemento amarelo do quadro, no centro comum (a gestão), nunca num aspecto.
const Glow: React.FC = () => {
  const { frame, fps, s, wave, out } = useT();
  const p = spring({ frame: frame - s(T.glow), fps, config: theme.spring.slow }) * out;
  const settle = interpolate(frame, [s(T.glow) + 15, s(T.glow) + 75], [1, 0], { ...clamp, easing: theme.ease.out });
  // Depois de assentar, o brilho respira devagar (5 s por respiração).
  const breath = 0.5 + 0.5 * wave(4, -Math.PI / 2);
  const r = HUB_INNER + 4 + 10 * (1 - p);
  return (
    <circle
      cx={HUB.x}
      cy={HUB.y}
      r={r}
      fill="none"
      stroke={theme.colors.hero}
      strokeWidth={2 + 2 * settle}
      opacity={p * Math.min(1, 0.35 + 0.65 * settle + 0.25 * breath)}
      style={{ filter: `drop-shadow(0 0 ${8 + 14 * settle + 8 * breath}px ${theme.colors.heroGlow})` }}
    />
  );
};

const Hub: React.FC = () => {
  const { frame, fps, s, wave, out, durationInFrames } = useT();
  const enter = spring({ frame: frame - s(T.hubIn), fps, config: theme.spring.slow }) * out;
  const converge = spring({ frame: frame - s(T.spokes + 0.6), fps, config: theme.spring.slow });
  const breathe = 1 + wave(4) * 0.012;
  const r1 = 150 - 22 * converge;
  // O anel pontilhado gira uma volta por ciclo: 360° no fim = mesmo quadro do início.
  const spin = (360 * frame) / durationInFrames;
  return (
    <g transform={`translate(${HUB.x} ${HUB.y}) scale(${(0.85 + 0.15 * enter) * breathe})`} opacity={enter}>
      <circle
        r={r1}
        fill="none"
        stroke={theme.colors.ring}
        strokeWidth={1.5}
        strokeDasharray="3 9"
        transform={`rotate(${spin})`}
      />
      <circle r={HUB_INNER} fill="#0B0B0B" fillOpacity={0.6 + 0.4 * converge} stroke={theme.colors.ring} strokeWidth={1.5} />
    </g>
  );
};

const Logo: React.FC = () => {
  const { frame, fps, s, out } = useT();
  const p = spring({ frame: frame - s(T.logo), fps, config: theme.spring.slow });
  const w = 184;
  return (
    <Img
      src={staticFile("logo-negativo.svg")}
      style={{
        position: "absolute",
        width: w,
        left: HUB.x - w / 2,
        top: HUB.y - (w * LOGO_RATIO) / 2,
        opacity: p * out,
        transform: `translateY(${interpolate(p, [0, 1], [14, 0])}px) scale(${interpolate(p, [0, 1], [0.92, 1])})`,
      }}
    />
  );
};

// Pulsos discretos (brancos, nunca amarelos) correndo de cada aspecto até o centro, sempre juntos.
// 8 pulsos por ciclo (2,5 s cada), para emendar no loop.
const Flow: React.FC = () => {
  const { frame, s, out, durationInFrames } = useT();
  const on = interpolate(frame, [s(T.flowIn), s(T.flowIn + 1.5)], [0, 1], clamp) * out;
  if (on <= 0) return null;
  const period = durationInFrames / 8;
  const t = (frame % period) / period;
  const e = theme.ease.inOut(t);
  const fade = Math.sin(Math.PI * t);
  return (
    <>
      {NODES.map((n, i) => {
        const d = dist(n, HUB);
        const a = { x: n.x + ((HUB.x - n.x) * 34) / d, y: n.y + ((HUB.y - n.y) * 34) / d };
        const k = 1 - HUB_INNER / d;
        const b = { x: n.x + (HUB.x - n.x) * k, y: n.y + (HUB.y - n.y) * k };
        return (
          <circle
            key={i}
            cx={a.x + (b.x - a.x) * e}
            cy={a.y + (b.y - a.y) * e}
            r={3.5}
            fill={theme.colors.text}
            opacity={0.5 * fade * on}
          />
        );
      })}
    </>
  );
};

export const M06Gestao: React.FC = () => {
  const [n1, n2, n3] = NODES;
  return (
    <AbsoluteFill style={{ backgroundColor: theme.colors.bg }}>
      <BgMesh />
      <AbsoluteFill>
        <svg width={S} height={S} viewBox={`0 0 ${S} ${S}`}>
          <Hub />
          {/* Relação entre os três aspectos: as três ligações se fecham juntas, sem ordem de leitura */}
          <DrawLine a={n1} b={n2} start={T.ring[0]} end={T.ring[1]} />
          <DrawLine a={n2} b={n3} start={T.ring[0]} end={T.ring[1]} />
          <DrawLine a={n3} b={n1} start={T.ring[0]} end={T.ring[1]} />
          {/* Convergência dos três aspectos para a visão da gestão */}
          {NODES.map((n, i) => {
            const toward = 1 - HUB_INNER / dist(n, HUB);
            const end = { x: n.x + (HUB.x - n.x) * toward, y: n.y + (HUB.y - n.y) * toward };
            const st = T.spokes + i * T.spokeStagger;
            return <DrawLine key={i} a={n} b={end} start={st} end={st + T.spokeDur} width={1.5} color={theme.colors.ring} />;
          })}
          <Flow />
          <Glow />
          {NODES.map((_, i) => (
            <Node key={i} i={i} />
          ))}
        </svg>
      </AbsoluteFill>
      {NODES.map((_, i) => (
        <Label key={i} i={i} />
      ))}
      <Logo />
      <Grade />
      <Grain />
      <Vignette />
    </AbsoluteFill>
  );
};
