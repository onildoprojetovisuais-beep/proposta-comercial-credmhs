import React from "react";
import { Composition } from "remotion";
import { M06Gestao } from "./M06Gestao";
import { video } from "./theme";
import { TrilhaValor } from "./TrilhaValor";
import { REFERENCE_PROPS, REFERENCE_SIZE, TRAIL_DURATION, TRAIL_FPS } from "../../src/motion/trail/timing";

export const RemotionRoot: React.FC = () => (
  <>
  <Composition
    id="M06Gestao"
    component={M06Gestao}
    durationInFrames={Math.round(video.seconds * video.fps)}
    fps={video.fps}
    width={video.size}
    height={video.size}
  />
  {/* Trilha de valor (V2): geometria de referência do desktop; na página a geometria é medida. */}
  <Composition
    id="TrilhaValor"
    component={TrilhaValor}
    durationInFrames={TRAIL_DURATION}
    fps={TRAIL_FPS}
    width={REFERENCE_SIZE.width}
    height={REFERENCE_SIZE.height}
    defaultProps={REFERENCE_PROPS}
  />
  </>
);
