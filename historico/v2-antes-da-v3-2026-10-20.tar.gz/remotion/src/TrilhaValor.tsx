import React from "react";
import { AbsoluteFill } from "remotion";
// Composição compartilhada com a página (src/motion/trail). Aqui só ganha o fundo amarelo da
// seção e a fonte, para Studio e renders de conferência. A página usa a mesma cena no Player.
import { TrailScene } from "../../src/motion/trail/TrailScene";
import type { TrailSceneProps } from "../../src/motion/trail/timing";
import { ensureFonts } from "./fonts";

export const TrilhaValor: React.FC<TrailSceneProps> = (props) => {
  ensureFonts();
  return (
    <AbsoluteFill style={{ background: "#FFCA00", fontFamily: "'Sommet Rounded', Arial, sans-serif" }}>
      <TrailScene {...props} />
    </AbsoluteFill>
  );
};
