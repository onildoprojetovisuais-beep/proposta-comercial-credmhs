import { continueRender, delayRender, staticFile } from "remotion";
import { theme } from "./theme";

const faces: Array<[string, string]> = [
  ["SommetRoundedRegular.otf", "400"],
  ["SommetRoundedBold.otf", "700"],
  ["SommetRoundedBlack.otf", "900"],
];

let started = false;

export const ensureFonts = () => {
  if (started || typeof document === "undefined") return;
  started = true;
  const handle = delayRender("Carregando Sommet Rounded");
  Promise.all(
    faces.map(([file, weight]) => {
      const face = new FontFace(theme.fonts.family, `url(${staticFile(`fonts/${file}`)}) format("opentype")`, {
        weight,
        style: "normal",
      });
      return face.load().then((loaded) => {
        document.fonts.add(loaded);
      });
    }),
  )
    .then(() => continueRender(handle))
    .catch((err) => {
      console.error(err);
      continueRender(handle);
    });
};
