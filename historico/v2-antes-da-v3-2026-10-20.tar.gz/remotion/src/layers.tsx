import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "./theme";

// Camada 1 — fundo preto da marca com luz amarela muito discreta e lenta.
// Deriva periódica (1 e 2 voltas por ciclo) para o loop emendar sem salto.
export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const a = (2 * Math.PI * frame) / durationInFrames;
  const d1 = Math.sin(a) * 30;
  const d2 = Math.cos(2 * a) * 26;
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <div
        style={{
          position: "absolute",
          width: 1100,
          height: 1100,
          borderRadius: "50%",
          left: -10 + d1,
          top: -40,
          background: `radial-gradient(circle, ${theme.colors.heroSoft}, transparent 60%)`,
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 900,
          height: 900,
          borderRadius: "50%",
          right: -380 - d2,
          bottom: -420,
          background: `radial-gradient(circle, ${theme.colors.bgLift}, transparent 65%)`,
        }}
      />
    </AbsoluteFill>
  );
};

// Camada 4 — grade sutil que unifica o conjunto.
export const Grade: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background:
        "linear-gradient(180deg, rgba(0,0,0,0.18), transparent 26%, transparent 74%, rgba(0,0,0,0.25))",
    }}
  />
);

// Camada 5 — grão estático (não animado, para manter o arquivo leve) e vinheta.
const noiseSvg =
  "<svg xmlns='http://www.w3.org/2000/svg' width='240' height='240'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='2' seed='7'/></filter><rect width='240' height='240' filter='url(#n)' opacity='0.5'/></svg>";
const noise = `url("data:image/svg+xml,${encodeURIComponent(noiseSvg)}")`;

export const Grain: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      backgroundImage: noise,
      backgroundSize: "240px",
      opacity: 0.05,
      mixBlendMode: "overlay",
    }}
  />
);

export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background: "radial-gradient(ellipse at center, transparent 58%, rgba(0,0,0,0.45) 100%)",
    }}
  />
);
