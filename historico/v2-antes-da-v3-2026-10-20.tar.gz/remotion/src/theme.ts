// Fonte única de tokens da composição M06.
// Cores: Brandbook Grupo CRED MHS (2021), p. 28 — amarelo #FFCA00 (Pantone 116 C) e preto 100%.
// O logotipo oficial (logo_nova.svg) usa #FEC702 / #1E1D1D; a versão negativa aplica branco
// no lugar do preto, conforme a página 39 do brandbook ("marca em negativo sobre fundos escuros").
// Tipografia: Sommet Rounded (brandbook p. 35), carregada localmente de public/fonts.
import { Easing } from "remotion";

export const video = {
  fps: 30,
  seconds: 20, // ciclo em loop: formação lenta → respiração → dissolução → recomeça
  size: 1080, // 1:1 — ver README para a justificativa
} as const;

export const theme = {
  colors: {
    bg: "#000000",
    bgLift: "#0D0D0D",
    hero: "#FFCA00", // único elemento amarelo por quadro
    heroGlow: "rgba(255, 202, 0, 0.35)",
    heroSoft: "rgba(255, 202, 0, 0.10)",
    text: "#FFFFFF",
    textDim: "rgba(255, 255, 255, 0.66)",
    line: "rgba(255, 255, 255, 0.28)",
    ring: "rgba(255, 255, 255, 0.14)",
  },
  fonts: {
    family: "Sommet Rounded",
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    snappy: { damping: 16, stiffness: 150, mass: 0.6 },
    // Entradas do loop: lentas e sem rebote.
    slow: { damping: 30, stiffness: 28, mass: 1.2 },
  },
} as const;

// Conteúdo: somente os três aspectos de M06 (docs/02-copy.md e docs/04, "Scroll narrativo de M06").
export const aspects = [
  { title: "Acompanhamento", detail: "Portal, atendimento e SLA" },
  { title: "Integração", detail: "Sistemas e dados" },
  { title: "Informação gerencial", detail: "Indicadores e Power BI" },
] as const;
