import { ChapterNavigation, scrollToChapter } from '../components/ui';
import Abertura from '../components/sections/v2/Abertura';
import Institucional from '../components/sections/v2/Institucional';
import Relacionamento from '../components/sections/v2/Relacionamento';
import Dados from '../components/sections/v2/Dados';
import GestaoIntegrada from '../components/sections/v2/GestaoIntegrada';
import Trilha from '../components/sections/v2/Trilha';
import Solucoes from '../components/sections/v2/Solucoes';
import Contato from '../components/sections/v2/Contato';
import { copy } from '../content';
import { CHAPTER_IDS, CHAPTER_INDEX } from './chapterIndex';
import { useCurrentChapter } from './useCurrentChapter';
import styles from './App.module.css';

const g = copy.global;

/**
 * Composição da página V2 (docs/REVISAO-CRED-MHS-V2.md, rev. 2.1): skip link, header (logo +
 * índice discreto), oito dobras conduzidas por rolagem, footer. Montada por PresentationRoot
 * depois que o executivo foi resolvido. Sem pauta, prioridades, contador ou "Nova apresentação".
 */
export default function App() {
  const current = useCurrentChapter(CHAPTER_IDS);

  return (
    <>
      <a className="skip-link" href="#conteudo">
        {g.skipLink}
      </a>

      <header className={styles.header}>
        <div className={`container ${styles.headerInner}`}>
          <a
            className={styles.brand}
            href="#abertura"
            aria-label="CRED MHS — início da apresentação"
            onClick={(e) => {
              e.preventDefault();
              scrollToChapter('abertura');
            }}
          >
            <img
              src="/brand/cred-mhs-logo.svg"
              alt={`${g.brand} — ${g.tagline}`}
              width={1600}
              height={481}
              className={styles.logo}
            />
          </a>
          <ChapterNavigation chapters={CHAPTER_INDEX} currentId={current} menuLabel={g.menu} />
        </div>
      </header>

      <main id="conteudo" tabIndex={-1} className={styles.main}>
        <Abertura />
        <Institucional />
        <Relacionamento />
        <Dados />
        <GestaoIntegrada />
        <Trilha />
        <Solucoes />
        <Contato />
      </main>

      <footer className={styles.footer} data-surface="dark">
        <div className={`container ${styles.footerInner}`}>
          <img
            src="/brand/cred-mhs-logo-negativo.svg"
            alt={`${g.brand} — ${g.tagline}`}
            width={1600}
            height={481}
            loading="lazy"
            className={styles.footerLogo}
          />
          <p className={styles.footerText}>{g.tagline}</p>
        </div>
      </footer>
    </>
  );
}
