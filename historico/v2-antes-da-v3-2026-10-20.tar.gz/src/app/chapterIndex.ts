import type { ChapterNavItem } from '../components/ui';
import type { ChapterId } from '../types/presentation';
import { chapterFromHash, chapters } from '../content';

/**
 * Índice derivado de src/content/chapters.ts (fonte única dos rótulos). Ordem = ordem da página.
 */
export const CHAPTER_INDEX: ChapterNavItem[] = chapters.map((c) => ({ id: c.id, label: c.navLabel }));

export const CHAPTER_IDS: ChapterId[] = CHAPTER_INDEX.map((c) => c.id);

/**
 * Resolve o hash da URL para o ID do capítulo: id atual (#trilha) ou hash da V1 (#m05, #ecossistema),
 * via `legacyHashes`. Desconhecido → null.
 */
export function sectionIdFromHash(hash: string): ChapterId | null {
  return chapterFromHash(hash)?.id ?? null;
}
