/**
 * Mídia extraída de sources/apresentacao-original.pptx (ppt/media) e copiada para
 * public/media/pptx/ com nomes descritivos. Originais preservados no PPTX.
 *
 * Regras (CLAUDE.md, docs/04, docs/07):
 * - `stock: true` = fotografia de banco/ilustrativa. NUNCA legendar ou posicionar como
 *   equipe, unidade, cliente ou atendimento da CRED. Uso só como atmosfera, com alt neutro.
 * - Logos de clientes: vínculo não qualificado (P07). Linguagem de percurso; sem cases/resultados.
 * - Credenciais (ISO/LGPD): referência visual do slide 18; titular, escopo e validade ausentes
 *   (P05/P06). Não exibir como certificação da CRED até confirmação.
 */

export type MediaKind = 'client-logo' | 'client-mosaic' | 'stock-photo' | 'credential-reference';

export interface MediaItem {
  /** Caminho público (servido a partir de /). */
  src: string;
  width: number;
  height: number;
  kind: MediaKind;
  /** Slide de origem no PPTX. */
  sourceSlide: number;
  /** Nome do arquivo dentro de ppt/media do PPTX. */
  pptxFile: string;
  /** O que a imagem representa. */
  represents: string;
  /** Fotografia de banco/ilustrativa (não é da CRED). */
  stock: boolean;
  /** Texto alternativo sugerido. Logos: nome da empresa. Ilustrativas: descrição neutra. */
  alt: string;
  /** Observações de uso/pendência. Não exibir ao prospect. */
  note?: string;
}

const logo = (
  file: string,
  pptxFile: string,
  name: string,
  width: number,
  height: number,
  note?: string,
): MediaItem => ({
  src: `/media/pptx/clientes/${file}.png`,
  width,
  height,
  kind: 'client-logo',
  sourceSlide: 16,
  pptxFile,
  represents: `Logotipo ${name} (relação "Empresas que estão no percurso", slide 16)`,
  stock: false,
  alt: name,
  note,
});

/** Logos individuais do slide 16. Os tons de cinza vêm do próprio PPTX. */
export const CLIENT_LOGOS: MediaItem[] = [
  logo('cervantes', 'image29.png', 'Cervantes', 800, 283),
  logo('cimento-nacional', 'image30.png', 'Cimento Nacional', 300, 161),
  logo('apia', 'image31.png', 'Ápia', 334, 151),
  logo('caparao', 'image32.png', 'Caparaó', 464, 108),
  logo('cencosud', 'image33.png', 'Cencosud', 800, 438),
  logo('loja-eletrica', 'image34.png', 'Loja Elétrica Ltda.', 800, 240),
  logo('sg-ompi', 'image35.png', 'SG Ompi', 228, 138),
  logo('perfa-alimentos', 'image36.png', 'PER’FA alimentos', 598, 165),
  logo('hyatt', 'image37.png', 'Hyatt', 235, 119),
  logo('grupo-sotreq', 'image38.png', 'Grupo Sotreq', 283, 173),
  logo('storm-group', 'image39.png', 'Storm Group', 225, 225),
  logo('minalba-brasil', 'image40.png', 'Minalba Brasil', 300, 168),
  logo('radix', 'image41.png', 'Radix — Engenharia e Software', 200, 101),
  logo('alianca-energia', 'image42.png', 'Aliança — A nova geração da energia', 402, 125),
  logo('banco-bmg', 'image43.png', 'Banco BMG', 300, 168),
  logo('tora', 'image44.png', 'Tora', 229, 220),
  logo('orguel', 'image45.png', 'Orguel', 331, 95),
  logo('guara', 'image46.png', 'Guará', 204, 192),
  logo('economart', 'image47.png', 'Economart Atacadista', 204, 192),
  logo('nacional-gas', 'image48.png', 'Nacional Gás', 204, 192),
  logo('villefort', 'image49.png', 'Villefort Atacadista', 127, 120, 'Arquivo muito pequeno (127px); legibilidade baixa em escala útil.'),
  logo('unicred', 'image50.png', 'Unicred', 162, 148, 'Presente como imagem no slide 16, mas ausente da transcrição em Markdown. Conciliar (P07).'),
  logo('trigo', 'image51.png', 'Trigo', 308, 76),
  logo('radisson-barra', 'image52.png', 'Radisson — Barra Rio de Janeiro', 242, 135),
  logo('hotel-santa-teresa', 'image53.png', 'Hotel Santa Teresa — MGallery Rio', 493, 349),
  logo('grupo-iter', 'image54.png', 'Grupo Iter', 362, 125),
  logo('hotel-nacional', 'image55.png', 'Hotel Nacional — Rio de Janeiro', 330, 130),
  logo('ferrareze-freitas', 'image56.png', 'Ferrareze & Freitas Advogados', 163, 88, 'Arquivo pequeno; texto do logo fica ilegível abaixo de ~160px.'),
  logo('rede-manaus', 'image57.png', 'Rede Manaus', 175, 68),
  logo('ombrello', 'image58.png', 'Ombrello', 300, 52),
  logo('fairmont-copacabana', 'image59.jpeg', 'Fairmont — Rio de Janeiro Copacabana', 345, 152),
  logo('dom-atacadista', 'image60.png', 'Dom Atacadista', 225, 225),
  logo('caixa', 'image61.png', 'Caixa Econômica Federal', 225, 225),
  logo('cimed', 'image63.png', 'Cimed', 148, 148),
  logo('cimed-variante-cinza', 'image62.png', 'Cimed', 257, 141, 'Variante recortada do mesmo logo Cimed. Usar só uma das duas.'),
  logo('brasfrigo', 'image64.png', 'Brasfrigo', 153, 148),
  logo('jia-group', 'image65.png', 'JIA Group', 230, 148),
  logo('csn', 'image66.png', 'CSN', 161, 148),
  logo('cesari', 'image67.png', 'Cesari', 248, 148),
];

/**
 * Mosaico adicional do slide 16 com marcas NÃO transcritas no Markdown
 * (Cencosud, Grupo Caparaó, Mart Minas, Grupo Orguel, Grupo Líder, Grupo GNC, Trevo Lácteos,
 * Laboratório Globo, DMA/EPA, Conartes, Tambasa, EPO, Rodeiro, Port). image28 é duplicata.
 */
export const CLIENT_MOSAIC: MediaItem = {
  src: '/media/pptx/clientes/mosaico-adicional-slide16.png',
  width: 1600,
  height: 319,
  kind: 'client-mosaic',
  sourceSlide: 16,
  pptxFile: 'image27.png',
  represents: 'Faixa com 14 logotipos adicionais do slide 16',
  stock: false,
  alt: 'Logotipos de Cencosud, Grupo Caparaó, Mart Minas, Grupo Orguel, Grupo Líder, Grupo GNC, Trevo Lácteos, Laboratório Globo, DMA, EPA, Conartes, Tambasa, EPO, Empreendimentos Rodeiro e Port',
  note: 'Inventário visual a conciliar com Nil (P07) antes de exibir; nomes não constam da transcrição.',
};

const stock = (
  file: string,
  pptxFile: string,
  sourceSlide: number,
  represents: string,
  alt: string,
  width: number,
  height: number,
): MediaItem => ({
  src: `/media/pptx/ilustrativas/${file}.webp`,
  width,
  height,
  kind: 'stock-photo',
  sourceSlide,
  pptxFile,
  represents,
  stock: true,
  alt,
  note: 'Foto de banco/ilustrativa. Não representa equipe, unidade ou cliente da CRED.',
});

/** Fotografias ilustrativas do PPTX (todas aparentam ser de banco de imagens). */
export const STOCK_PHOTOS: MediaItem[] = [
  stock('ilustrativa-saude-medico', 'image12.jpg', 7, 'Médico com estetoscópio (abertura de Saúde Ocupacional)', 'Profissional de saúde com estetoscópio', 1600, 1067),
  stock('ilustrativa-seguranca-trabalhador', 'image14.jpg', 8, 'Trabalhador segurando capacete (Segurança do Trabalho)', 'Trabalhador segurando capacete de segurança', 1600, 1065),
  stock('ilustrativa-tecnologia', 'image15.jpg', 9, 'Mão tocando interface digital (Gestão e Tecnologia)', 'Ilustração de interação com tecnologia digital', 1600, 998),
  stock('ilustrativa-ead-estudante', 'image16.png', 10, 'Pessoa estudando no notebook (Treinamentos/EAD)', 'Pessoa assistindo a uma aula on-line no notebook', 1600, 1068),
  stock('ilustrativa-digitacao-notebook', 'image17.jpeg', 11, 'Mãos digitando em notebook (diferenciais)', 'Mãos digitando em um notebook', 1600, 1067),
  stock('ilustrativa-reuniao-escritorio', 'image23.jpg', 12, 'Reunião em escritório (fundo dos slides 12–15)', 'Pessoas reunidas em um escritório', 1600, 1067),
  stock('ilustrativa-grupo-profissionais', 'image5.jpeg', 4, 'Grupo de profissionais de diversas áreas (institucional)', 'Grupo de profissionais de diferentes áreas', 1600, 1066),
];

const cred = (file: string, pptxFile: string, represents: string, alt: string, width: number, height: number, ext = 'webp'): MediaItem => ({
  src: `/media/pptx/credenciais/${file}.${ext}`,
  width,
  height,
  kind: 'credential-reference',
  sourceSlide: 18,
  pptxFile,
  represents,
  stock: false,
  alt,
  note: 'Selo genérico do slide 18, sem titular/escopo/validade. Não exibir como certificação até confirmação (P05/P06).',
});

export const CREDENTIAL_REFERENCES: MediaItem[] = [
  cred('iso-27001-referencia', 'image74.jpg', 'Selo ISO 27001', 'ISO 27001', 447, 447),
  cred('iso-9001-2015-referencia', 'image75.jpg', 'Selo ISO 9001:2015', 'ISO 9001:2015', 600, 500),
  cred('iso-45001-referencia', 'image76.jpg', 'Selo ISO 45001', 'ISO 45001', 460, 434),
  cred('lgpd-referencia', 'image73.png', 'Marca textual LGPD com escudo', 'LGPD', 453, 190, 'png'),
];

/**
 * Não copiados (registro): image2–4, image11 (posts com texto embutido); image1, image13
 * (linhas decorativas); image6/24 (foto de banco duplicada); image7–10, image18–22 e SVGs do
 * slide 17 (ícones genéricos — evitar ícones repetidos); image25 (texto rasterizado);
 * image26 (logo antigo rasterizado — usar SVG oficial); image28 (duplicata de image27);
 * image77–80 (ícones de contato); image81 (retrato de Sabrina 546×609 — há original em
 * assets/executives/sabrina-ferreira/foto-sabrina.png); hdphoto*.wdp (JPEG XR, formato não web).
 */
export const ALL_PPTX_MEDIA: MediaItem[] = [
  ...CLIENT_LOGOS,
  CLIENT_MOSAIC,
  ...STOCK_PHOTOS,
  ...CREDENTIAL_REFERENCES,
];
