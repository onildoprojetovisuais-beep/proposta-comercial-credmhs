import { useCallback, useState } from 'react';
import { Button, IconArrow, SectionShell, scrollToChapter, sectionTitleId } from '../../ui';
import { copy } from '../../../content';
import { formatTemplate } from '../../../lib/format';
import { useExecutive } from '../../../state';
import { Portrait } from './shared';
import styles from './Abertura.module.css';

const c = copy.abertura;
const g = copy.global;

/**
 * 01 — Abertura pessoal. Foto, nome e cargo reais do perfil resolvido por `?executivo=`.
 * Sem foto (ou falha ao carregar) → composição tipográfica. Sem campos para o visitante.
 */
export default function Abertura() {
  const executive = useExecutive();
  const [noPhoto, setNoPhoto] = useState(!executive.photo);
  const onMissing = useCallback(() => setNoPhoto(true), []);

  return (
    <SectionShell
      id="abertura"
      title={c.title}
      header={false}
      width="full"
      spacing="none"
      surface="yellow"
      className={styles.section}
    >
      <div className={`container ${styles.grid}`} data-has-photo={!noPhoto}>
        {!noPhoto ? (
          <figure className={styles.portrait}>
            <span className={styles.sun} aria-hidden="true" />
            <Portrait
              executive={executive}
              sizes="(min-width: 1024px) 40vw, 100vw"
              priority
              className={styles.photo}
              onMissing={onMissing}
            />
            <figcaption className={styles.caption}>
              <span className={styles.name}>{executive.fullName}</span>
              <span className={styles.role}>
                {executive.role} · {g.brand}
              </span>
            </figcaption>
          </figure>
        ) : null}

        <div className={styles.text}>
          <p className={styles.greeting}>{formatTemplate(c.greetingTemplate, { firstName: executive.firstName })}</p>
          <h1 id={sectionTitleId('abertura')} className={styles.title}>
            {c.title}
          </h1>
          <p className={styles.lead}>{c.body}</p>
          <div className={styles.actions}>
            <Button
              href="#institucional"
              size="lg"
              iconAfter={<IconArrow />}
              onClick={(e) => {
                e.preventDefault();
                scrollToChapter('institucional');
              }}
            >
              {c.cta}
            </Button>
          </div>
        </div>
        {/* Sem retrato: a identidade ocupa a coluna da foto no desktop e fica abaixo do texto no mobile. */}
        {noPhoto ? (
          <p className={styles.identity}>
            <span className={styles.name}>{executive.fullName}</span>
            <span className={styles.role}>
              {executive.role} · {g.brand}
            </span>
          </p>
        ) : null}
      </div>
    </SectionShell>
  );
}
