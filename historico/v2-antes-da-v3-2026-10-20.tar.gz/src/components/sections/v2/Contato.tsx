import { useCallback, useState } from 'react';
import { Button, IconArrow, SectionShell, sectionTitleId, SectionHeader } from '../../ui';
import { chapterById, copy } from '../../../content';
import { contactLinks } from '../../../lib';
import { formatTemplate } from '../../../lib/format';
import { useExecutive } from '../../../state';
import { Portrait } from './shared';
import styles from './Contato.module.css';

const c = copy.contato;

/**
 * 08 — Continuidade comercial. Volta ao executivo correto (foto, nome, cargo do perfil).
 * Ações na ordem: WhatsApp (só canal confirmado) → Enviar e-mail → Agendar (só URL real).
 * A primeira disponível é a principal; as demais são secundárias. Telefone, LinkedIn e site
 * ficam como links de apoio. Nada é enviado automaticamente nem pré-preenchido com escolhas.
 */
export default function Contato() {
  const executive = useExecutive();
  const links = contactLinks(executive);
  const [noPhoto, setNoPhoto] = useState(!executive.photo);
  const onMissing = useCallback(() => setNoPhoto(true), []);

  const actions = [
    links.whatsApp ? { key: 'wa', href: links.whatsApp.href, label: c.actions.whatsApp, external: true } : null,
    links.email ? { key: 'email', href: links.email.href, label: c.actions.email, external: false } : null,
    links.booking ? { key: 'booking', href: links.booking.href, label: c.actions.booking, external: true } : null,
  ].filter((a): a is NonNullable<typeof a> => a !== null);

  const secondary = [
    links.phone
      ? { key: 'phone', href: links.phone.href, label: formatTemplate(c.actions.phoneTemplate, { firstName: executive.firstName }), detail: links.phone.label, external: false }
      : null,
    links.linkedIn ? { key: 'linkedin', href: links.linkedIn.href, label: c.actions.linkedIn, detail: null, external: true } : null,
    links.website ? { key: 'site', href: links.website.href, label: c.actions.website, detail: links.website.label, external: true } : null,
  ].filter((a): a is NonNullable<typeof a> => a !== null);

  // Perfil sem nenhum canal válido: a dobra não fica sem destino — oferece o site institucional.
  if (!actions.length && !secondary.length) {
    secondary.push({ key: 'site', href: c.institutionalSite.href, label: c.actions.website, detail: c.institutionalSite.label, external: true });
  }

  return (
    <SectionShell id="contato" title={c.title} header={false} surface="yellow">
      <div className={styles.layout} data-has-photo={!noPhoto}>
        <div className={styles.person}>
          {!noPhoto ? (
            <span className={styles.photoWrap}>
              <Portrait
                executive={executive}
                sizes="(min-width: 1024px) 320px, 200px"
                alt={executive.photoAlt}
                className={styles.photo}
                onMissing={onMissing}
              />
            </span>
          ) : null}
          <p className={styles.identity}>
            <span className={styles.name}>{executive.fullName}</span>
            <span className={styles.role}>
              {executive.role} · {copy.global.brand}
            </span>
          </p>
        </div>

        <div className={styles.text}>
          <SectionHeader
            titleId={sectionTitleId('contato')}
            eyebrow={chapterById.contato.navLabel}
            title={c.title}
            intro={<p>{c.body}</p>}
            flush
          />

          {actions.length ? (
            <div className={styles.actions}>
              {actions.map((a, i) => (
                <Button
                  key={a.key}
                  href={a.href}
                  size="lg"
                  variant={i === 0 ? 'primary' : 'secondary'}
                  iconAfter={i === 0 ? <IconArrow direction="right" /> : undefined}
                  {...(a.external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
                >
                  {a.label}
                </Button>
              ))}
            </div>
          ) : null}

          {links.email ? <p className={styles.emailLine}>{links.email.label}</p> : null}

          {secondary.length ? (
            <ul role="list" className={styles.secondary}>
              {secondary.map((s) => (
                <li key={s.key}>
                  <a href={s.href} {...(s.external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}>
                    {s.label}
                    {s.external ? <span className="visually-hidden"> (abre em nova aba)</span> : null}
                  </a>
                  {s.detail ? <span className={styles.detail}>{s.detail}</span> : null}
                </li>
              ))}
            </ul>
          ) : null}
        </div>
      </div>
    </SectionShell>
  );
}
