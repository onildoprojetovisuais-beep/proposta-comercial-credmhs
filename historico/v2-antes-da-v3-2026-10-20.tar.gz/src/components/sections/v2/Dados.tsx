import type { CSSProperties } from 'react';
import { SectionShell } from '../../ui';
import { chapterById, copy } from '../../../content';
import { useReveal } from './shared';
import styles from './Dados.module.css';

const c = copy.dados;

/** Fragmentos do grafismo: palavras da própria dor (agendamentos, exames, documentos). */
const FRAGMENTS = ['Agendamentos', 'Exames', 'Documentos'] as const;

/**
 * 04 — Dados e visibilidade. Dor → resposta → três pontos.
 * Grafismo conceitual (decorativo, aria-hidden): informação dispersa à esquerda, a mesma
 * informação organizada à direita. Lido como antes/depois mesmo parado; sem números, sem
 * gráfico de desempenho, sem interface que simule produto.
 * Movimento (uma vez, CSS): a seta se desenha e cada fragmento disperso acende e "passa" para a
 * sua linha organizada, uma de cada vez. Estado final = o mesmo grafismo estático.
 */
export default function Dados() {
  const ref = useReveal<HTMLElement>();

  return (
    <SectionShell ref={ref} id="dados" eyebrow={chapterById.dados.navLabel} title={c.title} surface="white">
      <div className={styles.layout}>
        <div className={styles.text}>
          <p className={styles.pain}>{c.pain}</p>
          <p className={styles.answer}>{c.answer}</p>
          <ul role="list" className={styles.points}>
            {c.points.map((p, i) => (
              <li key={p} className={styles.point}>
                <span className={styles.pointNum} aria-hidden="true">
                  {String(i + 1).padStart(2, '0')}
                </span>
                {p}
              </li>
            ))}
          </ul>
        </div>

        <div className={styles.visual} aria-hidden="true" data-reveal style={{ '--n': FRAGMENTS.length } as CSSProperties}>
          <div className={styles.scatter}>
            {FRAGMENTS.map((f, i) => (
              <span key={f} className={`${styles.chip} ${styles[`s${i + 1}`]}`} style={{ '--i': i } as CSSProperties}>
                {f}
              </span>
            ))}
            <span className={`${styles.sheet} ${styles.d1}`} />
            <span className={`${styles.sheet} ${styles.d2}`} />
            <span className={`${styles.sheet} ${styles.d3}`} />
            <span className={`${styles.sheet} ${styles.d4}`} />
          </div>
          <span className={styles.arrow} />
          <div className={styles.order}>
            {FRAGMENTS.map((f, i) => (
              <span key={f} className={styles.row} style={{ '--i': i } as CSSProperties}>
                <span className={styles.rowLabel}>{f}</span>
                <span className={styles.rowItems}>
                  <i />
                  <i />
                  <i />
                  <i />
                </span>
              </span>
            ))}
          </div>
        </div>
      </div>
    </SectionShell>
  );
}
