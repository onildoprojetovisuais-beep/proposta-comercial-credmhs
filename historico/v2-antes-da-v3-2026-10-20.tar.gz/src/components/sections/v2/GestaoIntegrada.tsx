import { SectionShell } from '../../ui';
import { chapterById, copy } from '../../../content';
import styles from './GestaoIntegrada.module.css';

const c = copy.gestaoIntegrada;

/**
 * 05 — Gestão integrada e valor para o negócio. Único momento em preto (contraste pontual).
 * Saúde e segurança aparecem como uma oferta integrada — sem cards de serviço, seleção ou pacote.
 * O fecho faz a ponte para o eixo Reputacional (liderança, RH, comunicação), sem prometer
 * melhoria mensurável de reputação.
 */
export default function GestaoIntegrada() {
  return (
    <SectionShell
      id="gestao-integrada"
      eyebrow={chapterById['gestao-integrada'].navLabel}
      title={c.title}
      intro={<p>{c.body}</p>}
      surface="dark"
    >
      <div className={styles.grid}>
        <p className={styles.answer}>
          <span className={styles.sun} aria-hidden="true" />
          {c.answer}
        </p>
        <p className={styles.closing}>{c.closing}</p>
      </div>
    </SectionShell>
  );
}
