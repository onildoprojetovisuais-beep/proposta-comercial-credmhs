import { useId, useState } from 'react';
import type { CSSProperties } from 'react';
import { Button, IconChevron, SectionShell } from '../../ui';
import { capacityFacts, chapterById, copy, featuredClients, otherClients, positioningKey, reachText } from '../../../content';
import type { Client } from '../../../types';
import { CLIENT_LOGO_BY_ID, clientLogoSrc } from './clientLogos';
import { useReveal } from './shared';
import styles from './Institucional.module.css';

const c = copy.institucional;

/** Marca com proporção preservada e área visual equilibrada; sem arquivo conciliado → nome em texto. */
function ClientMark({ client }: { client: Client }) {
  const logo = CLIENT_LOGO_BY_ID[client.id];
  if (!logo) return <span className={styles.nameFallback}>{client.name}</span>;
  const [x, y, cw, ch] = logo.crop;
  const ratio = cw / ch;
  const cropStyle = { '--r': ratio, '--s': 1 / Math.sqrt(ratio) } as CSSProperties;
  const imgStyle: CSSProperties = {
    width: `${(logo.w / cw) * 100}%`,
    height: `${(logo.h / ch) * 100}%`,
    left: `${(-x / cw) * 100}%`,
    top: `${(-y / ch) * 100}%`,
  };
  return (
    <span className={styles.crop} style={cropStyle}>
      <img
        src={clientLogoSrc(logo)}
        alt={client.name}
        width={logo.w}
        height={logo.h}
        loading="lazy"
        decoding="async"
        className={styles.logo}
        style={imgStyle}
      />
    </span>
  );
}

/**
 * 02 — Apresentação institucional (obrigatória, logo depois da abertura): quem é a CRED MHS,
 * números preservados de src/content/facts.ts (sem alterar valor nem qualificador) e empresas
 * da trajetória (faixa principal + consulta complementar). Sem cases ou resultados.
 */
export default function Institucional() {
  const [expanded, setExpanded] = useState(false);
  const listId = useId();
  const ref = useReveal<HTMLElement>();

  return (
    <SectionShell
      ref={ref}
      id="institucional"
      eyebrow={chapterById.institucional.navLabel}
      title={c.title}
      intro={<p>{c.body}</p>}
      surface="white"
    >
      {/* Legenda do 3C/3I: primeira seção com selo; explica o que os selos das próximas indicam.
          Sem ordem nem setas — é posicionamento, não processo. */}
      <div className={styles.positioning}>
        <p className={styles.positioningTitle}>{positioningKey.title}</p>
        <dl className={styles.positioningGroups}>
          {positioningKey.groups.map((g) => (
            <div key={g.group} className={styles.positioningGroup}>
              <dt className={styles.positioningCode}>{g.group}</dt>
              <dd>{g.labels.join(' · ')}</dd>
            </div>
          ))}
        </dl>
      </div>

      <div className={styles.numbers}>
        <h3 className={`t-h3 ${styles.subTitle}`}>{c.numbersTitle}</h3>
        <dl className={styles.facts}>
          {capacityFacts.map((f) => (
            <div key={f.id} className={styles.fact} data-reveal>
              <dt className={styles.qualifier}>{f.qualifier}</dt>
              <dd className={`t-number ${styles.value}`}>{f.value}</dd>
            </div>
          ))}
        </dl>
        <p className={styles.reach}>
          <span className={styles.reachMark} aria-hidden="true" />
          {reachText}
        </p>
      </div>

      <div className={styles.clients}>
        <h3 className={`t-h3 ${styles.subTitle}`}>{c.clientsTitle}</h3>
        <ul role="list" className={styles.wall}>
          {featuredClients.map((client) => (
            <li key={client.id} className={styles.plate}>
              <ClientMark client={client} />
            </li>
          ))}
        </ul>

        <div className={styles.more}>
          <Button
            variant="link"
            aria-expanded={expanded}
            aria-controls={listId}
            onClick={() => setExpanded((v) => !v)}
            iconAfter={<IconChevron open={expanded} />}
          >
            {expanded ? c.clientsLess : c.clientsMore}
          </Button>
        </div>

        <ul id={listId} role="list" hidden={!expanded} className={`${styles.wall} ${styles.others}`}>
          {otherClients.map((client) => (
            <li key={client.id} className={`${styles.plate} ${styles.plateSmall}`}>
              <ClientMark client={client} />
            </li>
          ))}
        </ul>
      </div>

      <p className={styles.transition}>{c.transition}</p>
    </SectionShell>
  );
}
