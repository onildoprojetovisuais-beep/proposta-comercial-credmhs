import { SectionShell } from '../../ui';
import { chapterById, copy } from '../../../content';
import { formatTemplate } from '../../../lib/format';
import { useExecutive } from '../../../state';
import { Portrait, useReveal } from './shared';
import styles from './Relacionamento.module.css';

const c = copy.relacionamento;

/**
 * 03 — Relacionamento e continuidade. Dor → resposta → três pontos.
 * A composição Sua empresa — executivo — Operação CRED MHS é uma ilustração linear da resposta
 * (decorativa: o texto já diz a mesma coisa). Não é framework, triângulo nem metodologia.
 */
export default function Relacionamento() {
  const executive = useExecutive();
  const ref = useReveal<HTMLElement>();

  return (
    <SectionShell
      ref={ref}
      id="relacionamento"
      eyebrow={chapterById.relacionamento.navLabel}
      title={c.title}
      surface="yellow"
    >
      <div className={styles.body}>
        <p className={styles.pain}>{c.pain}</p>
        <div className={styles.response}>
          <p className={styles.answer}>{c.answer}</p>
          <ul role="list" className={styles.points}>
            {c.points.map((p) => (
              <li key={p} className={styles.point}>
                {p}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className={styles.chain} aria-hidden="true" data-reveal>
        <span className={styles.node}>{c.diagram.client}</span>
        <span className={styles.link} />
        <span className={`${styles.node} ${styles.person}`}>
          <span className={styles.avatar}>
            <Portrait executive={executive} sizes="96px" alt="" className={styles.avatarImg} />
          </span>
          {formatTemplate(c.diagram.executive, { firstName: executive.firstName })}
        </span>
        <span className={styles.link} />
        <span className={styles.node}>{c.diagram.operation}</span>
      </div>
    </SectionShell>
  );
}
