import type { CSSProperties } from 'react';
import { Accordion, SectionShell } from '../../ui';
import { copy, reachText, solutionAxes } from '../../../content';
import { useReveal } from './shared';
import styles from './Solucoes.module.css';

const c = copy.solucoes;

/**
 * 07 — Quatro eixos de soluções (Normativo, Reputacional, Gestão, Inovação) + capacidade de
 * atendimento. Resumos e exemplos sempre visíveis; aprofundamento opcional por <details>.
 * Não há seleção, carrinho, contador nem quinta coluna (Investimento é etapa da trilha).
 * `inventory` nunca é renderizado.
 */
export default function Solucoes() {
  const ref = useReveal<HTMLElement>();

  return (
    <SectionShell ref={ref} id="solucoes" eyebrow={c.eyebrow} title={c.title} intro={<p>{c.body}</p>} surface="white">
      {/* Entrada coordenada: os quatro filetes se desenham em sequência, como uma linha só, e os
          eixos sobem juntos — mesma atuação. Resumos e exemplos visíveis desde o início. */}
      <ul role="list" className={styles.axes} data-reveal>
        {solutionAxes.map((axis, i) => (
          <li key={axis.id} className={styles.axis} data-axis={axis.id} style={{ '--i': i } as CSSProperties}>
            <span className={styles.index} aria-hidden="true">
              {String(i + 1).padStart(2, '0')}
            </span>
            <h3 className={styles.label}>{axis.label}</h3>
            <p className={styles.summary}>{axis.summary}</p>
            <ul role="list" className={styles.examples}>
              {axis.examples.map((ex) => (
                <li key={ex}>{ex}</li>
              ))}
            </ul>
            {axis.detail ? (
              <Accordion summary={axis.detail.label} className={styles.detail}>
                <ul role="list" className={styles.detailList}>
                  {axis.detail.items.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
                {axis.detail.note ? <p className={styles.detailNote}>{axis.detail.note}</p> : null}
              </Accordion>
            ) : null}
          </li>
        ))}
      </ul>

      <p className={styles.scopeNote}>{c.scopeNote}</p>

      <div className={styles.network}>
        <div className={styles.networkText}>
          <h3 className={styles.networkTitle}>{c.network.title}</h3>
          <p className={styles.networkBody}>{c.network.body}</p>
        </div>
        <div className={styles.networkReach}>
          <p className={styles.reach}>{reachText}</p>
          <dl className={styles.legend}>
            {c.network.legend.map((n) => (
              <div key={n.id} className={styles.legendItem} data-kind={n.id}>
                <dt>
                  <span className={styles.legendMark} aria-hidden="true" />
                  {n.label}
                </dt>
                <dd>{n.text}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </SectionShell>
  );
}
