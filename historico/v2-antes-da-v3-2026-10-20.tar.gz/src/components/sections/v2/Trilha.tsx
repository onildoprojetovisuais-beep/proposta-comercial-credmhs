import { Suspense, lazy, useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { SectionShell } from '../../ui';
import { copy, valueTrail } from '../../../content';
import { LAST_FRAME, activeStepAt, reachedCountAt, type TrailSceneProps } from '../../../motion/trail/timing';
import type { TrailPlayerHandle } from '../../../motion/trail/TrailPlayer';
import { useReveal } from './shared';
import styles from './Trilha.module.css';

const TrailPlayer = lazy(() => import('../../../motion/trail/TrailPlayer'));

const c = copy.trilha;

/** Margem da camada de movimento além da lista (o halo do marcador não é cortado). */
const BLEED = 24;

type Phase = 'idle' | 'playing' | 'paused' | 'ended';

function motionAllowed() {
  if (typeof window === 'undefined' || typeof IntersectionObserver === 'undefined') return false;
  return !window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
}

interface Geometry {
  width: number;
  height: number;
  scene: TrailSceneProps;
}

/**
 * 06 — Trilha de valor: Normativo → Reputacional → Gestão → Inovação → Investimento.
 * Lista ordenada semântica, ordem fixa do framework (src/content/valueTrail.ts). Nomes e textos
 * são HTML, sempre visíveis, sem clique.
 *
 * Movimento (Remotion, src/motion/trail): ao entrar na tela, a linha percorre as cinco etapas uma
 * vez; cada etapa recebe destaque e sua descrição ganha fundo branco. No fim, as cinco ficam iguais
 * e a composição completa permanece. Saiu da tela no meio → pausa; voltou → continua. Pausar e
 * repetir são discretos. Reduced motion, sem IntersectionObserver ou antes de o player carregar:
 * composição completa estática (marcadores e trilho em CSS).
 * Não é régua de maturidade nem "onde o cliente está": o destaque só acompanha a explicação.
 */
export default function Trilha() {
  const ref = useReveal<HTMLElement>();
  const listRef = useRef<HTMLOListElement>(null);
  const playerRef = useRef<TrailPlayerHandle | null>(null);
  const steps = [...valueTrail].sort((a, b) => a.order - b.order);

  const [motion, setMotion] = useState(motionAllowed);
  const [near, setNear] = useState(false);
  const [geometry, setGeometry] = useState<Geometry | null>(null);
  const [mounted, setMounted] = useState(false);
  const [phase, setPhase] = useState<Phase>('idle');
  const [frame, setFrame] = useState(0);
  const autoPaused = useRef(false);
  const toggleRef = useRef<HTMLButtonElement>(null);
  const replayRef = useRef<HTMLButtonElement>(null);
  const phaseRef = useRef<Phase>('idle');
  phaseRef.current = phase;

  // Preferência alterada com a página aberta: reduced motion desliga o movimento na hora.
  useEffect(() => {
    const mq = window.matchMedia?.('(prefers-reduced-motion: reduce)');
    if (!mq) return;
    const onChange = () => {
      if (mq.matches) {
        playerRef.current?.pause();
        setMotion(false);
      }
    };
    mq.addEventListener?.('change', onChange);
    return () => mq.removeEventListener?.('change', onChange);
  }, []);

  // Carrega o player um pouco antes de a seção aparecer.
  useEffect(() => {
    const el = listRef.current;
    if (!motion || !el) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setNear(true);
          io.disconnect();
        }
      },
      { rootMargin: '800px 0px' },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [motion]);

  // Centros dos marcadores medidos no DOM: a composição desenha exatamente sobre a lista,
  // na horizontal (≥1024) ou na vertical (celular).
  useLayoutEffect(() => {
    const list = listRef.current;
    if (!motion || !near || !list) return;
    const labels = steps.map((s) => String(s.order).padStart(2, '0'));
    const measure = () => {
      const box = list.getBoundingClientRect();
      const markers = Array.from(list.querySelectorAll<HTMLElement>('[data-marker]'));
      if (markers.length !== labels.length || box.width === 0) return;
      const points = markers.map((m) => {
        const r = m.getBoundingClientRect();
        return { x: r.left - box.left + r.width / 2 + BLEED, y: r.top - box.top + r.height / 2 + BLEED };
      });
      setGeometry({
        width: box.width + BLEED * 2,
        height: box.height + BLEED * 2,
        scene: { points, marker: markers[0].getBoundingClientRect().width, labels },
      });
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(list);
    return () => ro.disconnect();
    // `steps` vem de conteúdo estático.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [motion, near]);

  const play = useCallback(() => {
    autoPaused.current = false;
    const start = playerRef.current?.getCurrentFrame() ?? 0;
    playerRef.current?.play();
    setPhase('playing');
    // Logo após montar (ex.: página aberta em #trilha) o player diz que toca mas fica parado no
    // quadro; pausar e tocar de novo destrava.
    const check = (tries: number) =>
      window.setTimeout(() => {
        const p = playerRef.current;
        if (phaseRef.current !== 'playing' || !p || p.getCurrentFrame() !== start) return;
        p.pause();
        p.play();
        if (tries > 1) check(tries - 1);
      }, 500);
    check(6);
  }, []);

  const pause = useCallback((auto: boolean) => {
    autoPaused.current = auto;
    playerRef.current?.pause();
    setPhase('paused');
  }, []);

  const replay = useCallback(() => {
    phaseRef.current = 'idle';
    playerRef.current?.seekTo(0);
    setFrame(0);
    play();
  }, [play]);

  // Toca uma vez quando boa parte da lista está visível; pausa se ela sai da tela no meio;
  // continua ao voltar, a menos que a pausa tenha sido pedida pelo botão.
  useEffect(() => {
    const el = listRef.current;
    if (!motion || !mounted || !el) return;
    // "Boa parte" = 45% da lista ou metade da tela (lista mais alta que a tela no celular).
    const enter = new IntersectionObserver(
      ([entry]) => {
        const visible = entry.intersectionRect.height;
        const enough = Math.min(entry.boundingClientRect.height * 0.45, window.innerHeight * 0.5);
        if (!entry.isIntersecting || visible < enough) return;
        const p = phaseRef.current;
        if (p === 'idle' || (p === 'paused' && autoPaused.current)) play();
      },
      { threshold: Array.from({ length: 21 }, (_, i) => i / 20) },
    );
    const leave = new IntersectionObserver(([entry]) => {
      if (!entry.isIntersecting && phaseRef.current === 'playing') pause(true);
    });
    enter.observe(el);
    leave.observe(el);
    return () => {
      enter.disconnect();
      leave.disconnect();
    };
  }, [motion, mounted, play, pause]);

  // Só re-renderiza a lista quando muda a etapa em destaque ou o número de etapas alcançadas.
  const onFrame = useCallback((f: number) => {
    if (phaseRef.current === 'ended') return;
    setFrame((prev) => (activeStepAt(prev) === activeStepAt(f) && reachedCountAt(prev) === reachedCountAt(f) ? prev : f));
  }, []);

  const onEnded = useCallback(() => {
    // seekTo no último quadro pode emitir `ended` de novo.
    if (phaseRef.current === 'ended') return;
    // O botão de pausa sai no fim; se estava com o foco, o foco passa para "Repetir".
    if (document.activeElement === toggleRef.current) replayRef.current?.focus();
    // A composição completa permanece: o player fica parado no último quadro.
    phaseRef.current = 'ended';
    playerRef.current?.pause();
    playerRef.current?.seekTo(LAST_FRAME);
    setFrame(LAST_FRAME);
    setPhase('ended');
  }, []);

  const attachPlayer = useCallback((h: TrailPlayerHandle | null) => {
    playerRef.current = h;
    if (h) setMounted(true);
  }, []);

  const live = motion && mounted && geometry !== null;
  const active = live ? activeStepAt(frame) : -1;
  const reached = live ? reachedCountAt(frame) : steps.length;

  return (
    <SectionShell ref={ref} id="trilha" className={styles.section} eyebrow={c.eyebrow} title={c.title} intro={<p>{c.body}</p>} surface="yellow">
      <div className={styles.stage}>
        <ol ref={listRef} className={styles.trail} data-reveal data-motion={live ? 'on' : 'off'}>
          {steps.map((s, i) => (
            <li
              key={s.id}
              className={styles.step}
              data-state={!live ? undefined : i === active ? 'active' : i < reached ? 'reached' : 'upcoming'}
            >
              <span className={styles.marker} data-marker aria-hidden="true">
                {String(s.order).padStart(2, '0')}
              </span>
              <h3 className={styles.label}>{s.label}</h3>
              <p className={styles.text}>{s.text}</p>
            </li>
          ))}
        </ol>

        {motion && near && geometry ? (
          <div className={styles.motionLayer} style={{ inset: -BLEED }} aria-hidden="true">
            <Suspense fallback={null}>
              <TrailPlayer
                ref={attachPlayer}
                scene={geometry.scene}
                width={geometry.width}
                height={geometry.height}
                onFrame={onFrame}
                onEnded={onEnded}
              />
            </Suspense>
          </div>
        ) : null}
      </div>

      {/* Espaço reservado desde o início: os botões aparecem sem empurrar o texto abaixo. */}
      {motion ? (
        <div className={styles.controls}>
          {live && phase !== 'idle' && phase !== 'ended' ? (
            <button
              ref={toggleRef}
              type="button"
              className={styles.control}
              onClick={() => (phase === 'playing' ? pause(false) : play())}
            >
              {phase === 'playing' ? <PauseIcon /> : <PlayIcon />}
              {phase === 'playing' ? 'Pausar animação' : 'Continuar animação'}
            </button>
          ) : null}
          {live && phase !== 'idle' ? (
            <button ref={replayRef} type="button" className={styles.control} onClick={replay}>
              <ReplayIcon /> Repetir animação
            </button>
          ) : null}
        </div>
      ) : null}

      <p className={styles.closing}>{c.closing}</p>
    </SectionShell>
  );
}

function PauseIcon() {
  return (
    <svg viewBox="0 0 16 16" width="16" height="16" aria-hidden="true">
      <rect x="3" y="2" width="3.5" height="12" rx="1" fill="currentColor" />
      <rect x="9.5" y="2" width="3.5" height="12" rx="1" fill="currentColor" />
    </svg>
  );
}

function PlayIcon() {
  return (
    <svg viewBox="0 0 16 16" width="16" height="16" aria-hidden="true">
      <path d="M4 2.5v11l9-5.5z" fill="currentColor" />
    </svg>
  );
}

function ReplayIcon() {
  return (
    <svg viewBox="0 0 16 16" width="16" height="16" aria-hidden="true">
      <path d="M8 3a5 5 0 1 1-4.6 3" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M2 2.5v4h4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
