import { useEffect, useRef, useState } from 'react';
import type { RefObject } from 'react';
import type { Executive } from '../../../types';

/**
 * Peças compartilhadas das dobras V2: retrato do executivo e revelação decorativa por rolagem.
 */

/**
 * Fontes otimizadas do retrato do projeto (`photoSource: 'bundled'`), derivadas do caminho do
 * perfil. Foto do Supabase (`remote`) já chega otimizada pelo painel: um único arquivo.
 */
function portraitSources(photo: string) {
  const base = photo.replace(/\.(png|jpe?g|webp|avif)$/i, '');
  // Só o perfil documentado tem derivados gerados (public/media/executives/*-640/-1098).
  if (!base.endsWith('/sabrina-ferreira')) return null;
  return {
    avif: `${base}-640.avif 640w, ${base}-1098.avif 1098w`,
    webp: `${base}-640.webp 640w, ${base}-1098.webp 1098w`,
    fallback: `${base}-1098.jpg`,
  };
}

interface PortraitProps {
  executive: Executive;
  sizes: string;
  className?: string;
  /** Prioridade de carregamento (só na abertura). */
  priority?: boolean;
  /** Texto alternativo; '' quando o nome já está ao lado e a foto é complementar. */
  alt?: string;
  /** Chamado quando não há foto ou ela falha — a dobra usa o layout tipográfico. */
  onMissing?: () => void;
}

/** Retrato real do executivo (local com derivados ou URL remota). Sem foto → null. */
export function Portrait({ executive, sizes, className, priority, alt, onMissing }: PortraitProps) {
  const [failed, setFailed] = useState<string | null>(null);
  const photo = executive.photo && executive.photo !== failed ? executive.photo : null;

  useEffect(() => {
    if (!photo) onMissing?.();
  }, [photo, onMissing]);

  if (!photo) return null;
  const sources = executive.photoSource === 'bundled' ? portraitSources(photo) : null;
  return (
    <picture>
      {sources ? <source type="image/avif" srcSet={sources.avif} sizes={sizes} /> : null}
      {sources ? <source type="image/webp" srcSet={sources.webp} sizes={sizes} /> : null}
      <img
        src={sources?.fallback ?? photo}
        alt={alt ?? executive.photoAlt}
        width={executive.photoWidth ?? 1098}
        height={executive.photoHeight ?? 1433}
        {...(priority ? { fetchpriority: 'high' } : { loading: 'lazy' as const })}
        decoding="async"
        className={className}
        onError={() => setFailed(photo)}
      />
    </picture>
  );
}

/** Movimento permitido? Falso com reduced motion ou sem IntersectionObserver. */
function motionAllowed(): boolean {
  if (typeof window === 'undefined' || typeof IntersectionObserver === 'undefined') return false;
  return !window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
}

/**
 * Revelação decorativa: marca `data-inview="true"` nos `[data-reveal]` da seção quando entram na
 * tela e liga `html.motion-ok`. Nunca esconde texto (ver global.css): sem movimento permitido,
 * tudo já está no estado final.
 */
export function useReveal<T extends HTMLElement>(): RefObject<T> {
  const ref = useRef<T>(null);
  useEffect(() => {
    const root = ref.current;
    if (!root) return;
    const targets = Array.from(root.querySelectorAll<HTMLElement>('[data-reveal]'));
    if (!motionAllowed()) {
      targets.forEach((t) => t.setAttribute('data-inview', 'true'));
      return;
    }
    document.documentElement.classList.add('motion-ok');
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            e.target.setAttribute('data-inview', 'true');
            io.unobserve(e.target);
          }
        }
      },
      { rootMargin: '0px 0px -12% 0px', threshold: 0.15 },
    );
    targets.forEach((t) => io.observe(t));
    return () => io.disconnect();
  }, []);
  return ref;
}
