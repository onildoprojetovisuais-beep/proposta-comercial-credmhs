import { useEffect, useRef } from 'react';
import type { ReactNode } from 'react';
import { IconChevron } from './icons';
import styles from './Accordion.module.css';

/**
 * Accordion — <details>/<summary> nativo (teclado, toque e leitores de tela sem JS extra).
 * Conteúdo expande no fluxo do documento.
 *
 * Props:
 * - summary: rótulo visível do controle (ReactNode).
 * - meta?: texto curto à direita do rótulo (ex.: "12 itens").
 * - open?: controla o estado (opcional). Sem `open`, é não controlado (use `defaultOpen`).
 * - defaultOpen?: estado inicial no modo não controlado.
 * - onToggle?(open): chamado quando o usuário abre/fecha.
 * - name?: agrupa acordeões exclusivos (só um aberto) — atributo nativo `name`.
 * - variant?: 'line' (padrão, divisória editorial) | 'boxed' (fundo branco) | 'dark' (sobre fundo escuro).
 * - id?, className?, children: conteúdo expandido.
 */
export interface AccordionProps {
  summary: ReactNode;
  meta?: ReactNode;
  open?: boolean;
  defaultOpen?: boolean;
  onToggle?: (open: boolean) => void;
  name?: string;
  variant?: 'line' | 'boxed' | 'dark';
  id?: string;
  className?: string;
  children: ReactNode;
}

export function Accordion({
  summary,
  meta,
  open,
  defaultOpen,
  onToggle,
  name,
  variant = 'line',
  id,
  className,
  children,
}: AccordionProps) {
  const ref = useRef<HTMLDetailsElement>(null);
  const controlled = open !== undefined;

  // Modo controlado: sincroniza o atributo nativo com a prop.
  useEffect(() => {
    if (controlled && ref.current && ref.current.open !== open) ref.current.open = open;
  }, [controlled, open]);

  // Modo não controlado: aplica defaultOpen só na montagem.
  useEffect(() => {
    if (!controlled && defaultOpen && ref.current) ref.current.open = true;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const nameAttr = name ? ({ name } as Record<string, string>) : {};

  return (
    <details
      ref={ref}
      id={id}
      {...nameAttr}
      className={[styles.accordion, styles[variant], className ?? ''].filter(Boolean).join(' ')}
      onToggle={(e) => {
        const isOpen = e.currentTarget.open;
        if (controlled && isOpen === open) return;
        onToggle?.(isOpen);
      }}
    >
      <summary className={styles.summary}>
        <span className={styles.summaryText}>{summary}</span>
        {meta ? <span className={styles.meta}>{meta}</span> : null}
        <span className={styles.marker} aria-hidden="true">
          <IconChevron />
        </span>
      </summary>
      <div className={styles.panel}>{children}</div>
    </details>
  );
}
