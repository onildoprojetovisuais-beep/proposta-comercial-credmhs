import { useCallback, useEffect, useId, useRef, useState } from 'react';
import type { KeyboardEvent } from 'react';
import type { ChapterId } from '../../types/presentation';
import styles from './ChapterNavigation.module.css';

export interface ChapterNavItem {
  id: ChapterId;
  /** Rótulo curto do índice (src/content/chapters.ts: "Apresentação", "Trilha de valor"…). */
  label: string;
}

const prefersReducedMotion = () =>
  typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/**
 * Rola até o capítulo, atualiza o hash (preservando ?executivo=) e move o foco para a seção.
 * Movimento instantâneo em reduced motion. Reutilizável por CTAs de continuidade.
 */
export function scrollToChapter(id: ChapterId, opts: { focus?: boolean; instant?: boolean } = {}) {
  const el = document.getElementById(id);
  if (!el) return;
  // Saltos longos (> 2,5 telas) vão direto: a rolagem suave nativa passaria de 1 s ao vivo.
  const far = Math.abs(el.getBoundingClientRect().top) > window.innerHeight * 2.5;
  const behavior: ScrollBehavior = opts.instant || far || prefersReducedMotion() ? 'auto' : 'smooth';
  el.scrollIntoView({ behavior, block: 'start' });
  const url = `${window.location.pathname}${window.location.search}#${id}`;
  window.history.replaceState(window.history.state, '', url);
  if (opts.focus !== false) el.focus({ preventScroll: true });
}

/**
 * ChapterNavigation — índice discreto e opcional das oito dobras da V2. A rolagem conduz a
 * apresentação; o índice serve ao executivo ao vivo e a quem quiser saltar.
 * - Botão "Conteúdo" (todas as larguras) abre lista curta com os capítulos (disclosure).
 * - ≥1024px: trilho numerado lateral como atalho de ponteiro; o teclado usa a lista completa.
 * - Lista: setas ↑/↓, Home/End navegam; Esc fecha e devolve o foco ao botão; Tab para fora fecha.
 * - Indica o capítulo atual com aria-current="location" + marcador visual (não só cor).
 *
 * Props:
 * - chapters: ChapterNavItem[] na ordem da página.
 * - currentId: capítulo visível (ou null).
 * - onNavigate?(id): chamado após navegar (padrão já rola/foca via scrollToChapter).
 * - menuLabel?: rótulo do botão (padrão "Conteúdo").
 * Sem pauta, contador ou "Nova apresentação" (percurso descartado na V2).
 */
export interface ChapterNavigationProps {
  chapters: ChapterNavItem[];
  currentId: ChapterId | null;
  onNavigate?: (id: ChapterId) => void;
  menuLabel?: string;
}

export function ChapterNavigation({
  chapters,
  currentId,
  onNavigate,
  menuLabel = 'Conteúdo',
}: ChapterNavigationProps) {
  const [open, setOpen] = useState(false);
  const toggleRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const rootRef = useRef<HTMLDivElement>(null);
  const panelId = useId();

  const currentIndex = chapters.findIndex((c) => c.id === currentId);
  const current = currentIndex >= 0 ? chapters[currentIndex] : null;
  const pad = (n: number) => String(n).padStart(2, '0');

  const close = useCallback((returnFocus = true) => {
    setOpen(false);
    if (returnFocus) toggleRef.current?.focus();
  }, []);

  // Ao abrir, foca o capítulo atual (ou o primeiro).
  useEffect(() => {
    if (!open) return;
    const links = panelRef.current?.querySelectorAll<HTMLAnchorElement>('a[data-chapter-link]');
    if (!links?.length) return;
    const active = Array.from(links).find((a) => a.getAttribute('aria-current') === 'location');
    (active ?? links[0]).focus();
  }, [open]);

  // Fecha ao clicar/tocar fora.
  useEffect(() => {
    if (!open) return;
    const onPointer = (e: PointerEvent) => {
      const target = e.target as Element | null;
      if (rootRef.current && !rootRef.current.contains(target as Node)) close(false);
    };
    document.addEventListener('pointerdown', onPointer);
    return () => document.removeEventListener('pointerdown', onPointer);
  }, [open, close]);

  const go = (id: ChapterId) => {
    setOpen(false);
    scrollToChapter(id);
    onNavigate?.(id);
  };

  const onPanelKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Escape') {
      e.preventDefault();
      close();
      return;
    }
    if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(e.key)) return;
    const links = Array.from(
      panelRef.current?.querySelectorAll<HTMLAnchorElement>('a[data-chapter-link]') ?? [],
    );
    const idx = links.indexOf(document.activeElement as HTMLAnchorElement);
    if (idx === -1) return;
    e.preventDefault();
    const next =
      e.key === 'Home'
        ? 0
        : e.key === 'End'
          ? links.length - 1
          : (idx + (e.key === 'ArrowDown' ? 1 : -1) + links.length) % links.length;
    links[next]?.focus();
  };

  return (
    <div ref={rootRef} className={styles.root}>
      <div className={styles.bar}>
        <button
          ref={toggleRef}
          type="button"
          className={styles.toggle}
          aria-expanded={open}
          aria-controls={panelId}
          onClick={() => setOpen((v) => !v)}
        >
          <span className={styles.toggleIcon} aria-hidden="true" data-open={open} />
          <span className={styles.toggleText}>{menuLabel}</span>
          {current ? (
            <span className={styles.toggleCurrent}>
              <span className="visually-hidden">, capítulo atual: </span>
              <span aria-hidden="true">{pad(currentIndex + 1)}</span>
              <span className={styles.toggleCurrentLabel}>{current.label}</span>
            </span>
          ) : null}
        </button>
      </div>

      <div
        ref={panelRef}
        id={panelId}
        className={styles.panel}
        hidden={!open}
        onKeyDown={onPanelKeyDown}
        onBlur={(e) => {
          // Tab para fora do índice fecha o painel (sem roubar o foco de volta).
          const next = e.relatedTarget as Node | null;
          if (next && rootRef.current && !rootRef.current.contains(next)) close(false);
        }}
      >
        <nav aria-label="Capítulos da apresentação">
          <ol className={styles.list} role="list">
            {chapters.map((c, i) => {
              const isCurrent = c.id === currentId;
              return (
                <li key={c.id}>
                  <a
                    href={`#${c.id}`}
                    data-chapter-link
                    className={styles.link}
                    aria-current={isCurrent ? 'location' : undefined}
                    onClick={(e) => {
                      e.preventDefault();
                      go(c.id);
                    }}
                  >
                    <span className={styles.num} aria-hidden="true">
                      {pad(i + 1)}
                    </span>
                    <span className={styles.label}>{c.label}</span>
                    {isCurrent ? <span className={styles.here}>você está aqui</span> : null}
                  </a>
                </li>
              );
            })}
          </ol>
        </nav>
      </div>

      {/* Trilho lateral (≥1024px): atalho de ponteiro; teclado/leitor usam a lista acima. */}
      <div className={styles.rail} aria-hidden="true">
        {chapters.map((c, i) => (
          <a
            key={c.id}
            href={`#${c.id}`}
            tabIndex={-1}
            className={styles.railItem}
            data-current={c.id === currentId}
            onClick={(e) => {
              e.preventDefault();
              go(c.id);
            }}
          >
            <span className={styles.railLabel}>{c.label}</span>
            <span className={styles.railNum}>{pad(i + 1)}</span>
          </a>
        ))}
      </div>
    </div>
  );
}
