import type { ReactNode, SVGProps } from 'react';

/**
 * Ícones de função (layout v2). UM desenho por função — não trocar entre si:
 * - IconPlus / IconCheck → sem uso na apresentação V2 (pauta retirada); mantidos para o painel/futuro.
 * - IconChevron → EXPANDIR/RECOLHER (`open` gira 180°) ou abrir detalhe (`direction="right"`).
 * - IconArrow   → navegar para outro capítulo (↓) ou sair (→).
 * Traço 2.5 em viewBox 24, `currentColor`, decorativos (aria-hidden). Tamanho = 1em por padrão.
 */
type IconProps = Omit<SVGProps<SVGSVGElement>, 'children'>;

function Svg({ width = '1em', height = '1em', ...rest }: IconProps & { children: ReactNode }) {
  return (
    <svg
      viewBox="0 0 24 24"
      width={width}
      height={height}
      fill="none"
      stroke="currentColor"
      strokeWidth={2.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
      {...rest}
    />
  );
}

export function IconPlus(props: IconProps) {
  return (
    <Svg {...props}>
      <path d="M12 5v14M5 12h14" />
    </Svg>
  );
}

export function IconCheck(props: IconProps) {
  return (
    <Svg {...props}>
      <path d="M5 12.5l4.5 4.5L19 7.5" />
    </Svg>
  );
}

export interface IconChevronProps extends IconProps {
  /** Para expandir/recolher: true gira para cima. */
  open?: boolean;
  /** 'down' (padrão, disclosure) | 'right' (abrir detalhe lateral). */
  direction?: 'down' | 'right';
}

export function IconChevron({ open, direction = 'down', style, ...props }: IconChevronProps) {
  const base = direction === 'right' ? -90 : 0;
  // Sem `open` nem direção lateral, não fixa transform inline (o CSS do pai pode girar o ícone).
  const rotation = open === undefined && base === 0 ? undefined : `rotate(${base + (open ? 180 : 0)}deg)`;
  return (
    <Svg
      {...props}
      style={{
        transform: rotation,
        transition: 'transform var(--dur-base) var(--ease-out)',
        ...style,
      }}
    >
      <path d="M6 9.5l6 6 6-6" />
    </Svg>
  );
}

export function IconArrow({ direction = 'down', ...props }: IconProps & { direction?: 'down' | 'right' }) {
  return (
    <Svg {...props}>
      {direction === 'down' ? <path d="M12 5v14M6 13l6 6 6-6" /> : <path d="M5 12h14M13 6l6 6-6 6" />}
    </Svg>
  );
}
