import type { Chapter, ChapterId } from '../types/presentation';

/**
 * Copy pública V2 (docs/REVISAO-CRED-MHS-V2.md, rev. 2.1, §7). Base executável, ainda sujeita à
 * validação comercial da Sabrina — não declarar aprovação da cliente.
 * Variáveis entre chaves são preenchidas com `formatTemplate` (src/lib/format.ts):
 * {firstName}, {fullName}, {role}.
 * Notas internas, objetivos e pendências NÃO fazem parte destes textos (ver docs/07).
 * Eixos de soluções: src/content/solutions.ts. Trilha: src/content/valueTrail.ts.
 * Números: src/content/facts.ts. Empresas: src/content/clients.ts.
 */
export const copy = {
  abertura: {
    greetingTemplate: 'Olá, sou {firstName}.',
    title: 'Vou te mostrar como a CRED MHS pode apoiar a gestão de saúde e segurança do trabalho da sua empresa.',
    body: 'Meu papel é aproximar as necessidades da sua empresa da nossa operação e acompanhar essa relação.',
    cta: 'Saiba mais',
  },

  institucional: {
    eyebrow: 'CRED MHS',
    title: 'Conheça a estrutura por trás dessa parceria.',
    body: 'A CRED MHS atua em saúde e segurança do trabalho, com abrangência nacional e experiência em diferentes setores. Reunimos equipe multidisciplinar, estrutura de atendimento e tecnologia para apoiar a gestão das empresas e das pessoas que fazem parte delas.',
    numbersTitle: 'Nossa força em números.',
    clientsTitle: 'Empresas que fazem parte da nossa trajetória.',
    clientsMore: 'Ver todas as empresas',
    clientsLess: 'Mostrar menos empresas',
    transition: 'Essa estrutura ganha sentido na forma como acompanhamos a sua operação.',
  },

  relacionamento: {
    title: 'Quando sua empresa precisa de uma resposta, sabe com quem contar?',
    pain: 'Exames, documentos e atendimentos fazem parte da rotina. Para acompanhar tudo isso, sua empresa também precisa de acesso, clareza e continuidade.',
    answer: 'Você conta com um executivo de negócios para conectar suas demandas à operação da CRED MHS e acompanhar os próximos passos.',
    points: ['Uma pessoa de referência.', 'Conexão com a equipe operacional.', 'Acompanhamento próximo das demandas.'],
    // Rótulos da composição cliente → executivo → operação (microcopy de interface).
    diagram: { client: 'Sua empresa', executive: '{firstName}', operation: 'Operação CRED MHS' },
  },

  dados: {
    title: 'Você sabe o que os dados da sua operação estão mostrando?',
    pain: 'Agendamentos, exames e documentos geram informação todos os dias. Quando ela fica dispersa, acompanhar a operação e definir prioridades se torna mais difícil.',
    answer: 'A CRED MHS reúne acompanhamento, integração e informação gerencial para dar mais clareza à gestão.',
    points: ['Acompanhamento dos atendimentos.', 'Integração de informações e sistemas.', 'Dados organizados para a gestão.'],
  },

  gestaoIntegrada: {
    title: 'Sua empresa já tem os serviços. O que ela consegue gerir com eles?',
    body: 'Cumprir as exigências faz parte da operação. O próximo passo é conectar saúde, segurança, pessoas e informação às necessidades do negócio.',
    answer: 'Nossa atuação integra saúde e segurança do trabalho, gestão e tecnologia, com uma equipe multidisciplinar e acompanhamento próximo.',
    closing: 'Essa atuação também pode conectar saúde e segurança à liderança, ao RH e à comunicação da empresa, fortalecendo a percepção de cuidado com as pessoas.',
  },

  trilha: {
    eyebrow: 'Trilha de valor',
    title: 'E se a gestão de saúde e segurança orientasse também as decisões do negócio?',
    body: 'A trilha de valor da CRED MHS conecta as exigências da operação ao cuidado com as pessoas, à informação e às decisões de investimento.',
    // Etapas: `valueTrail` (src/content/valueTrail.ts).
    closing: 'Quando a diretoria pergunta o que precisa de atenção, essa visão ajuda a conectar a rotina às decisões.',
  },

  solucoes: {
    eyebrow: 'Soluções',
    title: 'Como essa visão se transforma em soluções para a sua empresa?',
    body: 'Organizamos nossa atuação em quatro eixos que conectam as necessidades da operação ao valor para o negócio.',
    // Eixos: `solutionAxes` (src/content/solutions.ts).
    scopeNote: 'A composição das soluções considera as necessidades e o escopo de cada empresa.',
    network: {
      title: 'Sua operação tem diferentes endereços. Nossa atuação tem abrangência nacional.',
      body: 'A rede própria e credenciada da CRED MHS apoia o atendimento em diferentes regiões do país.',
      // Microcopy de interface (legenda textual, sem mapa nem números repetidos). Denominação de "unidades" pendente (P03).
      legend: [
        { id: 'propria', label: 'Rede própria', text: 'Unidades da CRED MHS.' },
        { id: 'credenciada', label: 'Rede credenciada', text: 'Clínicas credenciadas em diferentes regiões.' },
      ],
    },
  },

  contato: {
    title: 'Vamos olhar para a sua operação com essa perspectiva?',
    body: 'Podemos aprofundar como a CRED MHS conecta acompanhamento, informação e soluções às necessidades da sua empresa.',
    actions: {
      whatsApp: 'Falar por WhatsApp',
      email: 'Enviar e-mail',
      booking: 'Agendar uma conversa',
      phoneTemplate: 'Ligar para {firstName}',
      linkedIn: 'LinkedIn',
      website: 'Site da CRED MHS',
    },
    emailSubject: 'Conversa sobre a CRED MHS',
    // Site institucional (slide 3). Usado só quando o perfil não tem nenhum canal válido.
    institutionalSite: { href: 'https://www.credmhs.com.br', label: 'www.credmhs.com.br' },
  },

  global: {
    brand: 'CRED MHS',
    // Assinatura atual (Sabrina, 13/10): "gestão" continua válida na narrativa, não na assinatura.
    tagline: 'Saúde e Segurança do Trabalho',
    menu: 'Conteúdo',
    skipLink: 'Pular para o conteúdo',
    close: 'Fechar',
  },
} as const;

/** Índice e ordem das dobras. `id` = id do <section> e hash da URL. */
export const chapters: readonly Chapter[] = [
  { id: 'abertura', navLabel: 'Apresentação', legacyHashes: ['m01', 'apresentacao', 'm02', 'prioridades'] },
  { id: 'institucional', navLabel: 'CRED MHS', legacyHashes: ['m03', 'estrutura', 'm04', 'empresas'] },
  { id: 'relacionamento', navLabel: 'Relacionamento' },
  { id: 'dados', navLabel: 'Dados', legacyHashes: ['m06', 'gestao-e-tecnologia'] },
  { id: 'gestao-integrada', navLabel: 'Gestão integrada', legacyHashes: ['m08', 'confianca'] },
  { id: 'trilha', navLabel: 'Trilha de valor' },
  { id: 'solucoes', navLabel: 'Soluções', legacyHashes: ['m05', 'ecossistema', 'm07', 'aplicacoes'] },
  { id: 'contato', navLabel: 'Contato', legacyHashes: ['m09', 'sua-pauta', 'm10', 'contato'] },
];

export const chapterById: Readonly<Record<ChapterId, Chapter>> = Object.fromEntries(
  chapters.map((c) => [c.id, c]),
) as Record<ChapterId, Chapter>;

/** Resolve um hash (#trilha, ou hash antigo da V1 como #m05) para o capítulo; desconhecido → null. */
export function chapterFromHash(hash: string): Chapter | null {
  let slug = hash.replace(/^#/, '');
  try {
    slug = decodeURIComponent(slug);
  } catch {
    return null;
  }
  slug = slug.trim().toLowerCase();
  if (!slug) return null;
  return chapters.find((c) => c.id === slug) ?? chapters.find((c) => c.legacyHashes?.includes(slug)) ?? null;
}
