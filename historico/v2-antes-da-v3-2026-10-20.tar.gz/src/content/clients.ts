import type { Client } from '../types';

/**
 * Dobra `institucional` (V2), sub-bloco “Empresas que fazem parte da nossa trajetória” — empresas citadas no slide 16 (relação textual recebida, docs/02 M04).
 * - A relação não prova resultados nem confirma contratos vigentes (P07).
 * - `logo` fica vazio até existir arquivo oficial em assets/clients/ (ou extraído e conciliado
 *   do PPTX). Não redesenhar logos a partir do nome; o nome em texto é fallback editorial.
 * - O PPTX tem ~40 imagens de marca sem nome associado; a conciliação com esta lista está pendente.
 */
const names: string[] = [
  'Cervantes',
  'Cimento Nacional',
  'Ápia',
  'Caparaó',
  'Cencosud',
  'Loja Elétrica Ltda.',
  'SG Ompi',
  'PER’FA alimentos',
  'Hyatt',
  'Grupo Sotreq',
  'Storm Group',
  'Minalba Brasil',
  'Radix — Engenharia e Software',
  'Aliança — A nova geração da energia.',
  'Banco BMG',
  'Tora',
  'Orguel',
  'Guará',
  'Economart Atacadista',
  'Nacional Gás',
  'Villefort Atacadista',
  'Trigo',
  'Radisson — Barra Rio de Janeiro',
  'Hotel Santa Teresa — MGallery Rio',
  'Grupo Iter',
  'HN Hotel Nacional — Rio de Janeiro',
  'Ferrareze & Freitas Advogados',
  'Rede Manaus',
  'Ombrello',
  'Fairmont — Rio de Janeiro Copacabana',
  'Dom Atacadista',
  'Caixa — Caixa Econômica Federal',
  'Cimed',
  'Brasfrigo',
  'JIA Group',
  'CSN',
  'Cesari',
];

function slugify(value: string): string {
  return value
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

export const clients: readonly Client[] = names.map((name) => ({
  id: slugify(name),
  name,
  sourceSlides: [16],
  relationshipStatus: 'listed-in-source',
  verificationStatus: 'source-supplied',
}));

/**
 * Faixa principal (6–8 marcas) da dobra `institucional`; as demais ficam na consulta complementar. Provisória: segue a ordem da fonte, sem juízo de
 * relevância, até Nil/CRED indicarem as marcas prioritárias e os logos oficiais.
 */
export const FEATURED_CLIENT_COUNT = 8;
export const featuredClients: readonly Client[] = clients.slice(0, FEATURED_CLIENT_COUNT);
export const otherClients: readonly Client[] = clients.slice(FEATURED_CLIENT_COUNT);
