import type { ChapterId } from '../types/presentation';

/**
 * Mapa de cobertura fonte → destino V2 (docs/V2-MAPEAMENTO-FRAMEWORKS.md; docs/07).
 * Uso interno de rastreabilidade. Nunca renderizar ao prospect.
 *
 * source:
 * - pptx: apresentação original (slides 1–19, sources/apresentacao-original.md)
 * - framework-solucoes: “Soluções que nos levam além” (quatro eixos)
 * - framework-trilha: “Trilha de valor na gestão de SSO” (cinco etapas)
 * - brandbook: Brandbook V0 rev. 200318
 *
 * treatment:
 * - principal: aparece na leitura principal
 * - detalhe: preservado em aprofundamento opcional (disclosure dos eixos, “ver todas as empresas”)
 * - condensado: sintetizado; redação original preservada em sources/
 * - inventario: preservado só no inventário (dados/fonte), não exibido
 * - retido: retido por pendência (ID de docs/07)
 * - retirado: removido por decisão da V2 (revisão §4), com motivo em `note`
 */
export type CoverageSource = 'pptx' | 'framework-solucoes' | 'framework-trilha' | 'brandbook';
export type CoverageTreatment = 'principal' | 'detalhe' | 'condensado' | 'inventario' | 'retido' | 'retirado';

export interface CoverageEntry {
  source: CoverageSource;
  /** Slide do PPTX (1–19). Ausente para frameworks e brandbook. */
  slide?: number;
  item: string;
  destination: ChapterId[];
  /** Local no código de conteúdo. */
  dataRef: string;
  treatment: CoverageTreatment;
  pendingRef?: string;
  note?: string;
}

export const coverage: readonly CoverageEntry[] = [
  // ---------------------------------------------------------------- PPTX
  // Slide 01
  { source: 'pptx', slide: 1, item: 'Marca CRED MHS', destination: ['abertura', 'contato'], dataRef: 'copy.global.brand / logo', treatment: 'principal' },
  { source: 'pptx', slide: 1, item: '“entre as 5 maiores em Saúde e Segurança do Trabalho”', destination: [], dataRef: 'facts#ranking', treatment: 'retido', pendingRef: 'P02' },

  // Slide 02
  { source: 'pptx', slide: 2, item: 'Caminhar lado a lado dos clientes na jornada de gestão', destination: ['abertura', 'relacionamento'], dataRef: 'copy.abertura.body / copy.relacionamento', treatment: 'condensado' },
  { source: 'pptx', slide: 2, item: 'Equipe personalizada que entende necessidades e sugere soluções na medida certa', destination: ['relacionamento', 'solucoes'], dataRef: 'copy.relacionamento.answer / copy.solucoes.scopeNote', treatment: 'condensado' },

  // Slide 03
  { source: 'pptx', slide: 3, item: '“Pessoas no centro” e convite a descobrir benefícios', destination: ['abertura', 'gestao-integrada'], dataRef: 'copy.abertura (retrato) / copy.gestaoIntegrada.closing', treatment: 'condensado', note: 'O slide anuncia benefícios sem especificá-los; nenhum benefício foi criado.' },
  { source: 'pptx', slide: 3, item: 'www.credmhs.com.br', destination: ['contato'], dataRef: 'executives.websiteUrl', treatment: 'principal' },

  // Slide 04
  { source: 'pptx', slide: 4, item: 'Operadora de SST, atuação estratégica, abrangência nacional, experiência multissetorial', destination: ['institucional'], dataRef: 'copy.institucional.body', treatment: 'condensado' },
  { source: 'pptx', slide: 4, item: '“30 anos”', destination: [], dataRef: 'facts#tempo-experiencia', treatment: 'retido', pendingRef: 'P01' },
  { source: 'pptx', slide: 4, item: 'Investimento em pessoas; gestão de SST como força estratégica para o negócio', destination: ['gestao-integrada', 'trilha'], dataRef: 'copy.gestaoIntegrada / valueTrail', treatment: 'condensado' },

  // Slide 05
  { source: 'pptx', slide: 5, item: 'Ecossistema de soluções com serviços integrados, customização', destination: ['gestao-integrada', 'solucoes'], dataRef: 'copy.gestaoIntegrada.answer / copy.solucoes.scopeNote', treatment: 'condensado' },
  { source: 'pptx', slide: 5, item: 'Quatro frentes (Saúde Ocupacional, Segurança do Trabalho, Gestão e Tecnologia, Treinamentos)', destination: ['solucoes'], dataRef: 'solutionAxes', treatment: 'retirado', note: 'Divisão provisória substituída pelos quatro eixos do framework (revisão §7-07). Itens migrados para solutionAxes[].inventory.' },

  // Slide 06
  { source: 'pptx', slide: 6, item: 'Gestão estratégica e valor em SSO, disponível para empresas de todo Brasil', destination: ['solucoes', 'institucional'], dataRef: 'copy.solucoes.network / reachText', treatment: 'condensado', note: 'Sem geolocalização ou endereços inventados.' },

  // Slide 07
  { source: 'pptx', slide: 7, item: 'Solução para requisitos da NR-7, documentos obrigatórios e ferramentas auxiliares', destination: ['solucoes'], dataRef: 'axisById.normativo', treatment: 'condensado', pendingRef: 'P18', note: 'Referência à NR-7 fora da página até redação técnica validada.' },
  { source: 'pptx', slide: 7, item: 'PCMSO, ASO, Relatório Anual, PPP, Gestão dos Exames, Convocação de Periódicos, In Company', destination: ['solucoes'], dataRef: 'axisById.normativo.inventory', treatment: 'detalhe', pendingRef: 'P10', note: 'Siglas no inventário; exibidos “Exames ocupacionais”, convocação de periódicos e exames na empresa.' },
  { source: 'pptx', slide: 7, item: '“e muitos outros…”', destination: [], dataRef: 'sources', treatment: 'inventario', note: 'Não enumerar itens não citados.' },

  // Slide 08
  { source: 'pptx', slide: 8, item: 'Equipe multidisciplinar (Engenheiros, Técnicos, áreas afins); implantação, adequação, auditoria', destination: ['institucional', 'gestao-integrada'], dataRef: 'copy.institucional.body / copy.gestaoIntegrada.answer', treatment: 'condensado' },
  { source: 'pptx', slide: 8, item: 'PGR/GRO, PCMAT, LTCAT, CIPA, Perícias, Laudos, Ordens de Serviço, Gestão de EPI', destination: ['solucoes'], dataRef: 'axisById.normativo.inventory', treatment: 'detalhe', pendingRef: 'P10' },

  // Slide 09
  { source: 'pptx', slide: 9, item: 'Customização de dados, mentoria para ativação de módulos, aprendizagem, indicadores', destination: ['dados'], dataRef: 'copy.dados / axisById.gestao.inventory', treatment: 'condensado' },
  { source: 'pptx', slide: 9, item: 'Integração ERP, interface online, GED, assinatura digital, app, acervo fotográfico, saúde remota, biometria, nuvem', destination: ['solucoes', 'dados'], dataRef: 'axisById.gestao', treatment: 'detalhe' },
  { source: 'pptx', slide: 9, item: '“100% aderente” / “100% na nuvem”', destination: [], dataRef: 'sources', treatment: 'inventario', note: '“100%” preservado só na fonte.' },
  { source: 'pptx', slide: 9, item: '“Certificada ISO 9001 e ISO45001”', destination: [], dataRef: 'credentials', treatment: 'retido', pendingRef: 'P05' },
  { source: 'pptx', slide: 9, item: '“Totalmente adequada à LGPD”', destination: [], dataRef: 'credentials#lgpd', treatment: 'retido', pendingRef: 'P06' },

  // Slide 10
  { source: 'pptx', slide: 10, item: 'Central EAD, mais de 77 cursos, conformidade declarada com NR1', destination: ['solucoes'], dataRef: 'axisById.inovacao', treatment: 'detalhe', pendingRef: 'P09', note: 'Central exibida no detalhe de Inovação; “77 cursos” só no inventário até revisão do catálogo.' },
  { source: 'pptx', slide: 10, item: 'Lista de 12 temas NR', destination: [], dataRef: 'axisById.inovacao.inventory', treatment: 'inventario', pendingRef: 'P10' },
  { source: 'pptx', slide: 10, item: 'Certificados, conteúdo programático, listas de presença integrados ao software', destination: ['solucoes'], dataRef: 'axisById.inovacao.detail', treatment: 'detalhe' },
  { source: 'pptx', slide: 10, item: '“Prático, Seguro, Intuitivo, Econômico, Atualizado”', destination: [], dataRef: 'sources', treatment: 'inventario', note: 'Adjetivos não exibidos.' },

  // Slide 11
  { source: 'pptx', slide: 11, item: 'Portal de Serviços On-line; acompanhamento do atendimento e SLA', destination: ['dados', 'solucoes'], dataRef: 'copy.dados.points / axisById.gestao.detail', treatment: 'condensado', pendingRef: 'P39', note: 'SLA não é exibido como promessa.' },
  { source: 'pptx', slide: 11, item: 'Teleatendimento e Telediagnóstico', destination: [], dataRef: 'axisById.inovacao.inventory', treatment: 'inventario' },
  { source: 'pptx', slide: 11, item: 'Parque próprio de equipamentos para medições', destination: ['solucoes'], dataRef: 'axisById.normativo (exemplo “Avaliações técnicas”)', treatment: 'condensado' },
  { source: 'pptx', slide: 11, item: '4 Soluções para o eSocial', destination: [], dataRef: 'facts#solucoes-esocial', treatment: 'retido', pendingRef: 'P08' },
  { source: 'pptx', slide: 11, item: 'Integração à Fábrica de Power BI', destination: [], dataRef: 'axisById.gestao.inventory', treatment: 'retido', pendingRef: 'P34' },

  // Slide 12
  { source: 'pptx', slide: 12, item: 'Sistema online que interliga locais de atendimento; parametrização eSocial; webservice com ERP', destination: ['dados', 'solucoes'], dataRef: 'copy.dados.points / axisById.gestao.detail', treatment: 'detalhe' },

  // Slide 13
  { source: 'pptx', slide: 13, item: 'Gestão do FAP/NTEP: acompanhamento das etapas, integração entre sistemas', destination: ['solucoes'], dataRef: 'axisById.inovacao.detail', treatment: 'detalhe', pendingRef: 'P11' },

  // Slide 14
  { source: 'pptx', slide: 14, item: 'Riscos Psicossociais NR1: Programa de Vigilância Epidemiológica sob medida', destination: ['solucoes'], dataRef: 'axisById.normativo.detail', treatment: 'detalhe', pendingRef: 'P38', note: 'Fora do framework; classificação provisória no Normativo. Nunca renomear como VIVA (P16).' },

  // Slide 15
  { source: 'pptx', slide: 15, item: 'Dez soluções adicionais', destination: ['solucoes'], dataRef: 'axisById.inovacao.detail / axisById.normativo.detail', treatment: 'detalhe', note: 'Gestão de Absenteísmo fora do framework (P38).' },

  // Slide 16
  { source: 'pptx', slide: 16, item: 'Título “Empresas que estão no percurso…”', destination: ['institucional'], dataRef: 'copy.institucional.clientsTitle', treatment: 'condensado' },
  { source: 'pptx', slide: 16, item: 'Relação textual de 37 empresas e logos conciliados', destination: ['institucional'], dataRef: 'clients / clientLogos', treatment: 'principal', pendingRef: 'P07' },
  { source: 'pptx', slide: 16, item: 'Copyright “Todos os direitos reservados a Sabrina Ferreira”', destination: [], dataRef: 'sources', treatment: 'retido', pendingRef: 'P17' },

  // Slide 17
  { source: 'pptx', slide: 17, item: '16 Unidades; +700 Clínicas Credenciadas; +550k Vidas Gerenciadas; +5k Clientes Atendidos', destination: ['institucional'], dataRef: 'capacityFacts', treatment: 'principal', pendingRef: 'P03' },
  { source: 'pptx', slide: 17, item: '27 Estados Atendidos', destination: ['institucional', 'solucoes'], dataRef: 'facts#estados-atendidos (fallback “Atuação nacional”)', treatment: 'retido', pendingRef: 'P04' },
  { source: 'pptx', slide: 17, item: '34 Anos de Experiência', destination: [], dataRef: 'facts#tempo-experiencia', treatment: 'retido', pendingRef: 'P01' },

  // Slide 18
  { source: 'pptx', slide: 18, item: 'ISO 27001, ISO 9001:2015, ISO 45001', destination: [], dataRef: 'credentials', treatment: 'retido', pendingRef: 'P05' },
  { source: 'pptx', slide: 18, item: 'Referência visual LGPD', destination: [], dataRef: 'credentials#lgpd', treatment: 'retido', pendingRef: 'P06' },

  // Slide 19
  { source: 'pptx', slide: 19, item: 'Sabrina Ferreira, Executiva de Negócios, foto', destination: ['abertura', 'contato'], dataRef: 'executives#sabrina-ferreira', treatment: 'principal' },
  { source: 'pptx', slide: 19, item: 'Telefone, LinkedIn, e-mail, site', destination: ['contato'], dataRef: 'executives / contactLinks', treatment: 'principal', pendingRef: 'P13' },
  { source: 'pptx', slide: 19, item: 'Convite a agendar conversa e pensar juntos a integração da gestão', destination: ['contato'], dataRef: 'copy.contato', treatment: 'condensado', pendingRef: 'P14', note: 'Sem botão “Agendar” enquanto não houver URL real.' },

  // ---------------------------------------------------------------- Frameworks (14/10/2026)
  { source: 'framework-solucoes', item: 'Eixo Normativo', destination: ['solucoes'], dataRef: 'axisById.normativo', treatment: 'principal', pendingRef: 'P33' },
  { source: 'framework-solucoes', item: 'Eixo Reputacional', destination: ['solucoes', 'gestao-integrada'], dataRef: 'axisById.reputacional / copy.gestaoIntegrada.closing', treatment: 'principal', pendingRef: 'P33' },
  { source: 'framework-solucoes', item: 'Eixo Gestão', destination: ['solucoes', 'dados'], dataRef: 'axisById.gestao', treatment: 'principal', pendingRef: 'P33' },
  { source: 'framework-solucoes', item: 'Eixo Inovação', destination: ['solucoes'], dataRef: 'axisById.inovacao', treatment: 'principal', pendingRef: 'P33' },
  { source: 'framework-solucoes', item: 'Símbolos BI/AI', destination: [], dataRef: 'axisById.gestao.inventory', treatment: 'inventario', pendingRef: 'P34' },
  { source: 'framework-solucoes', item: 'Ícones ESG/ODS', destination: [], dataRef: 'axisById.reputacional.inventory', treatment: 'inventario', pendingRef: 'P35' },
  { source: 'framework-solucoes', item: 'Cores diversas e tagline antiga da imagem', destination: [], dataRef: '—', treatment: 'retirado', note: 'Direção visual atual (amarelo, branco, preto) e assinatura “Saúde e Segurança do Trabalho” prevalecem (revisão §5).' },
  { source: 'framework-trilha', item: 'Cinco etapas: Normativo → Reputacional → Gestão → Inovação → Investimento', destination: ['trilha'], dataRef: 'valueTrail', treatment: 'principal', pendingRef: 'P33' },
  { source: 'framework-trilha', item: 'Sentido detalhado de cada etapa', destination: ['trilha'], dataRef: 'valueTrail.ts (comentário) / copy.trilha', treatment: 'condensado' },

  // ---------------------------------------------------------------- Brandbook
  { source: 'brandbook', item: '3C/3I — Credibilidade, Compromisso, Conhecimento, Inovação, Investimento, Inteligência', destination: ['institucional', 'relacionamento', 'dados', 'gestao-integrada'], dataRef: 'copy (linguagem e provas)', treatment: 'condensado', note: 'Orientam a linguagem; não são etapas nem componente.' },
];

/** Slides do PPTX sem nenhuma entrada de cobertura (deve ser vazio). */
export function uncoveredSlides(): number[] {
  const covered = new Set(coverage.filter((c) => c.source === 'pptx').map((c) => c.slide));
  return Array.from({ length: 19 }, (_, i) => i + 1).filter((s) => !covered.has(s));
}
