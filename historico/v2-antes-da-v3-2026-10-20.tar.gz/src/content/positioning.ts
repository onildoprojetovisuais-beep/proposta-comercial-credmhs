import type { ChapterId } from '../types/presentation';

/**
 * Posicionamento 3C/3I (Brandbook Grupo CRED MHS, p. 21 — "Eixos, temáticas e mensagens-chave").
 *
 * Decisão do Nil em 16/10/2026: o nome do eixo aparece escrito em cada seção onde ele é a
 * mensagem principal, para deixar visível que a apresentação fala dos 3C/3I. Isso muda a regra
 * anterior da revisão V2 (3C/3I só por trás da copy).
 *
 * Limites que continuam valendo:
 * - É posicionamento de marca, NÃO metodologia nem processo: sem ordem, setas, números de etapa
 *   ou "seis passos". Cada seção mostra um eixo; não há sequência entre eles.
 * - Não se mistura com os quatro eixos de soluções (solutions.ts) nem com a trilha de valor
 *   (valueTrail.ts). "Inovação" e "Investimento" existem nas três estruturas; o selo sempre
 *   leva o prefixo 3C/3I para não confundir.
 * - `message` é o texto do brandbook, só para orientar fala e redação; não é renderizado.
 */
export type PillarId = 'credibilidade' | 'compromisso' | 'conhecimento' | 'inovacao' | 'investimento' | 'inteligencia';

export interface Pillar {
  id: PillarId;
  group: '3C' | '3I';
  label: string;
  /** Mensagem-chave do brandbook (uso interno). */
  message: string;
}

export const pillars: readonly Pillar[] = [
  {
    id: 'credibilidade',
    group: '3C',
    label: 'Credibilidade',
    message: 'Nossa história remete à profissionalização do setor. Relacionamento próximo e acessível como diferencial estratégico.',
  },
  {
    id: 'compromisso',
    group: '3C',
    label: 'Compromisso',
    message: 'Gestão familiar comprometida com o negócio e as pessoas que o compõem. Obsessão pelo cliente torna a empresa flexível e ágil no atendimento das demandas.',
  },
  {
    id: 'conhecimento',
    group: '3C',
    label: 'Conhecimento',
    message: 'Contribuímos para a profissionalização do setor e por isso temos um profundo conhecimento do negócio. Nossa experiência agrega valor à gestão de saúde e segurança do trabalho de qualquer cliente.',
  },
  {
    id: 'inovacao',
    group: '3I',
    label: 'Inovação',
    message: 'Tecnologia e dados como motor para segurança da informação, qualidade de entrega e transformações no negócio, no setor e para o cliente. Olhar único para as pessoas que compõem as organizações dos nossos clientes.',
  },
  {
    id: 'investimento',
    group: '3I',
    label: 'Investimento',
    message: 'Crescimento sustentado que reflete a visão de que ainda há muito a ser feito para a evolução do setor no atendimento aos clientes. Nossa prestação de serviços compreende a gestão de saúde e segurança operacional como diferencial estratégico para o seu negócio.',
  },
  {
    id: 'inteligencia',
    group: '3I',
    label: 'Inteligência',
    message: 'Gestão compartilhada e colaborativa focada em melhoria contínua para os clientes. Nossa atuação nacional em diferentes setores da economia nos dá acesso a um estoque de conhecimento ímpar para o segmento.',
  },
];

export const pillarById = Object.fromEntries(pillars.map((p) => [p.id, p])) as Record<PillarId, Pillar>;

/**
 * Eixo em evidência em cada seção (um por seção; cada eixo aparece uma vez).
 * Abertura e Contato são do executivo e ficam sem selo.
 * Critério: a mensagem-chave do brandbook que a seção mais demonstra.
 */
export const chapterPillar: Partial<Record<ChapterId, PillarId>> = {
  institucional: 'credibilidade', // história, números, empresas atendidas
  relacionamento: 'compromisso', // pessoa de referência, atendimento ágil às demandas
  dados: 'inovacao', // tecnologia e dados a serviço da entrega
  'gestao-integrada': 'inteligencia', // gestão compartilhada e colaborativa
  trilha: 'investimento', // SST como diferencial estratégico para o negócio
  solucoes: 'conhecimento', // experiência que agrega valor à gestão de qualquer cliente
};

/** Legenda pública (seção institucional, primeira com selo). Copy de trabalho, validar com a Sabrina. */
export const positioningKey = {
  title: 'O posicionamento da CRED MHS',
  groups: [
    { group: '3C', labels: ['Credibilidade', 'Compromisso', 'Conhecimento'] },
    { group: '3I', labels: ['Inovação', 'Investimento', 'Inteligência'] },
  ],
} as const;
