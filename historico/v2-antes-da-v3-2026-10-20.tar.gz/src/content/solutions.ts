import type { InventoryItem, SolutionAxis, SolutionAxisId } from '../types/presentation';

/**
 * Quatro eixos de soluções (framework “Soluções que nos levam além”, recebido da Sabrina em
 * 14/10/2026; docs/REVISAO-CRED-MHS-V2.md §5 e §7-07; docs/V2-MAPEAMENTO-FRAMEWORKS.md).
 *
 * - Os eixos NÃO são pacotes nem contratações separadas; saúde e segurança seguem integradas.
 * - Investimento é a 5ª etapa da trilha (valueTrail.ts), nunca um 5º eixo.
 * - `summary` e `examples` são públicos e sempre visíveis. `detail` é aprofundamento opcional.
 * - `inventory` é uso interno: framework + catálogo da V1 (PPTX), sem perda silenciosa.
 *   Nunca renderizar `inventory`, `note`, `pendingRef` ou `sources`.
 * - Os JPEGs originais do framework não estavam no projeto em 14/10 (docs/07, P33): a
 *   classificação segue a transcrição da revisão §5.
 * - Símbolos BI/AI e ícones ESG/ODS do material NÃO viram capacidade, certificação ou promessa.
 */

const FW = 'framework-solucoes' as const;
const PPTX = 'pptx' as const;

// ---------------------------------------------------------------------------
// Normativo
// ---------------------------------------------------------------------------

const normativoInventory: InventoryItem[] = [
  { label: 'PGR/GRO', sources: [FW, PPTX], sourceSlides: [8], display: 'inventario', pendingRef: 'P10' },
  { label: 'LTCAT', sources: [FW, PPTX], sourceSlides: [8], display: 'inventario', pendingRef: 'P10' },
  { label: 'PCMSO', sources: [FW, PPTX], sourceSlides: [7], display: 'inventario', pendingRef: 'P10' },
  { label: 'PCMAT', sources: [FW, PPTX], sourceSlides: [8], display: 'inventario', pendingRef: 'P37', note: 'Programa exige revisão técnica de vigência antes de publicação detalhada (revisão §5).' },
  { label: 'Relatório anual', sources: [FW, PPTX], sourceSlides: [7], display: 'inventario', pendingRef: 'P10', note: 'V1: "Relatório Anual" (PCMSO).' },
  { label: 'PCA', sources: [FW], display: 'inventario', pendingRef: 'P10', note: 'Só no framework; não estava no catálogo da V1.' },
  { label: 'PPRA', sources: [FW], display: 'inventario', pendingRef: 'P37', note: 'Programa exige revisão técnica de vigência antes de publicação (revisão §5).' },
  { label: 'PPP — Perfil Profissional Previdenciário', sources: [FW, PPTX], sourceSlides: [7], display: 'inventario', pendingRef: 'P10' },
  { label: 'Atestado médico', sources: [FW], display: 'inventario', note: 'Framework: "atestado médico". V1 listava "ASO — Atestado de Saúde Ocupacional" (item separado abaixo); não fundir sem confirmação.' },
  { label: 'ASO — Atestado de Saúde Ocupacional', sources: [PPTX], sourceSlides: [7], display: 'inventario', pendingRef: 'P10', note: 'Catálogo V1 (Saúde Ocupacional); classificado no Normativo por afinidade com "atestado médico".' },
  { label: 'Convocação de exames periódicos', sources: [FW, PPTX], sourceSlides: [7], display: 'detalhe', publicLabel: 'Gestão e convocação de exames periódicos', note: 'V1: "Gestão de Convocação de Periódicos".' },
  { label: 'Gestão dos Exames Ocupacionais', sources: [PPTX], sourceSlides: [7], display: 'exemplo', publicLabel: 'Exames ocupacionais', note: 'Catálogo V1; não listado nominalmente no framework. Base do exemplo editorial "Exames ocupacionais".' },
  { label: 'Exames Ocupacionais In Company', sources: [PPTX], sourceSlides: [7], display: 'detalhe', publicLabel: 'Exames ocupacionais na própria empresa', note: 'Catálogo V1; não listado no framework.' },
  { label: 'LI e LP', sources: [FW, PPTX], sourceSlides: [8], display: 'detalhe', publicLabel: 'Laudos de insalubridade e periculosidade', note: 'V1: "Laudos de Insalubridade e Periculosidade".' },
  { label: 'CIPA', sources: [FW, PPTX], sourceSlides: [8], display: 'inventario', pendingRef: 'P10' },
  { label: 'Mapa de risco', sources: [FW], display: 'detalhe', publicLabel: 'Mapa de risco' },
  { label: 'Mapa de distribuição de extintores', sources: [FW], display: 'inventario' },
  { label: 'Ordens de serviço', sources: [FW, PPTX], sourceSlides: [8], display: 'detalhe', publicLabel: 'Ordens de serviço' },
  { label: 'Fichas de EPI', sources: [FW, PPTX], sourceSlides: [8], display: 'detalhe', publicLabel: 'Gestão de EPI', note: 'V1: "Gestão de EPI".' },
  { label: 'Certificados de treinamentos', sources: [FW], display: 'inventario', note: 'Framework coloca certificados no Normativo; os treinamentos em si ficam em Inovação.' },
  { label: 'Sistema de gestão', sources: [FW], display: 'inventario', note: 'Item do Normativo no framework, sem descrição; recursos do sistema estão no eixo Gestão.' },
  { label: 'Perícias', sources: [FW, PPTX], sourceSlides: [8], display: 'detalhe', publicLabel: 'Perícias' },
  { label: 'Análise ergonômica', sources: [FW, PPTX], sourceSlides: [15], display: 'detalhe', publicLabel: 'Análise ergonômica', note: 'V1: solução adicional (slide 15). Framework: Normativo.' },
  { label: 'Equipamentos de medição de riscos', sources: [FW, PPTX], sourceSlides: [11], display: 'exemplo', publicLabel: 'Avaliações técnicas', note: 'V1: "Parque próprio de equipamentos tecnológicos para medições" ("de última geração" não reproduzido). Base do exemplo "Avaliações técnicas".' },
  { label: 'Programas de saúde e segurança (PCMSO, PGR/GRO, LTCAT e afins)', sources: [FW, PPTX], sourceSlides: [7, 8], display: 'exemplo', publicLabel: 'Programas de saúde e segurança', note: 'Exemplo editorial agrupado; siglas só após revisão técnica e de escopo.' },
  { label: 'Riscos Psicossociais NR1 — Programa de Vigilância Epidemiológica sob medida', sources: [PPTX], sourceSlides: [14], display: 'detalhe', publicLabel: 'Programa para riscos psicossociais, estruturado para a realidade da empresa', pendingRef: 'P38', note: 'Não aparece no framework. Classificado no Normativo por relação com a NR-1 (divergência registrada). Nunca renomear como VIVA (P16).' },
];

// ---------------------------------------------------------------------------
// Reputacional — entrega para a empresa cliente; não é prova social da CRED MHS
// ---------------------------------------------------------------------------

const reputacionalInventory: InventoryItem[] = [
  { label: 'Norteadores estratégicos para posicionamento da marca', sources: [FW], display: 'detalhe', publicLabel: 'Norteadores estratégicos para o posicionamento da marca' },
  { label: 'Integração de SSO com RH, comunicação e marketing', sources: [FW], display: 'exemplo', publicLabel: 'Integração com a comunicação' },
  { label: 'Envolvimento da liderança', sources: [FW], display: 'exemplo', publicLabel: 'Alinhamento de liderança' },
  { label: 'OK’s e KPI’s', sources: [FW], display: 'exemplo', publicLabel: 'Indicadores de percepção', pendingRef: 'P36', note: 'Grafia do framework: "OK’s e KPI’s". Não expandir para OKRs; copy pública usa "indicadores".' },
  { label: 'Apuração da percepção de efetividade', sources: [FW], display: 'detalhe', publicLabel: 'Apuração da percepção sobre as ações de saúde e segurança' },
  { label: 'Ícones ESG/ODS', sources: [FW], display: 'inventario', pendingRef: 'P35', note: 'Ilustração do material; não comprova certificação nem resultado ambiental/social.' },
];

// ---------------------------------------------------------------------------
// Gestão
// ---------------------------------------------------------------------------

const gestaoInventory: InventoryItem[] = [
  { label: 'Integração com folha', sources: [FW], display: 'detalhe', publicLabel: 'Integração com a folha de pagamento' },
  { label: 'Integração com softwares ERP', sources: [PPTX], sourceSlides: [9, 12], display: 'exemplo', publicLabel: 'Integração de dados', note: 'V1. "100% aderente" e "qualquer software ERP" ficam só na fonte.' },
  { label: 'Importação/exportação de dados', sources: [FW, PPTX], sourceSlides: [9], display: 'detalhe', publicLabel: 'Importação e exportação de dados', note: 'V1: "Interface online para importação e exportação de dados".' },
  { label: 'Gestão eletrônica de documentos', sources: [FW, PPTX], sourceSlides: [9], display: 'exemplo', publicLabel: 'Gestão eletrônica de documentos' },
  { label: 'Assinatura digital', sources: [FW, PPTX], sourceSlides: [9], display: 'exemplo', publicLabel: 'Assinatura digital' },
  { label: 'Aplicativo móvel', sources: [FW, PPTX], sourceSlides: [9], display: 'detalhe', publicLabel: 'Aplicativo móvel' },
  { label: 'Acervo fotográfico', sources: [FW, PPTX], sourceSlides: [9], display: 'detalhe', publicLabel: 'Acervo fotográfico' },
  { label: 'Biometria', sources: [FW, PPTX], sourceSlides: [9], display: 'detalhe', publicLabel: 'Biometria' },
  { label: 'Nuvem', sources: [FW, PPTX], sourceSlides: [9], display: 'detalhe', publicLabel: 'Sistema em nuvem', note: '"100% na nuvem" fica só na fonte.' },
  { label: 'Saúde remota', sources: [FW, PPTX], sourceSlides: [9], display: 'detalhe', publicLabel: 'Saúde remota' },
  { label: 'eSocial — sistema online que interliga os locais de atendimento, parametrização eSocial e webservice com ERP', sources: [FW, PPTX], sourceSlides: [11, 12], display: 'detalhe', publicLabel: 'Parametrização para o eSocial e integração com sistemas', pendingRef: 'P08', note: 'V1: aplicação eSocial (M07). "4 soluções para o eSocial" segue retido (P08).' },
  { label: 'Portal de Serviços On-line — acompanhamento do atendimento e SLA', sources: [PPTX], sourceSlides: [11], display: 'detalhe', publicLabel: 'Portal online para acompanhar os atendimentos', pendingRef: 'P39', note: 'V1 (M06). SLA não aparece como promessa até escopo confirmado (revisão §8). Não listado no framework.' },
  { label: 'Customização de dados e desenvolvimento de indicadores', sources: [PPTX], sourceSlides: [9], display: 'inventario', note: 'V1 (Gestão e Tecnologia). Coberto pela copy de Dados ("Dados organizados para a gestão").' },
  { label: 'Integração à Fábrica de Power BI', sources: [PPTX], sourceSlides: [11], display: 'inventario', pendingRef: 'P34', note: 'Não usar com o símbolo BI do framework para prometer análises; manter fora da página até descrição validada.' },
  { label: 'Mentoria para ativação de módulos do sistema de gestão; aprendizagem dos profissionais técnicos', sources: [PPTX], sourceSlides: [9], display: 'inventario' },
  { label: 'LGPD', sources: [FW, PPTX], sourceSlides: [9, 18], display: 'inventario', pendingRef: 'P06', note: 'Referência no framework e "Totalmente adequada à LGPD" no slide 9: não é certificação; exige revisão técnica (P37).' },
  { label: 'Símbolos BI e AI', sources: [FW], display: 'inventario', pendingRef: 'P34', note: 'Não descrevem produto nem capacidade; proibido prometer IA, análise preditiva ou recomendações automáticas.' },
];

// ---------------------------------------------------------------------------
// Inovação
// ---------------------------------------------------------------------------

const inovacaoInventory: InventoryItem[] = [
  { label: 'Gestão de FAP/NTEP — Projeto Cuidar', sources: [FW, PPTX], sourceSlides: [13], display: 'detalhe', publicLabel: 'Gestão de FAP/NTEP, com acompanhamento das etapas do processo', pendingRef: 'P11', note: 'V1: aplicação M07. Nome "Projeto Cuidar" fica no inventário (detalhe proprietário). Sem promessa de alíquota ou economia.' },
  { label: 'Monitoramento por telemedicina', sources: [FW, PPTX], sourceSlides: [15], display: 'exemplo', publicLabel: 'Monitoramento por telemedicina' },
  { label: 'Teleatendimento e telediagnóstico', sources: [PPTX], sourceSlides: [11], display: 'inventario', note: 'V1 (M06, recursos complementares). Não listado no framework; afinidade com telemedicina. Telediagnóstico exige revisão técnica de escopo.' },
  { label: 'Administração de ambulatórios', sources: [FW, PPTX], sourceSlides: [15], display: 'exemplo', publicLabel: 'Administração de ambulatórios' },
  { label: 'Mão de obra especializada', sources: [FW, PPTX], sourceSlides: [15], display: 'detalhe', publicLabel: 'Mão de obra especializada', note: 'V1: "Locação de Mão de Obra".' },
  { label: 'Continuidade de negócios', sources: [FW, PPTX], sourceSlides: [15], display: 'detalhe', publicLabel: 'Plano de continuidade de negócios' },
  { label: 'Veículo de urgência e emergência', sources: [FW, PPTX], sourceSlides: [15], display: 'detalhe', publicLabel: 'Veículo de urgência e emergência', note: 'V1: "Locação de Veículo de Urgência e Emergência".' },
  { label: 'Vacinas', sources: [FW, PPTX], sourceSlides: [15], display: 'detalhe', publicLabel: 'Campanhas de vacinação', note: 'V1: "Campanhas Vacinais".' },
  { label: 'Ginástica laboral', sources: [FW, PPTX], sourceSlides: [15], display: 'detalhe', publicLabel: 'Ginástica laboral' },
  { label: 'SIPAT digital', sources: [FW, PPTX], sourceSlides: [15], display: 'detalhe', publicLabel: 'SIPAT digital' },
  { label: 'Treinamentos normativos EAD e práticos', sources: [FW, PPTX], sourceSlides: [10], display: 'exemplo', publicLabel: 'Treinamentos digitais e práticos' },
  { label: 'Central EAD integrada ao software de gestão (certificados, conteúdo programático, listas de presença)', sources: [PPTX], sourceSlides: [10, 11], display: 'detalhe', publicLabel: 'Central de treinamentos a distância integrada à gestão de certificados e listas de presença' },
  { label: 'Mais de 77 cursos na central EAD', sources: [PPTX], sourceSlides: [10], display: 'inventario', pendingRef: 'P09', note: 'Valor do PPTX sem data-base; catálogo de cursos exige revisão (revisão §8). Não inferir 77 NRs.' },
  { label: 'Temas NR: NR-01, NR-05, NR-06, NR-10, NR-10 SEP, NR-11, NR-12, NR-13, NR-17, NR-20, NR-33, NR-35', sources: [PPTX], sourceSlides: [10], display: 'inventario', pendingRef: 'P10', note: 'Lista completa preservada em docs/02 (Histórico V1). Nomenclatura normativa exige revisão técnica.' },
  { label: 'Mapeamento dos treinamentos normativos e automação dos personalizados; acesso multiplataforma', sources: [PPTX], sourceSlides: [10], display: 'inventario' },
  { label: 'Gestão de Absenteísmo', sources: [PPTX], sourceSlides: [15], display: 'detalhe', publicLabel: 'Gestão de absenteísmo', pendingRef: 'P38', note: 'V1: solução adicional (slide 15). Não aparece no framework; classificada em Inovação por afinidade com FAP/NTEP (divergência registrada). Sem promessa de redução ou previsão de afastamentos.' },
];

export const solutionAxes: readonly SolutionAxis[] = [
  {
    id: 'normativo',
    label: 'Normativo',
    summary:
      'Programas, exames, documentos e serviços técnicos para apoiar o atendimento às exigências de saúde e segurança do trabalho.',
    examples: ['Programas de saúde e segurança', 'Exames ocupacionais', 'Avaliações técnicas'],
    detail: {
      label: 'Outros exemplos do eixo Normativo',
      items: [
        'Gestão e convocação de exames periódicos',
        'Exames ocupacionais na própria empresa',
        'Laudos de insalubridade e periculosidade',
        'Perícias',
        'Análise ergonômica',
        'Mapa de risco',
        'Ordens de serviço e gestão de EPI',
        'Programa para riscos psicossociais, estruturado para a realidade da empresa',
      ],
    },
    inventory: normativoInventory,
  },
  {
    id: 'reputacional',
    label: 'Reputacional',
    summary:
      'Conexão entre saúde e segurança, liderança, RH e comunicação para fortalecer a percepção de cuidado com as pessoas.',
    examples: ['Alinhamento de liderança', 'Integração com a comunicação', 'Indicadores de percepção'],
    detail: {
      label: 'Outros exemplos do eixo Reputacional',
      items: [
        'Norteadores estratégicos para o posicionamento da marca',
        'Integração da saúde e segurança com RH, comunicação e marketing',
        'Apuração da percepção sobre as ações de saúde e segurança',
      ],
    },
    inventory: reputacionalInventory,
  },
  {
    id: 'gestao',
    label: 'Gestão',
    summary:
      'Informações, documentos e sistemas conectados para apoiar o acompanhamento da operação e as decisões das equipes.',
    examples: ['Integração de dados', 'Gestão eletrônica de documentos', 'Assinatura digital'],
    detail: {
      label: 'Outros recursos do eixo Gestão',
      items: [
        'Integração com a folha de pagamento',
        'Importação e exportação de dados',
        'Parametrização para o eSocial e integração com sistemas',
        'Portal online para acompanhar os atendimentos',
        'Aplicativo móvel',
        'Acervo fotográfico',
        'Biometria',
        'Saúde remota',
        'Sistema em nuvem',
      ],
      note: 'Recursos disponíveis conforme o escopo definido com cada empresa.',
    },
    inventory: gestaoInventory,
  },
  {
    id: 'inovacao',
    label: 'Inovação',
    summary:
      'Soluções aplicadas às necessidades da empresa, com foco em transformar ações em valor para a operação e as pessoas.',
    examples: ['Monitoramento por telemedicina', 'Administração de ambulatórios', 'Treinamentos digitais e práticos'],
    detail: {
      label: 'Outros exemplos do eixo Inovação',
      items: [
        'Gestão de FAP/NTEP, com acompanhamento das etapas do processo',
        'Gestão de absenteísmo',
        'Central de treinamentos a distância integrada à gestão de certificados e listas de presença',
        'Plano de continuidade de negócios',
        'Mão de obra especializada',
        'Veículo de urgência e emergência',
        'Campanhas de vacinação',
        'Ginástica laboral',
        'SIPAT digital',
      ],
    },
    inventory: inovacaoInventory,
  },
];

export const axisById: Readonly<Record<SolutionAxisId, SolutionAxis>> = Object.fromEntries(
  solutionAxes.map((a) => [a.id, a]),
) as Record<SolutionAxisId, SolutionAxis>;
