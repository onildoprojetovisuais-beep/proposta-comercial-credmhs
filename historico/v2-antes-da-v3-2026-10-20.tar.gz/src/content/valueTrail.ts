import type { ValueStep } from '../types/presentation';

/**
 * Trilha de valor na gestão de SSO (framework recebido da Sabrina em 14/10/2026;
 * docs/REVISAO-CRED-MHS-V2.md §5 "Sentido das cinco etapas" e §7-06).
 *
 * - Ordem fixa: Normativo → Reputacional → Gestão → Inovação → Investimento.
 * - Explicação comercial de valor. NÃO é pacote, contratação sequencial, pontuação de
 *   maturidade, diagnóstico do visitante nem garantia de retorno financeiro.
 * - Investimento é etapa da trilha, nunca um 5º eixo de soluções (ver solutions.ts).
 * - Textos públicos = tabela da revisão §7-06 (copy de trabalho, a validar com a Sabrina).
 *
 * Sentido de cada etapa no framework (uso interno, para orientar fala e redação):
 * 1. Normativo: a necessidade de gestão de SSO nasce do enquadramento legal e regulatório.
 * 2. Reputacional: a marca percebida como local de trabalho saudável, seguro e comprometido
 *    com o bem-estar da sociedade.
 * 3. Gestão: ferramentas, processos e metodologias organizam dados e informações para dar
 *    transparência e apoiar decisões.
 * 4. Inovação: o valor está nas ações implementadas e nos resultados para a empresa e a
 *    sociedade, não apenas na presença de tecnologia.
 * 5. Investimento: aplicação estratégica e intencional de recursos, baseada em dados,
 *    conduzida por pessoas que reconhecem valor para si, suas equipes, o negócio e a sociedade.
 */
export const valueTrail: readonly ValueStep[] = [
  { id: 'normativo', order: 1, label: 'Normativo', text: 'Atender às exigências que fazem parte da operação.' },
  { id: 'reputacional', order: 2, label: 'Reputacional', text: 'Fortalecer a percepção de um ambiente de trabalho saudável e seguro.' },
  { id: 'gestao', order: 3, label: 'Gestão', text: 'Organizar informações para acompanhar a operação e apoiar decisões.' },
  { id: 'inovacao', order: 4, label: 'Inovação', text: 'Transformar ações implementadas em valor para a empresa e as pessoas.' },
  { id: 'investimento', order: 5, label: 'Investimento', text: 'Direcionar recursos com intenção, dados e visão de negócio.' },
];
