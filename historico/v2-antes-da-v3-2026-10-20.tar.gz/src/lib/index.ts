export { formatTemplate, joinPtBr } from './format';
export { resolveExecutive, resolveLocalExecutive, readExecutiveRequest, getExecutiveById, getDefaultExecutive } from './executive';
export type { ExecutiveRequest, ResolveExecutiveOptions } from './executive';
export { contactLinks } from './personalization';
