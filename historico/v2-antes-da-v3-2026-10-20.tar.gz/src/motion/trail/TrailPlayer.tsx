import { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';
import { Player, type PlayerRef } from '@remotion/player';
import { TrailScene } from './TrailScene';
import { TRAIL_DURATION, TRAIL_FPS, type TrailSceneProps } from './timing';

/**
 * Player Remotion da trilha (carregado sob demanda pela seção 06; fora do bundle inicial).
 * Sem controles nativos, sem loop, sem áudio, sem clique no vídeo: a seção controla tocar,
 * pausar e repetir com botões próprios.
 */
export interface TrailPlayerProps {
  scene: TrailSceneProps;
  width: number;
  height: number;
  onFrame: (frame: number) => void;
  onEnded: () => void;
}

export type TrailPlayerHandle = Pick<PlayerRef, 'play' | 'pause' | 'seekTo' | 'getCurrentFrame' | 'isPlaying'>;

const TrailPlayer = forwardRef<TrailPlayerHandle, TrailPlayerProps>(function TrailPlayer(
  { scene, width, height, onFrame, onEnded },
  ref,
) {
  const player = useRef<PlayerRef>(null);
  const callbacks = useRef({ onFrame, onEnded });
  callbacks.current = { onFrame, onEnded };

  useImperativeHandle(ref, () => ({
    play: () => player.current?.play(),
    pause: () => player.current?.pause(),
    seekTo: (f: number) => player.current?.seekTo(f),
    getCurrentFrame: () => player.current?.getCurrentFrame() ?? 0,
    isPlaying: () => player.current?.isPlaying() ?? false,
  }));

  useEffect(() => {
    const p = player.current;
    if (!p) return;
    const frame = (e: { detail: { frame: number } }) => callbacks.current.onFrame(e.detail.frame);
    const ended = () => callbacks.current.onEnded();
    p.addEventListener('frameupdate', frame);
    p.addEventListener('seeked', frame);
    p.addEventListener('ended', ended);
    return () => {
      p.removeEventListener('frameupdate', frame);
      p.removeEventListener('seeked', frame);
      p.removeEventListener('ended', ended);
    };
  }, []);

  return (
    <Player
      ref={player}
      component={TrailScene}
      inputProps={scene}
      durationInFrames={TRAIL_DURATION}
      fps={TRAIL_FPS}
      compositionWidth={Math.max(1, Math.round(width))}
      compositionHeight={Math.max(1, Math.round(height))}
      controls={false}
      loop={false}
      clickToPlay={false}
      doubleClickToFullscreen={false}
      spaceKeyToPlayOrPause={false}
      numberOfSharedAudioTags={0}
      acknowledgeRemotionLicense
      style={{ width: '100%', height: '100%', background: 'transparent' }}
    />
  );
});

export default TrailPlayer;
