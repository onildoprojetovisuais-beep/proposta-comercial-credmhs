import type { CSSProperties } from 'react';
import { Easing, interpolate, useCurrentFrame } from 'remotion';
import {
  STEP_COUNT,
  SETTLE_START,
  TRAVEL,
  arrivalFrame,
  departureFrame,
  type TrailPoint,
  type TrailSceneProps,
} from './timing';

/**
 * Camada de movimento da trilha de valor (composição Remotion).
 *
 * Desenha só o trilho e os cinco marcadores, nas posições medidas da lista HTML: nomes e
 * descrições continuam no HTML (acessíveis, legíveis sem vídeo). Os cinco marcadores têm o
 * mesmo tratamento; Investimento é a chegada da linha, não um destaque diferente.
 *
 * Quadro 0: trilho claro e marcadores vazados (já legível). Último quadro: linha completa e cinco
 * marcadores pretos iguais — o mesmo estado estático da página sem movimento.
 */

const YELLOW = '#FFCA00';
const BLACK = '#000000';
const WHITE = '#FFFFFF';
const STROKE = 3;

// Div simples em vez de <AbsoluteFill>: no React 18 da app, AbsoluteFill 4.0.534 avisa sobre `ref`.
const fillStyle: CSSProperties = { position: 'absolute', inset: 0 };

const clamp = { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' } as const;
const ease = Easing.bezier(0.65, 0, 0.35, 1);
const easeOut = Easing.bezier(0.22, 1, 0.36, 1);

function segmentLengths(points: TrailPoint[]) {
  const lengths: number[] = [];
  for (let i = 1; i < points.length; i++) {
    lengths.push(Math.hypot(points[i].x - points[i - 1].x, points[i].y - points[i - 1].y));
  }
  return lengths;
}

/** Ponto ao longo da polilinha a uma distância `d` da origem. */
function pointAt(points: TrailPoint[], lengths: number[], d: number): TrailPoint {
  let rest = d;
  for (let i = 0; i < lengths.length; i++) {
    if (rest <= lengths[i] || i === lengths.length - 1) {
      const t = lengths[i] === 0 ? 0 : Math.min(1, rest / lengths[i]);
      return {
        x: points[i].x + (points[i + 1].x - points[i].x) * t,
        y: points[i].y + (points[i + 1].y - points[i].y) * t,
      };
    }
    rest -= lengths[i];
  }
  return points[points.length - 1];
}

export function TrailScene({ points, marker, labels }: TrailSceneProps) {
  const frame = useCurrentFrame();
  if (points.length < STEP_COUNT) return <div style={fillStyle} />;

  const lengths = segmentLengths(points);
  const cumulative = lengths.reduce<number[]>((acc, l) => [...acc, acc[acc.length - 1] + l], [0]);
  const total = cumulative[cumulative.length - 1];

  // Distância percorrida: parada em cada etapa, percurso suave entre elas.
  let distance = 0;
  for (let i = 0; i < STEP_COUNT - 1; i++) {
    const from = departureFrame(i);
    if (frame < from) break;
    distance = interpolate(frame, [from, from + TRAVEL], [cumulative[i], cumulative[i + 1]], { ...clamp, easing: ease });
  }

  const head = pointAt(points, lengths, distance);
  // A ponta só aparece no percurso; desenhada sob os marcadores, sai de um e entra no próximo.
  let headOpacity = 0;
  for (let i = 0; i < STEP_COUNT - 1; i++) {
    const from = departureFrame(i);
    headOpacity = Math.max(headOpacity, interpolate(frame, [from, from + 3, from + TRAVEL - 3, from + TRAVEL], [0, 1, 1, 0], clamp));
  }
  const baseOpacity = interpolate(frame, [SETTLE_START, SETTLE_START + 12], [0.28, 0], clamp);
  const path = points.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.x} ${p.y}`).join(' ');
  const r = marker / 2;

  return (
    <div style={fillStyle}>
      <svg width="100%" height="100%" style={{ overflow: 'visible' }} aria-hidden="true">
        {/* Trilho completo, claro: mostra o caminho inteiro desde o início. */}
        <path d={path} fill="none" stroke={BLACK} strokeOpacity={baseOpacity} strokeWidth={STROKE} strokeDasharray="2 8" strokeLinecap="round" />
        {/* Linha que avança. */}
        <path
          d={path}
          fill="none"
          stroke={BLACK}
          strokeWidth={STROKE}
          strokeDasharray={`${total} ${total}`}
          strokeDashoffset={total - distance}
        />

        <circle cx={head.x} cy={head.y} r={7} fill={WHITE} stroke={BLACK} strokeWidth={STROKE} opacity={headOpacity} />

        {points.map((p, i) => {
          const arrive = arrivalFrame(i);
          const leave = i === STEP_COUNT - 1 ? SETTLE_START : departureFrame(i);
          const fill = interpolate(frame, [arrive, arrive + 8], [0, 1], clamp);
          const halo =
            interpolate(frame, [arrive, arrive + 12], [0, 1], { ...clamp, easing: easeOut }) *
            interpolate(frame, [leave, leave + 10], [1, 0], clamp);
          return (
            <g key={i}>
              {halo > 0 ? (
                <circle cx={p.x} cy={p.y} r={r + 4 + 6 * halo} fill="none" stroke={WHITE} strokeWidth={8} strokeOpacity={halo} />
              ) : null}
              <circle cx={p.x} cy={p.y} r={r - STROKE / 2} fill={YELLOW} stroke={BLACK} strokeWidth={STROKE} />
              <circle cx={p.x} cy={p.y} r={(r - STROKE / 2) * fill} fill={BLACK} />
              <text
                x={p.x}
                y={p.y}
                textAnchor="middle"
                dominantBaseline="central"
                fill={fill > 0.5 ? YELLOW : BLACK}
                style={{ font: `900 ${Math.round(marker * 0.36)}px var(--font-brand, 'Sommet Rounded', Arial, sans-serif)`, fontVariantNumeric: 'tabular-nums' }}
              >
                {labels[i]}
              </text>
            </g>
          );
        })}

      </svg>
    </div>
  );
}
