/**
 * Linha do tempo da composição da trilha de valor (Remotion, 30 fps).
 * Sem import de `remotion`: o HTML da seção usa as mesmas marcas para destacar a etapa ativa.
 *
 * Sequência: a linha parte da etapa 1, para em cada etapa (destaque) e segue até Investimento.
 * Depois de Investimento o destaque se desfaz e as cinco etapas ficam iguais (composição completa),
 * no último quadro, que permanece na tela. Toca uma vez; não há loop.
 */
export const TRAIL_FPS = 30;
export const STEP_COUNT = 5;

/** Quadro em que a linha chega à etapa 1. */
const FIRST_ARRIVAL = 10;
/** Pausa em cada etapa (destaque da etapa e da descrição). */
export const DWELL = 40;
/** Percurso entre duas etapas. */
export const TRAVEL = 22;
/** Assentamento final: destaque some, composição completa. */
const SETTLE = 24;

export const arrivalFrame = (i: number) => FIRST_ARRIVAL + i * (DWELL + TRAVEL);
export const departureFrame = (i: number) => arrivalFrame(i) + DWELL;
/** Fim do destaque de Investimento. */
export const SETTLE_START = departureFrame(STEP_COUNT - 1);
export const TRAIL_DURATION = SETTLE_START + SETTLE;
export const LAST_FRAME = TRAIL_DURATION - 1;

/**
 * Etapa em destaque no quadro: a última alcançada, até o assentamento.
 * -1 antes da primeira chegada e depois do assentamento (todas iguais).
 */
export function activeStepAt(frame: number): number {
  if (frame < arrivalFrame(0) || frame >= SETTLE_START) return -1;
  let active = 0;
  for (let i = 0; i < STEP_COUNT; i++) if (frame >= arrivalFrame(i)) active = i;
  return active;
}

/** Quantas etapas a linha já alcançou no quadro (0–5). */
export function reachedCountAt(frame: number): number {
  let n = 0;
  for (let i = 0; i < STEP_COUNT; i++) if (frame >= arrivalFrame(i)) n = i + 1;
  return n;
}

export interface TrailPoint {
  x: number;
  y: number;
}

export interface TrailSceneProps {
  /** Centro de cada marcador em px, relativo à lista (medido no DOM; 5 pontos). */
  points: TrailPoint[];
  /** Diâmetro do marcador em px. */
  marker: number;
  /** Números exibidos nos marcadores ("01"…"05"). Decorativos: o HTML tem nome e texto. */
  labels: string[];
  // Index signature exigida pelo Player para inputProps.
  [key: string]: unknown;
}

/** Geometria de referência (desktop 1440, lista de 5 colunas) para Studio e renders de conferência. */
export const REFERENCE_PROPS: TrailSceneProps = {
  // Lista de 1180 px + 24 px de margem (halo) em volta, como na página.
  points: [0, 1, 2, 3, 4].map((i) => ({ x: 50 + i * 240.8, y: 50 })),
  marker: 52,
  labels: ['01', '02', '03', '04', '05'],
};
export const REFERENCE_SIZE = { width: 1228, height: 100 };
