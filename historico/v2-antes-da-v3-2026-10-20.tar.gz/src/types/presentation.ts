/**
 * Contrato V2 da apresentação pública (docs/REVISAO-CRED-MHS-V2.md, rev. 2.1; docs/V2-CONTRATO.md).
 * Dono: coordenador. Agentes consomem; mudanças de forma passam pelo coordenador.
 *
 * Três sistemas que NÃO se misturam (revisão §5):
 * - 3C/3I do brandbook → orientam linguagem e provas; nunca viram etapas nem componentes.
 * - Quatro eixos de soluções → `SolutionAxis` (Normativo, Reputacional, Gestão, Inovação).
 * - Trilha de valor em cinco etapas → `ValueStep` (… + Investimento). Investimento NÃO é eixo.
 */

// ---------------------------------------------------------------------------
// Capítulos (ordem da página = ordem deste tipo)
// ---------------------------------------------------------------------------

/** IDs das oito dobras. São também o `id` do <section> no DOM e o hash da URL (#trilha). */
export type ChapterId =
  | 'abertura'
  | 'institucional'
  | 'relacionamento'
  | 'dados'
  | 'gestao-integrada'
  | 'trilha'
  | 'solucoes'
  | 'contato';

export const CHAPTER_ORDER: readonly ChapterId[] = [
  'abertura',
  'institucional',
  'relacionamento',
  'dados',
  'gestao-integrada',
  'trilha',
  'solucoes',
  'contato',
];

export interface Chapter {
  id: ChapterId;
  /** Rótulo curto do índice "Conteúdo". */
  navLabel: string;
  /** Hashes antigos da V1 que devem cair neste capítulo (links já enviados). Uso interno. */
  legacyHashes?: string[];
}

// ---------------------------------------------------------------------------
// Quatro eixos de soluções
// ---------------------------------------------------------------------------

export type SolutionAxisId = 'normativo' | 'reputacional' | 'gestao' | 'inovacao';

/** Destino de um item do inventário na página. Nunca renderizar este campo. */
export type InventoryDisplay =
  /** aparece nos exemplos visíveis do eixo */
  | 'exemplo'
  /** aparece no aprofundamento opcional do eixo */
  | 'detalhe'
  /** preservado só no código/documentação (revisão técnica, escopo ou pendência) */
  | 'inventario';

export interface InventoryItem {
  /** Texto como aparece na fonte (sigla preservada). */
  label: string;
  /** De onde veio: framework “Soluções que nos levam além” e/ou PPTX original (slides). */
  sources: ('framework-solucoes' | 'pptx')[];
  sourceSlides?: number[];
  display: InventoryDisplay;
  /** Rótulo público quando `display !== 'inventario'` e o texto da fonte não serve ao prospect. */
  publicLabel?: string;
  /** ID de pendência em docs/07 (ex.: 'P10'). Uso interno. */
  pendingRef?: string;
  /** Nota interna (divergência de classificação, revisão técnica). Nunca renderizar. */
  note?: string;
}

export interface SolutionAxis {
  id: SolutionAxisId;
  /** Nome oficial do eixo: 'Normativo' | 'Reputacional' | 'Gestão' | 'Inovação'. */
  label: string;
  /** Resumo público (sempre visível, sem clique). */
  summary: string;
  /** Até três exemplos editoriais públicos (sempre visíveis). */
  examples: string[];
  /**
   * Aprofundamento opcional (disclosure acessível por teclado). Só itens com redação pública
   * revisada; ausente → o eixo não oferece aprofundamento.
   */
  detail?: { label: string; items: string[]; note?: string };
  /** Inventário completo do eixo (framework + catálogo anterior). Uso interno. */
  inventory: InventoryItem[];
}

// ---------------------------------------------------------------------------
// Trilha de valor (cinco etapas, ordem fixa)
// ---------------------------------------------------------------------------

export type ValueStepId = 'normativo' | 'reputacional' | 'gestao' | 'inovacao' | 'investimento';

export interface ValueStep {
  id: ValueStepId;
  /** 1–5. A ordem é a do framework e nunca muda. */
  order: 1 | 2 | 3 | 4 | 5;
  label: string;
  /** Texto público curto (revisão §7, tabela da seção 06). */
  text: string;
}

// ---------------------------------------------------------------------------
// Contatos (sem seleções, sem mensagem gerada)
// ---------------------------------------------------------------------------

export interface ContactLinksV2 {
  /** mailto: com destinatário e assunto fixo; sem corpo. null → perfil sem e-mail válido. */
  email: { href: string; label: string } | null;
  /** https://wa.me/<dígitos>, sem texto. null → canal não confirmado. */
  whatsApp: { href: string } | null;
  /** tel: E.164. */
  phone: { href: string; label: string } | null;
  linkedIn: { href: string } | null;
  website: { href: string; label: string } | null;
  /**
   * URL real de agendamento. Hoje sempre null: nenhum perfil tem booking confirmado
   * e o banco não tem esse campo (revisão §7, 08). Não inventar destino.
   */
  booking: { href: string } | null;
}
